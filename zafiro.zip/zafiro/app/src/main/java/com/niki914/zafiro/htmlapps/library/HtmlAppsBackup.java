package com.niki914.zafiro.htmlapps.library;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collection;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Whole-library ZIP backup and restore.
 *
 * Backups skip dot-folders (.versions, .trash), underscore folders (_exports, _models) and dot
 * files, so a backup never contains another backup. Restore rejects entries that escape the
 * library after canonicalisation (zip-slip) and can keep existing folders.
 */
public final class HtmlAppsBackup {

    public static class Result {
        public boolean ok;
        public int count;
        public String message;
    }

    private HtmlAppsBackup() {
    }

    public static Result backup(File root, OutputStream output, Collection<String> onlyFolders) {
        Result result = new Result();
        try (ZipOutputStream zip = new ZipOutputStream(output)) {
            File[] children = root.listFiles();
            if (children != null) {
                for (File app : children) {
                    if (!app.isDirectory()) continue;
                    String name = app.getName();
                    if (name.startsWith("_") || name.startsWith(".")) continue;
                    if (onlyFolders != null && !onlyFolders.contains(name)) continue;
                    File index = new File(app, "index.html");
                    if (!index.isFile()) continue;
                    addDir(zip, app, name);
                    result.count++;
                }
            }
            result.ok = true;
        } catch (Exception e) {
            result.ok = false;
            result.message = e.getMessage();
        }
        return result;
    }

    private static void addDir(ZipOutputStream zip, File dir, String prefix) throws Exception {
        File[] children = dir.listFiles();
        if (children == null) return;
        for (File child : children) {
            String name = child.getName();
            if (name.startsWith(".") && child.isFile()) continue;
            String entryName = prefix + "/" + name;
            if (child.isDirectory()) {
                addDir(zip, child, entryName);
            } else {
                ZipEntry entry = new ZipEntry(entryName);
                zip.putNextEntry(entry);
                try (InputStream in = new FileInputStream(child)) {
                    byte[] buffer = new byte[8192];
                    int read;
                    while ((read = in.read(buffer)) > 0) zip.write(buffer, 0, read);
                }
                zip.closeEntry();
            }
        }
    }

    public static Result restore(File root, InputStream input, boolean overwrite) {
        Result result = new Result();
        String rootPath;
        try {
            rootPath = root.getCanonicalPath() + File.separator;
        } catch (Exception e) {
            result.message = "kütüphane yolu okunamadı";
            return result;
        }
        if (!root.exists()) root.mkdirs();
        try (ZipInputStream zip = new ZipInputStream(input)) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                String name = entry.getName();
                if (name == null || name.isEmpty() || name.startsWith("__MACOSX")) continue;
                File target = new File(root, name);
                String targetPath = target.getCanonicalPath();
                if (!targetPath.startsWith(rootPath)) continue;
                if (entry.isDirectory()) {
                    target.mkdirs();
                    continue;
                }
                if (target.exists() && !overwrite) continue;
                File parent = target.getParentFile();
                if (parent != null && !parent.exists()) parent.mkdirs();
                try (OutputStream out = new FileOutputStream(target)) {
                    byte[] buffer = new byte[8192];
                    int read;
                    while ((read = zip.read(buffer)) > 0) out.write(buffer, 0, read);
                }
                result.count++;
            }
            result.ok = true;
        } catch (Exception e) {
            result.ok = false;
            result.message = e.getMessage();
        }
        return result;
    }

    public static File exportFile(File cacheDir, String prefix) {
        File dir = new File(cacheDir, "htmlapps");
        if (!dir.isDirectory()) dir.mkdirs();
        String name = prefix + "-" + System.currentTimeMillis() + ".zip";
        return new File(dir, name);
    }
}
