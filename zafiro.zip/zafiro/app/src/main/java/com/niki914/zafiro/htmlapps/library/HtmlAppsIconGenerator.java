package com.niki914.zafiro.htmlapps.library;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

import java.io.File;
import java.io.FileOutputStream;

/** Renders a launcher icon for a published HTML app (rounded colour tile + emoji). */
public final class HtmlAppsIconGenerator {

    private HtmlAppsIconGenerator() {}

    public static boolean render(File out, String emoji, int color) {
        try {
            int size = 512;
            Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setColor(color);
            canvas.drawRoundRect(new RectF(0, 0, size, size), size * 0.23f, size * 0.23f, paint);
            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(size * 0.61f);
            Paint.FontMetrics metrics = paint.getFontMetrics();
            float y = size / 2f - (metrics.ascent + metrics.descent) / 2f;
            canvas.drawText(emoji == null || emoji.isEmpty() ? "🤖" : emoji, size / 2f, y, paint);
            File parent = out.getParentFile();
            if (parent != null && !parent.isDirectory() && !parent.mkdirs()) return false;
            try (FileOutputStream stream = new FileOutputStream(out)) {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            }
            bitmap.recycle();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
