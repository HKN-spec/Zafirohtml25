package com.niki914.zafiro.htmlapps.library;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.niki914.zafiro.app.MainActivity;
import com.niki914.zafiro.app.R;
import com.niki914.zafiro.htmlapps.NovaPromptRelay;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Full HtmlApps library inside Zafiro.
 *
 * Grid/list, search, category chips, favourites, sorting, bulk actions, ZIP backup/restore,
 * recycle bin, QR import, shortcuts, icon editor, version history, sharing and stats.
 */
public class HtmlAppsLibraryActivity extends Activity {

    private static final int REQ_BACKUP_ZIP = 2001;
    private static final int REQ_RESTORE_ZIP = 2002;

    private static final int BG = 0xFF0B0F16;
    private static final int CARD = 0xFF151C27;
    private static final int CARD_2 = 0xFF101722;
    private static final int ACCENT = 0xFF3F8CFF;
    private static final int TEXT = 0xFFF2F6FF;
    private static final int MUTED = 0xFF8FA3BF;
    private static final int STROKE = 0xFF223048;

    private final List<HtmlAppsRepo.App> apps = new ArrayList<>();
    private final Set<String> selected = new LinkedHashSet<>();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final LruCache<String, Bitmap> iconCache = new LruCache<>(64);

    private File root;
    private GridView grid;
    private EditText etSearch;
    private LinearLayout chipsRow;
    private LinearLayout bulkBar;
    private TextView tvBulkCount;
    private TextView tvEmpty;
    private TextView tvCount;
    private TextView gridButton;
    private TextView permissionCard;
    private AppAdapter adapter;

    private String currentCategory = "all";
    private String currentSort = "created";
    private boolean gridMode = true;
    private boolean bulkMode = false;
    private boolean askedStorage = false;

    private final List<HtmlAppsRepo.App> pinQueue = new ArrayList<>();
    private int pinIndex;
    private int pinToken;
    private int pinFailures;
    private BroadcastReceiver pinReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = HtmlAppsRepo.root();
        if (hasStorage()) HtmlAppsRepo.ensureRoot();

        SharedPreferences prefs = getSharedPreferences("htmlapps_library_ui", MODE_PRIVATE);
        gridMode = prefs.getBoolean("grid", true);
        currentSort = prefs.getString("sort", "created");
        currentCategory = prefs.getString("category", "all");

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(0xFF070A10);
            getWindow().setNavigationBarColor(BG);
        }

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(BG);
        int pad = dp(12);
        main.setPadding(pad, dp(8), pad, 0);

        // ---------------------------------------------------------------- header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        main.addView(header);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        header.addView(titles, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView title = new TextView(this);
        title.setText("Kütüphane");
        title.setTextColor(TEXT);
        title.setTextSize(23);
        title.setTypeface(null, Typeface.BOLD);
        titles.addView(title);

        tvCount = new TextView(this);
        tvCount.setTextColor(MUTED);
        tvCount.setTextSize(11);
        titles.addView(tvCount);

        TextView add = headerButton("＋", v -> createWithNova());
        header.addView(add);
        gridButton = headerButton(gridMode ? "☰" : "▦", v -> {
            gridMode = !gridMode;
            gridButton.setText(gridMode ? "☰" : "▦");
            applyGridMode();
        });
        header.addView(gridButton);
        header.addView(headerButton("⇅", v -> showSortMenu()));
        header.addView(headerButton("⋮", v -> showLibraryMenu()));

        // ---------------------------------------------------------------- search
        etSearch = new EditText(this);
        etSearch.setHint("Ara: ad, açıklama, etiket…");
        etSearch.setHintTextColor(0xFF5E708A);
        etSearch.setTextColor(TEXT);
        etSearch.setTextSize(14);
        etSearch.setSingleLine(true);
        etSearch.setBackground(rounded(CARD, 14, STROKE));
        etSearch.setPadding(dp(14), dp(7), dp(14), dp(7));
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        searchParams.topMargin = dp(10);
        main.addView(etSearch, searchParams);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { refresh(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        // ---------------------------------------------------------------- chips
        HorizontalScrollView chipsScroll = new HorizontalScrollView(this);
        chipsScroll.setHorizontalScrollBarEnabled(false);
        chipsScroll.setPadding(0, dp(8), 0, dp(2));
        chipsRow = new LinearLayout(this);
        chipsRow.setOrientation(LinearLayout.HORIZONTAL);
        chipsScroll.addView(chipsRow);
        main.addView(chipsScroll);

        // ---------------------------------------------------------------- permission
        permissionCard = new TextView(this);
        permissionCard.setText("Kütüphaneyi görmek için tüm dosyalara erişim izni gerekiyor. "
                + "Dokun ve izni ver.");
        permissionCard.setTextColor(0xFFFFD180);
        permissionCard.setTextSize(12);
        permissionCard.setPadding(dp(12), dp(10), dp(12), dp(10));
        permissionCard.setBackground(rounded(0xFF2A2010, 12, 0xFF6B4E12));
        LinearLayout.LayoutParams permissionParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        permissionParams.topMargin = dp(8);
        main.addView(permissionCard, permissionParams);
        permissionCard.setOnClickListener(v -> openStorageSettings());

        // ---------------------------------------------------------------- grid
        grid = new GridView(this);
        grid.setNumColumns(gridMode ? 3 : 1);
        grid.setVerticalSpacing(dp(6));
        grid.setHorizontalSpacing(dp(2));
        grid.setPadding(0, dp(6), 0, dp(10));
        grid.setClipToPadding(false);
        grid.setSelector(new android.graphics.drawable.ColorDrawable(0x00000000));
        adapter = new AppAdapter();
        grid.setAdapter(adapter);
        LinearLayout.LayoutParams gridParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        main.addView(grid, gridParams);

        tvEmpty = new TextView(this);
        tvEmpty.setTextColor(MUTED);
        tvEmpty.setTextSize(13);
        tvEmpty.setGravity(Gravity.CENTER);
        tvEmpty.setPadding(pad, dp(30), pad, dp(30));
        main.addView(tvEmpty);

        // ---------------------------------------------------------------- bulk bar
        bulkBar = new LinearLayout(this);
        bulkBar.setOrientation(LinearLayout.HORIZONTAL);
        bulkBar.setGravity(Gravity.CENTER_VERTICAL);
        bulkBar.setPadding(dp(8), dp(8), dp(8), dp(8));
        bulkBar.setBackground(rounded(CARD, 16, STROKE));
        LinearLayout.LayoutParams bulkParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bulkParams.bottomMargin = dp(10);
        main.addView(bulkBar, bulkParams);
        bulkBar.setVisibility(View.GONE);

        tvBulkCount = new TextView(this);
        tvBulkCount.setTextColor(TEXT);
        tvBulkCount.setTextSize(12);
        bulkBar.addView(tvBulkCount, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        bulkBar.addView(bulkButton("Sil", 0xFFFF6B6B, v -> bulkDelete()));
        bulkBar.addView(bulkButton("Yedek", ACCENT, v -> bulkBackup()));
        bulkBar.addView(bulkButton("Kısayol", 0xFF4CAF50, v -> bulkShortcuts()));
        bulkBar.addView(bulkButton("İptal", 0xFF3A4556, v -> exitBulk()));

        setContentView(main);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (hasStorage()) HtmlAppsRepo.ensureRoot();
        iconCache.evictAll();
        refresh();
    }

    // ---------------------------------------------------------------- ui helpers

    private boolean hasStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                return Environment.isExternalStorageManager();
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    private void openStorageSettings() {
        if (Build.VERSION.SDK_INT < 30) return;
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            } catch (Exception ignored) {
                toast("Ayarlar açılamadı");
            }
        }
    }

    private TextView headerButton(String text, View.OnClickListener listener) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(TEXT);
        view.setTextSize(20);
        view.setGravity(Gravity.CENTER);
        view.setLayoutParams(new LinearLayout.LayoutParams(dp(42), dp(42)));
        view.setOnClickListener(listener);
        return view;
    }

    private TextView bulkButton(String text, int color, View.OnClickListener listener) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(Color.WHITE);
        view.setTextSize(11);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(9), dp(7), dp(9), dp(7));
        view.setBackground(rounded(color, 10, 0));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.leftMargin = dp(5);
        view.setLayoutParams(params);
        view.setOnClickListener(listener);
        return view;
    }

    private TextView chip(String label, String value, boolean selectedChip) {
        TextView view = new TextView(this);
        view.setText(label);
        view.setTextSize(11);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(12), dp(7), dp(12), dp(7));
        view.setTextColor(selectedChip ? Color.WHITE : MUTED);
        view.setBackground(rounded(selectedChip ? ACCENT : CARD, 20, selectedChip ? 0 : STROKE));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.rightMargin = dp(6);
        view.setLayoutParams(params);
        view.setOnClickListener(v -> {
            currentCategory = value;
            prefsUi().edit().putString("category", currentCategory).apply();
            refresh();
        });
        return view;
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private SharedPreferences prefsUi() {
        return getSharedPreferences("htmlapps_library_ui", MODE_PRIVATE);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    private void applyGridMode() {
        grid.setNumColumns(gridMode ? 3 : 1);
        adapter.notifyDataSetChanged();
        prefsUi().edit().putBoolean("grid", gridMode).apply();
    }

    // ---------------------------------------------------------------- data

    private void refresh() {
        boolean storage = hasStorage();
        permissionCard.setVisibility(storage ? View.GONE : View.VISIBLE);
        grid.setVisibility(storage ? View.VISIBLE : View.GONE);

        if (!storage) {
            apps.clear();
            adapter.notifyDataSetChanged();
            tvEmpty.setVisibility(View.VISIBLE);
            tvEmpty.setText("Tüm dosyalara erişim verilince kütüphane burada görünecek.");
            tvCount.setText("Erişim bekleniyor");
            chipsRow.removeAllViews();
            return;
        }

        List<HtmlAppsRepo.App> all = HtmlAppsRepo.list(root);
        apps.clear();
        apps.addAll(HtmlAppsRepo.filter(all, etSearch.getText().toString(),
                currentCategory, currentSort));
        adapter.notifyDataSetChanged();
        tvCount.setText(all.size() + " uygulama · " + visibleSizeLabel(all));
        tvEmpty.setVisibility(apps.isEmpty() ? View.VISIBLE : View.GONE);
        tvEmpty.setText(all.isEmpty()
                ? "Henüz uygulama yok. ＋ ile Nova'ya ilk uygulamanı ürettir."
                : "Aramaya uyan uygulama yok.");
        rebuildChips(all);
        updateBulkBar();
    }

    private String visibleSizeLabel(List<HtmlAppsRepo.App> all) {
        long total = 0;
        for (HtmlAppsRepo.App app : all) total += app.meta.sizeBytes;
        return HtmlAppsRepo.size(total);
    }

    private void rebuildChips(List<HtmlAppsRepo.App> all) {
        chipsRow.removeAllViews();
        chipsRow.addView(chip("Tümü (" + all.size() + ")", "all", "all".equals(currentCategory)));
        chipsRow.addView(chip("★ Favoriler", "fav", "fav".equals(currentCategory)));
        Set<String> categories = new LinkedHashSet<>();
        for (HtmlAppsRepo.App app : all) {
            String category = app.meta.category;
            if (category != null && !category.trim().isEmpty()) categories.add(category.trim());
        }
        for (String category : categories) {
            chipsRow.addView(chip(category, category, category.equals(currentCategory)));
        }
    }

    private void updateBulkBar() {
        if (bulkMode) {
            bulkBar.setVisibility(View.VISIBLE);
            tvBulkCount.setText(selected.size() + " seçili");
        } else {
            bulkBar.setVisibility(View.GONE);
        }
    }

    private void enterBulk() {
        bulkMode = true;
        selected.clear();
        refresh();
    }

    private void exitBulk() {
        bulkMode = false;
        selected.clear();
        refresh();
    }

    // ---------------------------------------------------------------- adapter

    private class AppAdapter extends BaseAdapter {
        @Override public int getCount() { return apps.size(); }
        @Override public Object getItem(int position) { return apps.get(position); }
        @Override public long getItemId(int position) { return position; }

        @Override
        public View getView(int position, View convert, ViewGroup parent) {
            boolean listMode = !gridMode;
            if (convert == null) {
                convert = LayoutInflater.from(HtmlAppsLibraryActivity.this).inflate(
                        listMode ? R.layout.item_htmlapps_list : R.layout.item_htmlapps_grid,
                        parent, false);
            }
            final HtmlAppsRepo.App app = apps.get(position);
            ImageView icon = convert.findViewById(R.id.ivIcon);
            icon.setImageBitmap(iconFor(app));
            TextView name = convert.findViewById(R.id.tvName);
            name.setText(app.name);
            TextView meta = convert.findViewById(R.id.tvMeta);
            String category = app.meta.category == null || app.meta.category.trim().isEmpty()
                    ? "Genel" : app.meta.category;
            meta.setText(category + " · " + HtmlAppsRepo.size(app.meta.sizeBytes));
            TextView desc = convert.findViewById(R.id.tvDesc);
            if (desc != null) {
                desc.setText(app.meta.description == null || app.meta.description.isEmpty()
                        ? app.folder : app.meta.description);
            }
            TextView fav = convert.findViewById(R.id.tvFav);
            if (fav != null) fav.setVisibility(app.meta.favorite ? View.VISIBLE : View.GONE);

            CheckBox check = convert.findViewById(R.id.chkSel);
            check.setVisibility(bulkMode ? View.VISIBLE : View.GONE);
            check.setChecked(selected.contains(app.folder));

            convert.setOnClickListener(v -> {
                if (bulkMode) {
                    if (selected.contains(app.folder)) selected.remove(app.folder);
                    else selected.add(app.folder);
                    notifyDataSetChanged();
                    updateBulkBar();
                } else {
                    openApp(app);
                }
            });
            convert.setOnLongClickListener(v -> {
                if (!bulkMode) onAppLongPressed(app);
                return true;
            });
            return convert;
        }
    }

    private Bitmap iconFor(HtmlAppsRepo.App app) {
        Bitmap cached = iconCache.get(app.folder);
        if (cached != null) return cached;
        Bitmap bitmap = HtmlAppsRepo.loadIcon(app);
        Bitmap scaled = Bitmap.createScaledBitmap(bitmap, 256, 256, true);
        iconCache.put(app.folder, scaled);
        return scaled;
    }

    // ---------------------------------------------------------------- app actions

    private void openApp(HtmlAppsRepo.App app) {
        HtmlAppsRepo.touch(root, app);
        HtmlAppsContextStore.setFolder(this, app.folder);
        HtmlAppsShortcut.launch(this, app.folder);
    }

    private void onAppLongPressed(final HtmlAppsRepo.App app) {
        String[] options = {
                "▶  Aç",
                "🖼  Önizleme",
                "🔗  Ana ekrana kısayol",
                "📤  Paylaş",
                "🕘  Sürüm geçmişi",
                "🎨  Simgeyi düzenle",
                "🏷  Kategori değiştir",
                app.meta.favorite ? "☆  Favoriden çıkar" : "⭐  Favorilere ekle",
                "⌨  Kodu gör",
                "💬  Sohbetle düzenle",
                "🗑  Geri dönüşüm kutusuna taşı"
        };
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(app.name)
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0:
                        case 1:
                            openApp(app);
                            break;
                        case 2:
                            addShortcut(app);
                            break;
                        case 3:
                            startActivity(new Intent(this, HtmlAppsShareActivity.class)
                                    .putExtra(HtmlAppsShareActivity.EXTRA_APP_FOLDER, app.folder));
                            break;
                        case 4:
                            startActivity(new Intent(this, HtmlAppsVersionsActivity.class)
                                    .putExtra(HtmlAppsVersionsActivity.EXTRA_APP_FOLDER, app.folder));
                            break;
                        case 5:
                            startActivity(new Intent(this, HtmlAppsIconEditorActivity.class)
                                    .putExtra(HtmlAppsIconEditorActivity.EXTRA_APP_FOLDER, app.folder));
                            break;
                        case 6:
                            changeCategory(app);
                            break;
                        case 7:
                            app.meta.favorite = !app.meta.favorite;
                            app.meta.save(app.dir);
                            refresh();
                            toast(app.meta.favorite ? "Favorilere eklendi" : "Favoriden çıkarıldı");
                            break;
                        case 8:
                            showCode(app);
                            break;
                        case 9:
                            editWithChat(app);
                            break;
                        default:
                            confirmDelete(app);
                            break;
                    }
                })
                .show();
    }

    private void addShortcut(final HtmlAppsRepo.App app) {
        File icon = new File(app.dir, "icon.png");
        boolean ok = HtmlAppsShortcut.register(this, app.folder, app.name, icon);
        toast(ok ? "Kısayol istendi" : "Launcher kısayolu reddetti");
    }

    private void changeCategory(final HtmlAppsRepo.App app) {
        final EditText input = new EditText(this);
        input.setText(app.meta.category);
        input.setSingleLine(true);
        input.setPadding(dp(16), dp(12), dp(16), dp(12));
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Kategori")
                .setView(input)
                .setPositiveButton("Kaydet", (dialog, which) -> {
                    String value = input.getText().toString().trim();
                    app.meta.category = value.isEmpty() ? "Genel" : value;
                    app.meta.save(app.dir);
                    refresh();
                })
                .setNegativeButton("İptal", null)
                .show();
    }

    private void editWithChat(HtmlAppsRepo.App app) {
        String prompt = "Kütüphanedeki \"" + app.name + "\" HtmlApps uygulamasını sohbetle "
                + "düzenle. Dosya: " + app.index.getAbsolutePath();
        NovaPromptRelay.offer(prompt, "library");
        startActivity(new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
    }

    private void createWithNova() {
        NovaPromptRelay.offer("HtmlApps kütüphanesi için tek dosyalık, çevrimdışı "
                + "çalışan yeni bir HTML uygulaması üret ve htmlapps_publish ile yayınla.", "library");
        startActivity(new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
    }

    private void showCode(HtmlAppsRepo.App app) {
        try {
            String html = HtmlAppsMeta.readText(app.index);
            TextView view = new TextView(this);
            view.setText(html);
            view.setTextSize(10.5f);
            view.setTypeface(Typeface.MONOSPACE);
            view.setTextColor(TEXT);
            view.setTextIsSelectable(true);
            view.setPadding(dp(12), dp(12), dp(12), dp(12));
            ScrollView scroll = new ScrollView(this);
            scroll.addView(view);
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                    .setTitle(app.name + " · index.html (" + html.length() + " karakter)")
                    .setView(scroll)
                    .setPositiveButton("Kapat", null)
                    .show();
        } catch (Exception e) {
            toast("Kod okunamadı: " + e.getMessage());
        }
    }

    private void confirmDelete(final HtmlAppsRepo.App app) {
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Geri dönüşüm kutusuna taşınsın mı?")
                .setMessage(app.name + " klasörü Geri Dönüşüm'e taşınır; oradan geri "
                        + "yükleyebilirsin.")
                .setNegativeButton("İptal", null)
                .setPositiveButton("Taşı", (dialog, which) -> {
                    String error = HtmlAppsRepo.moveToTrash(app.folder);
                    if (error != null) {
                        toast("Taşınamadı: " + error);
                        return;
                    }
                    HtmlAppsShortcut.removeDynamic(this, app.folder);
                    iconCache.remove(app.folder);
                    refresh();
                    toast("Geri dönüşüm kutusuna taşındı");
                })
                .show();
    }

    // ---------------------------------------------------------------- bulk actions

    private void bulkDelete() {
        if (selected.isEmpty()) {
            toast("Önce uygulama seç");
            return;
        }
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(selected.size() + " uygulama silinsin mi?")
                .setMessage("Seçili uygulamalar Geri Dönüşüm'e taşınır.")
                .setNegativeButton("İptal", null)
                .setPositiveButton("Taşı", (dialog, which) -> {
                    for (String folder : new ArrayList<>(selected)) {
                        HtmlAppsRepo.moveToTrash(folder);
                        HtmlAppsShortcut.removeDynamic(this, folder);
                        iconCache.remove(folder);
                    }
                    exitBulk();
                })
                .show();
    }

    private void bulkBackup() {
        if (selected.isEmpty()) {
            toast("Önce uygulama seç");
            return;
        }
        pickBackupTarget(new LinkedHashSet<>(selected));
    }

    private void bulkShortcuts() {
        if (selected.isEmpty()) {
            toast("Önce kısayol isteyeceğin uygulamaları seç");
            return;
        }
        List<HtmlAppsRepo.App> chosen = new ArrayList<>();
        for (HtmlAppsRepo.App app : HtmlAppsRepo.list(root)) {
            if (selected.contains(app.folder)) chosen.add(app);
        }
        if (chosen.isEmpty()) {
            toast("Seçili uygulama bulunamadı");
            return;
        }
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(chosen.size() + " uygulama için kısayol")
                .setMessage("Sadece seçtiğin uygulamalar için sırayla ana ekran kısayolu "
                        + "istenecek. Launcher her istekte onay gösterebilir.")
                .setPositiveButton("İste", (dialog, which) ->
                        restoreShortcuts(chosen, "Seçili"))
                .setNegativeButton("İptal", null)
                .show();
    }

    // ---------------------------------------------------------------- library menu

    private void showSortMenu() {
        final String[] labels = {"En yeni", "İsim (A-Z)", "Son kullanılan", "Boyut (büyük → küçük)"};
        final String[] values = {"created", "name", "used", "size"};
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Sırala")
                .setItems(labels, (dialog, which) -> {
                    currentSort = values[which];
                    prefsUi().edit().putString("sort", currentSort).apply();
                    refresh();
                })
                .show();
    }

    private void showLibraryMenu() {
        String[] options = {
                "☑  Toplu seçim",
                "💾  Kütüphaneyi yedekle (ZIP)",
                "📥  Yedekten geri yükle",
                "🗑  Geri dönüşüm kutusu",
                "📷  QR'dan uygulama içe aktar",
                "📊  Kullanım istatistikleri",
                "🔗  Tüm uygulamaların kısayollarını geri yükle",
                "⚙  Kütüphane ayarları"
        };
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Kütüphane")
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0: enterBulk(); break;
                        case 1: pickBackupTarget(null); break;
                        case 2: pickRestoreZip(); break;
                        case 3: showTrash(); break;
                        case 4: showQrImportDialog(); break;
                        case 5:
                            startActivity(new Intent(this, HtmlAppsStatsActivity.class));
                            break;
                        case 6: restoreShortcuts(HtmlAppsRepo.list(root), "Tümü"); break;
                        default: showSettingsDialog(); break;
                    }
                })
                .show();
    }

    private void showSettingsDialog() {
        final SharedPreferences prefs = prefsUi();
        String[] options = {
                (prefs.getBoolean("grid", gridMode) ? "✓ " : "") + "Varsayılan ızgara görünümü",
                "Sık kullanılan sıralama: " + sortLabel(currentSort),
                "Kütüphane klasörü: " + root.getAbsolutePath(),
                "Hakkında"
        };
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Kütüphane ayarları")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        gridMode = !gridMode;
                        prefs.edit().putBoolean("grid", gridMode).apply();
                        gridButton.setText(gridMode ? "☰" : "▦");
                        applyGridMode();
                    } else if (which == 1) {
                        showSortMenu();
                    } else if (which == 2) {
                        toast(root.getAbsolutePath());
                    } else {
                        new AlertDialog.Builder(this,
                                android.R.style.Theme_DeviceDefault_Dialog_Alert)
                                .setTitle("HtmlApps Kütüphanesi")
                                .setMessage("Zafiro içindeki HtmlApps kütüphanesi.\n\n"
                                        + "• Izgara/liste, arama, kategori, favori, sıralama\n"
                                        + "• Toplu silme, ZIP yedek, kısayol\n"
                                        + "• Sürüm geçmişi, simge düzenleyici\n"
                                        + "• Nova ile sohbetle düzenleme\n\n"
                                        + "Klasör: " + root.getAbsolutePath())
                                .setPositiveButton("Tamam", null)
                                .show();
                    }
                })
                .show();
    }

    private String sortLabel(String sort) {
        if ("name".equals(sort)) return "İsim (A-Z)";
        if ("used".equals(sort)) return "Son kullanılan";
        if ("size".equals(sort)) return "Boyut";
        return "En yeni";
    }

    // ---------------------------------------------------------------- backup / restore

    private void pickBackupTarget(Set<String> only) {
        try {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/zip");
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
            intent.putExtra(Intent.EXTRA_TITLE, "HtmlApps-yedek-" + stamp + ".zip");
            if (only != null) onlyFolders = only;
            else onlyFolders = null;
            startActivityForResult(intent, REQ_BACKUP_ZIP);
        } catch (Exception e) {
            toast("Dosya seçici açılamadı");
        }
    }

    private Set<String> onlyFolders;

    private void pickRestoreZip() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQ_RESTORE_ZIP);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        if (requestCode == REQ_BACKUP_ZIP) {
            final Set<String> only = onlyFolders;
            onlyFolders = null;
            new Thread(() -> {
                String message;
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    HtmlAppsBackup.Result result = HtmlAppsBackup.backup(root, out, only);
                    message = result.ok
                            ? result.count + " uygulama yedeklendi"
                            : "Yedek başarısız: " + result.message;
                } catch (Exception e) {
                    message = "Yedek başarısız: " + e.getMessage();
                }
                final String text = message;
                ui.post(() -> {
                    toast(text);
                    exitBulk();
                });
            }, "htmlapps-backup").start();
        } else if (requestCode == REQ_RESTORE_ZIP) {
            new Thread(() -> {
                String message;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    HtmlAppsBackup.Result result = HtmlAppsBackup.restore(root, in, false);
                    message = result.ok
                            ? result.count + " dosya geri yüklendi"
                            : "Geri yükleme başarısız: " + result.message;
                } catch (Exception e) {
                    message = "Geri yükleme başarısız: " + e.getMessage();
                }
                final String text = message;
                ui.post(() -> {
                    iconCache.evictAll();
                    refresh();
                    toast(text);
                });
            }, "htmlapps-restore").start();
        }
    }

    // ---------------------------------------------------------------- trash

    private void showTrash() {
        final List<HtmlAppsRepo.App> trash = HtmlAppsRepo.trashApps();
        if (trash.isEmpty()) {
            toast("Geri dönüşüm kutusu boş");
            return;
        }
        String[] names = new String[trash.size()];
        for (int i = 0; i < trash.size(); i++) names[i] = "♻ " + trash.get(i).name;
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Geri dönüşüm kutusu (" + trash.size() + ")")
                .setItems(names, (dialog, which) -> showTrashItem(trash.get(which)))
                .setNeutralButton("Çöpü boşalt", (dialog, which) -> emptyTrash())
                .setNegativeButton("Kapat", null)
                .show();
    }

    private void showTrashItem(final HtmlAppsRepo.App app) {
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(app.name)
                .setItems(new String[]{"♻ Geri yükle", "🗑 Kalıcı olarak sil"}, (dialog, which) -> {
                    if (which == 0) {
                        boolean ok = HtmlAppsRepo.restoreFromTrash(app.folder);
                        toast(ok ? "Geri yüklendi" : "Geri yüklenemedi");
                        refresh();
                    } else {
                        HtmlAppsRepo.deleteDir(app.dir);
                        toast("Kalıcı olarak silindi");
                    }
                })
                .show();
    }

    private void emptyTrash() {
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Çöp kutusu boşaltılsın mı?")
                .setMessage("Geri dönüşüm kutusundaki tüm uygulamalar kalıcı olarak silinir. "
                        + "Bu işlem geri alınamaz.")
                .setNegativeButton("İptal", null)
                .setPositiveButton("Boşalt", (dialog, which) -> {
                    File[] children = HtmlAppsRepo.trashDir().listFiles();
                    if (children != null) for (File child : children) HtmlAppsRepo.deleteDir(child);
                    toast("Çöp kutusu boşaltıldı");
                })
                .show();
    }

    // ---------------------------------------------------------------- qr import

    private void showQrImportDialog() {
        final EditText input = new EditText(this);
        input.setHint("QR içeriğini buraya yapıştır");
        input.setMinLines(4);
        input.setGravity(Gravity.TOP);
        int pad = dp(14);
        input.setPadding(pad, pad, pad, pad);
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("QR'dan içe aktar")
                .setMessage("HtmlApps'te paylaşılan QR metnini buraya yapıştır.")
                .setView(input)
                .setPositiveButton("İçe aktar", (dialog, which) -> {
                    String data = input.getText().toString().trim();
                    if (!data.isEmpty()) importQr(data);
                })
                .setNegativeButton("İptal", null)
                .show();
    }

    private void importQr(final String data) {
        new Thread(() -> {
            String message;
            try {
                String[] unpacked = HtmlAppsQr.unpackApp(data);
                String folder = unpacked[0] == null ? ""
                        : unpacked[0].replaceAll("[^\\p{L}\\p{N}_-]", "");
                String html = unpacked[1];
                if (folder.isEmpty() || html == null || html.trim().isEmpty()) {
                    throw new Exception("QR geçersiz");
                }
                File dir = new File(root, folder);
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("klasör açılamadı");
                try (FileOutputStream out = new FileOutputStream(new File(dir, "index.html"))) {
                    out.write(html.getBytes(StandardCharsets.UTF_8));
                }
                HtmlAppsMeta meta = HtmlAppsMeta.load(dir);
                meta.name = folder;
                meta.description = "QR'dan içe aktarıldı";
                meta.createdAt = System.currentTimeMillis();
                meta.sizeBytes = HtmlAppsRepo.dirSize(dir);
                meta.save(dir);
                HtmlAppsIconGenerator.render(new File(dir, "icon.png"), meta.iconEmoji,
                        Color.parseColor(meta.iconColor));
                new HtmlAppsVersions(dir).snapshot("QR içe aktarma");
                message = "İçe aktarıldı: " + folder;
            } catch (Exception e) {
                message = "İçe aktarılamadı: " + e.getMessage();
            }
            final String text = message;
            ui.post(() -> {
                refresh();
                toast(text);
            });
        }, "htmlapps-qr").start();
    }

    // ---------------------------------------------------------------- shortcuts

    private void restoreShortcuts(List<HtmlAppsRepo.App> source, String label) {
        unregisterPinReceiver();
        pinQueue.clear();
        if (source != null) pinQueue.addAll(source);
        pinIndex = 0;
        pinToken++;
        pinFailures = 0;
        if (pinQueue.isEmpty()) {
            toast("Uygulama yok");
            return;
        }
        pinReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                pinToken++;
                pinNext();
            }
        };
        try {
            IntentFilter filter = new IntentFilter(HtmlAppsShortcut.ACTION_PIN);
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(pinReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(pinReceiver, filter);
            }
        } catch (Exception ignored) {
        }
        toast(label + ": " + pinQueue.size() + " uygulama için kısayol sırayla istenecek");
        pinNext();
    }

    private void pinNext() {
        if (pinIndex >= pinQueue.size()) {
            int count = pinQueue.size();
            toast(count + " uygulama için kısayol istendi");
            unregisterPinReceiver();
            if (bulkMode) exitBulk();
            return;
        }
        final HtmlAppsRepo.App app = pinQueue.get(pinIndex++);
        File icon = new File(app.dir, "icon.png");
        Intent callbackIntent = new Intent(HtmlAppsShortcut.ACTION_PIN);
        callbackIntent.setPackage(getPackageName());
        callbackIntent.putExtra("index", pinIndex);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent callback = PendingIntent.getBroadcast(this, 1000 + pinIndex,
                callbackIntent, flags);
        boolean requested;
        try {
            requested = HtmlAppsShortcut.register(this, app.folder, app.name, icon, callback);
        } catch (Exception e) {
            requested = false;
        }
        if (!requested) {
            pinFailures++;
            if (pinFailures >= 3) {
                pinFailures = 0;
                ui.postDelayed(this::pinNext, 150);
            } else {
                ui.postDelayed(this::pinNext, 300);
            }
            return;
        }
        pinFailures = 0;
        final int token = pinToken;
        ui.postDelayed(() -> {
            if (token == pinToken) {
                pinToken++;
                pinNext();
            }
        }, 5000);
    }

    private void unregisterPinReceiver() {
        if (pinReceiver != null) {
            try {
                unregisterReceiver(pinReceiver);
            } catch (Exception ignored) {
            }
            pinReceiver = null;
        }
    }

    @Override
    protected void onDestroy() {
        unregisterPinReceiver();
        super.onDestroy();
    }
}
