package com.niki914.zafiro.htmlapps.library;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/** Internal hook: the agent/tool layer can publish generated HTML with a broadcast. */
public class HtmlAppsPublishReceiver extends BroadcastReceiver {

    public static final String ACTION_PUBLISH = "com.niki914.zafiro.htmlapps.PUBLISH_HTML";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !ACTION_PUBLISH.equals(intent.getAction())) return;
        String html = intent.getStringExtra("html");
        String name = intent.getStringExtra("name");
        try {
            java.io.File dir = HtmlAppsLibrary.publish(context, name, html);
            boolean pinned = HtmlAppsShortcut.register(context, dir.getName(),
                    dir.getName(), new java.io.File(dir, "icon.png"));
            Toast.makeText(context, "HtmlApps'a eklendi: " + dir.getName()
                    + (pinned ? " · ana ekran kısayolu istendi" : ""),
                    Toast.LENGTH_SHORT).show();
            showReadyNotification(context, dir);
        } catch (Exception e) {
            Toast.makeText(context, "HtmlApps'a eklenemedi: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void showReadyNotification(Context context, java.io.File dir) {
        try {
            android.app.NotificationManager manager =
                    (android.app.NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) return;
            String channel = "htmlapps";
            if (android.os.Build.VERSION.SDK_INT >= 26
                    && manager.getNotificationChannel(channel) == null) {
                manager.createNotificationChannel(new android.app.NotificationChannel(
                        channel, "HtmlApps", android.app.NotificationManager.IMPORTANCE_HIGH));
            }
            Intent open = new Intent(context, HtmlAppsViewerActivity.class);
            open.putExtra(HtmlAppsViewerActivity.EXTRA_FOLDER, dir.getName());
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            int flags = android.app.PendingIntent.FLAG_UPDATE_CURRENT;
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                flags |= android.app.PendingIntent.FLAG_IMMUTABLE;
            }
            android.app.PendingIntent pending = android.app.PendingIntent.getActivity(
                    context, dir.getName().hashCode(), open, flags);
            android.app.Notification.Builder builder = android.os.Build.VERSION.SDK_INT >= 26
                    ? new android.app.Notification.Builder(context, channel)
                    : new android.app.Notification.Builder(context);
            builder.setSmallIcon(android.R.drawable.ic_menu_view)
                    .setContentTitle("HtmlApps hazır: " + dir.getName())
                    .setContentText("Dokunup çalıştır")
                    .setContentIntent(pending)
                    .setAutoCancel(true);
            manager.notify(dir.getName().hashCode(), builder.build());
        } catch (Exception ignored) {
        }
    }
}
