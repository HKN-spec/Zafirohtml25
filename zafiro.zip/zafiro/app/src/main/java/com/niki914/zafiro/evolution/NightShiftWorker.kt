package com.niki914.zafiro.evolution

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.niki914.logging.Logger
import com.niki914.zafiro.evolution.core.EvolutionRuntime
import com.niki914.zafiro.evolution.core.Texts
import com.niki914.zafiro.evolution.json.asDoubleOrNull
import com.niki914.zafiro.evolution.json.asInt
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import java.time.Duration
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.concurrent.TimeUnit

/**
 * R8/P5: the only autonomous entry point. It never edits code; it runs the
 * observation loop (diagnose → static arena → meta → resource report), respects
 * charging/battery/screen/time conditions, and leaves one morning notification.
 * One night = no more than one change; self-editing stays human/CI-gated.
 */
class NightShiftWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val runtime = EvolutionRuntime.getOrNull() ?: return Result.success()
        val config = runtime.config()
        if (!config.nightlyEnabled) return Result.success()
        if (runtime.services.state.load().safeMode) {
            runtime.note("night_skip", "Güvenli mod açık; gece oturumu atlandı.")
            return Result.success()
        }
        val hour = LocalTime.now().hour
        if (!inWindow(hour, config.nightStartHour, config.nightEndHour)) return Result.success()

        val battery = applicationContext.getSystemService(BatteryManager::class.java)
        val charging = battery?.isCharging == true
        val level = battery?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val interactive = applicationContext.getSystemService(PowerManager::class.java)?.isInteractive == true
        if (config.nightRequireCharging && !charging) {
            runtime.note("night_skip", "Koşul yok: şarjda değil.")
            return Result.success()
        }
        if (level in 0 until config.nightMinBattery) {
            runtime.note("night_skip", "Koşul yok: pil %$level < %${config.nightMinBattery}.")
            return Result.success()
        }
        if (interactive) {
            runtime.note("night_skip", "Koşul yok: ekran açık.")
            return Result.success()
        }

        return try {
            val summary = withTimeout(config.nightMaxMinutes.coerceIn(10, 240) * 60_000L) {
                val diagnosis = runtime.diagnose(7)
                val arena = runtime.arenaRun(limit = 5)
                val meta = runtime.metaReport()
                runtime.resourceReport()
                runtime.note(
                    "night_done",
                    "Gece turu: ${diagnosis.turns} tur, ${diagnosis.gaps.size} gap; " +
                        "arena ${arena["defended"].asInt()}/${arena["cases"].asInt()}; " +
                        "meta ${meta["acceptance_rate"].asDoubleOrNull() ?: 0.0}",
                )
                "Gece raporu: ${diagnosis.turns} tur, ${diagnosis.gaps.size} kanıtlı eksik. " +
                    "Arena ${arena["defended"].asInt()}/${arena["cases"].asInt()}."
            }
            notifyMorning(summary)
            Result.success()
        } catch (timeout: TimeoutCancellationException) {
            runtime.engine.safeMode("Gece oturumu zaman aşımı (${config.nightMaxMinutes} dk).")
            notifyMorning("Gece oturumu zaman aşımına uğradı; güvenli moda geçildi.")
            Result.success()
        } catch (throwable: Throwable) {
            Logger.w(LOG_TAG, "night shift failed: ${throwable.message}")
            runtime.note("night_error", throwable.message ?: throwable::class.java.simpleName)
            notifyMorning("Gece oturumu hata verdi: ${throwable.message ?: "bilinmeyen"}")
            Result.failure()
        }
    }

    private fun inWindow(hour: Int, start: Int, end: Int): Boolean {
        val s = start.coerceIn(0, 23)
        val e = end.coerceIn(0, 24)
        return if (s <= e) hour in s until e else hour >= s || hour < e
    }

    private fun notifyMorning(text: String) {
        val manager = applicationContext.getSystemService(NotificationManager::class.java) ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Zafiro gece raporu", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Zafiro gece raporu")
            .setContentText(Texts.oneLine(text, 180))
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .build()
        runCatching {
            if (NotificationManagerCompat.from(applicationContext).areNotificationsEnabled()) {
                NotificationManagerCompat.from(applicationContext).notify(NOTIFICATION_ID, notification)
            }
        }
    }

    companion object {
        private const val LOG_TAG = "niki914_zafiro_NightShift"
        const val CHANNEL_ID = "zafiro_night_shift"
        private const val NOTIFICATION_ID = 9901
    }
}

object NightShiftScheduler {
    private const val UNIQUE_NAME = "zafiro-night-shift"

    fun schedule(context: Context, enabled: Boolean, startHour: Int) {
        val manager = WorkManager.getInstance(context)
        if (!enabled) {
            manager.cancelUniqueWork(UNIQUE_NAME)
            return
        }
        val request = PeriodicWorkRequestBuilder<NightShiftWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(initialDelayMs(startHour), TimeUnit.MILLISECONDS)
            .setConstraints(
                Constraints.Builder()
                    .setRequiresBatteryNotLow(true)
                    .build()
            )
            .build()
        manager.enqueueUniquePeriodicWork(UNIQUE_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    private fun initialDelayMs(startHour: Int): Long {
        val now = LocalDateTime.now()
        var next = now.withHour(startHour.coerceIn(0, 23)).withMinute(0).withSecond(0).withNano(0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        return Duration.between(now, next).toMillis().coerceAtLeast(60_000L)
    }
}
