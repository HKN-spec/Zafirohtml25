package com.niki914.zafiro.htmlapps.avatar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * App-process endpoint for the agent-runtime avatar tool and any same-package HTML page.
 * The agent runs in a separate process, so it dispatches intent extras instead of touching views.
 */
public class HtmlAppsAvatarReceiver extends BroadcastReceiver {

    public static final String ACTION = "com.niki914.zafiro.htmlapps.AVATAR";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !ACTION.equals(intent.getAction())) return;
        AvatarOverlay avatar = AvatarOverlay.get(context);
        String op = intent.getStringExtra("op");
        if (op == null) return;
        switch (op) {
            case "show": avatar.show(); break;
            case "hide": avatar.hide(); break;
            case "say": avatar.say(intent.getStringExtra("text"), intent.getLongExtra("durationMs", 3800)); break;
            case "mood": avatar.setMood(intent.getStringExtra("mood")); break;
            case "walk": avatar.walkTo(intent.getIntExtra("x", 0), intent.getIntExtra("y", 0),
                    intent.getLongExtra("durationMs", 700)); break;
            case "point": avatar.pointAt(intent.getIntExtra("x", 0), intent.getIntExtra("y", 0),
                    intent.getStringExtra("label")); break;
            case "circle": avatar.circle(intent.getIntExtra("x", 0), intent.getIntExtra("y", 0),
                    intent.getIntExtra("r", 80), intent.getIntExtra("color", 0xFFFFC857),
                    intent.getLongExtra("durationMs", 900)); break;
            case "underline": avatar.underline(intent.getIntExtra("x1", 0), intent.getIntExtra("y1", 0),
                    intent.getIntExtra("x2", 0), intent.getIntExtra("y2", 0),
                    intent.getIntExtra("color", 0xFFFFD54F),
                    intent.getLongExtra("durationMs", 800)); break;
            case "draw": {
                List<float[]> points = parsePoints(intent.getStringExtra("points"));
                if (!points.isEmpty()) {
                    avatar.drawPath(points, intent.getIntExtra("color", 0xFFFF5252),
                            (float) intent.getFloatExtra("width", 5f),
                            intent.getLongExtra("durationMs", 900));
                }
                break;
            }
            case "tap_ripple": avatar.tapRipple(intent.getIntExtra("x", 0),
                    intent.getIntExtra("y", 0)); break;
            case "tap":
                avatar.pointAt(intent.getIntExtra("x", 0), intent.getIntExtra("y", 0), "");
                final int tapX = intent.getIntExtra("x", 0);
                final int tapY = intent.getIntExtra("y", 0);
                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(
                        () -> HtmlAppsScreenBridge.INSTANCE.tap(context, tapX, tapY), 680);
                break;
            case "long_click":
                avatar.pointAt(intent.getIntExtra("x", 0), intent.getIntExtra("y", 0), "");
                final int longX = intent.getIntExtra("x", 0);
                final int longY = intent.getIntExtra("y", 0);
                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(
                        () -> HtmlAppsScreenBridge.INSTANCE.longClick(context, longX, longY), 680);
                break;
            case "swipe":
                avatar.underline(intent.getIntExtra("x1", 0), intent.getIntExtra("y1", 0),
                        intent.getIntExtra("x2", 0), intent.getIntExtra("y2", 0),
                        0xFFFFC857, intent.getLongExtra("durationMs", 400));
                final int sx1 = intent.getIntExtra("x1", 0);
                final int sy1 = intent.getIntExtra("y1", 0);
                final int sx2 = intent.getIntExtra("x2", 0);
                final int sy2 = intent.getIntExtra("y2", 0);
                final long swipeMs = intent.getLongExtra("durationMs", 400);
                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(
                        () -> HtmlAppsScreenBridge.INSTANCE.swipe(context, sx1, sy1, sx2, sy2,
                                swipeMs), 680);
                break;
            default: break;
        }
    }

    private static List<float[]> parsePoints(String raw) {
        List<float[]> out = new ArrayList<>();
        if (raw == null || raw.isEmpty()) return out;
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONArray point = array.optJSONArray(i);
                if (point == null || point.length() < 2) continue;
                out.add(new float[]{(float) point.optDouble(0, 0),
                        (float) point.optDouble(1, 0)});
            }
        } catch (Exception ignored) {
        }
        return out;
    }
}
