// githooks:ignore-file file-token-limit
package com.niki914.zafiro.runtime.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.DeadObjectException
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.net.toUri
import com.niki914.logging.Logger
import com.niki914.store.HostApp
import com.niki914.store.XIpcStoreRepository
import com.niki914.zafiro.api.Agent
import com.niki914.zafiro.api.AgentControl
import com.niki914.zafiro.api.AgentManager
import com.niki914.zafiro.api.TurnStart
import com.niki914.zafiro.api.telemetry.Metrics
import com.niki914.zafiro.api.model.AgentState
import com.niki914.zafiro.api.model.ApprovalDecision
import com.niki914.zafiro.api.model.TurnFailureCode
import com.niki914.zafiro.api.model.isRunning
import com.niki914.zafiro.app.MainActivity
import com.niki914.zafiro.app.notification.ResidentNotificationBuilder
import com.niki914.zafiro.app.notification.ResidentNotificationManager
import com.niki914.zafiro.app.notification.TurnNotificationManager
import com.niki914.zafiro.business.notification.NotificationChannelManager
import com.niki914.zafiro.business.permission.Permission
import com.niki914.zafiro.business.permission.PermissionManager
import com.niki914.zafiro.business.permission.PermissionState
import com.niki914.zafiro.chat.ToolStatusLabels
import com.niki914.zafiro.repo.XRepo
import com.niki914.zafiro.runtime.ipc.IAgentRuntimeService
import com.niki914.zafiro.runtime.ipc.IAgentStoreService
import com.niki914.zafiro.runtime.ipc.IRenderFrameCallback
import com.niki914.zafiro.runtime.ipc.RenderFrame
import com.niki914.zafiro.service.requireService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.dropWhile
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicReference
import com.niki914.zafiro.app.R as AppR

class AgentRuntimeService : Service() {

    override fun onCreate() {
        super.onCreate()
        instance = this
        val initialNotification = ResidentNotificationBuilder.build(
            context = this,
            channelManager = notificationChannelManager,
            status = agentControl.status.value,
        )
        startForeground(ResidentNotificationBuilder.NOTIFICATION_ID, initialNotification)
        observeStatus()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ResidentNotificationBuilder.ACTION_STOP -> {
                Logger.i(LOG_TAG, "Resident notification: Stop clicked")
                agentControl.stop()
            }

            ResidentNotificationBuilder.ACTION_APPROVE -> {
                Logger.i(LOG_TAG, "Resident notification: Approve clicked")
                ResidentNotificationManager.resolveApproval(ApprovalDecision.Allow)
            }

            ResidentNotificationBuilder.ACTION_DECLINE -> {
                Logger.i(LOG_TAG, "Resident notification: Decline clicked")
                ResidentNotificationManager.resolveApproval(ApprovalDecision.Deny)
            }

            ACTION_START_RESIDENT -> {
                isResidentRequested = true
                updateResidentNotification()
            }

            ACTION_STOP_RESIDENT -> {
                isResidentRequested = false
                if (boundClientsCount == 0 && activeTurn.get() == null) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        if (!validateCaller()) return null
        boundClientsCount++
        return StubImpl()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        boundClientsCount = (boundClientsCount - 1).coerceAtLeast(0)
        if (boundClientsCount == 0 && !isResidentRequested && activeTurn.get() == null) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        statusJob?.cancel()
        activeTurn.getAndSet(null)?.job?.cancel()
        scope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    private val agentManager: AgentManager get() = requireService()
    private val agentControl: AgentControl get() = requireService()
    private val notificationChannelManager: NotificationChannelManager get() = requireService()
    private val permissionManager: PermissionManager get() = requireService()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val activeTurn = AtomicReference<ActiveTurn?>(null)
    private var currentHostAgent: Agent? = null
    private var statusJob: Job? = null
    private var boundClientsCount = 0
    private var isResidentRequested = false

    private data class ActiveTurn(
        val callback: IRenderFrameCallback,
        val job: Job,
        val agent: Agent,
    )

    companion object {
        private const val LOG_TAG = "niki914_zafiro_AgentRuntimeService"
        const val ACTION_START_RESIDENT = "com.niki914.zafiro.action.START_RESIDENT"
        const val ACTION_STOP_RESIDENT = "com.niki914.zafiro.action.STOP_RESIDENT"
        private const val MAX_QUERY_LENGTH = 8192
        private const val STORE_CHANNEL_ID = "nexus_xservice_default_channel"
        private const val STORE_CHANNEL_NAME = "Zafiro"

        private var instance: AgentRuntimeService? = null

        fun notifyUpdate() {
            instance?.updateResidentNotification()
        }
    }

    fun updateResidentNotification() {
        val status = agentControl.status.value
        val notification = ResidentNotificationBuilder.build(
            context = this,
            channelManager = notificationChannelManager,
            status = status,
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(ResidentNotificationBuilder.NOTIFICATION_ID, notification)
    }

    private fun observeStatus() {
        statusJob = scope.launch {
            agentControl.status.collect {
                updateResidentNotification()
            }
        }
    }

    private inner class StubImpl : IAgentRuntimeService.Stub() {
        private val storeStub = StoreStubImpl()

        override fun getStoreBinder(): IBinder? {
            if (!validateCaller()) return null
            return storeStub
        }

        override fun submit(query: String?, callback: IRenderFrameCallback?) {
            val q = query ?: return
            val cb = callback ?: return

            if (q.isBlank() || q.length > MAX_QUERY_LENGTH) {
                Logger.w(
                    LOG_TAG,
                    "submit rejected queryLength=${q.length} maxLength=$MAX_QUERY_LENGTH " +
                            "reason=${if (q.isBlank()) "blank" else "tooLong"}"
                )
                sendError(
                    cb, "Query is blank or exceeds maximum length of $MAX_QUERY_LENGTH characters",
                )
                return
            }
            Logger.i(LOG_TAG, "submit accepted queryLength=${q.length}")

            val callingUid = getCallingUid()
            val callingPackages = packageManager.getPackagesForUid(callingUid)
            val host = callingPackages?.firstNotNullOfOrNull { HostApp.fromPackageName(it) }

            try {
                cb.asBinder().linkToDeath(deathRecipient, 0)
            } catch (e: Exception) {
                Logger.e(LOG_TAG, "submit failed linkToDeath error=${e.message}")
                return
            }

            when (host) {
                HostApp.Breeno -> Metrics.takeoverInvoke("breeno")
                HostApp.XiaoAi -> Metrics.takeoverInvoke("xiaoai")
                null -> Unit
            }

            val isIsolated = runBlocking { XRepo.voiceAssistantIsolatedSession() }
            val targetAgent = if (isIsolated) {
                currentHostAgent ?: agentManager.createTaskAgent(isPersistent = false).also {
                    currentHostAgent = it
                }
            } else {
                currentHostAgent?.release()
                currentHostAgent = null
                agentManager.main
            }
            targetAgent.updateDraft { it.copy(text = q, images = emptyList(), files = emptyList()) }
            when (targetAgent.stream()) {
                TurnStart.Busy -> {
                    Logger.i(LOG_TAG, "submit preempting activeTurn isolated=$isIsolated")
                    // 先登记再启动：失败路径会在 job 尾部清 activeTurn，倒序会被它抢先清成空。
                    val job = scope.launch(start = CoroutineStart.LAZY) {
                        if (preemptAndStream(targetAgent, isIsolated)) {
                            executeTurn(cb, targetAgent)
                        } else {
                            if (activeTurn.get()?.callback === cb) activeTurn.set(null)
                            rejectBusy(cb)
                        }
                    }
                    activeTurn.set(ActiveTurn(cb, job, targetAgent))
                    job.start()
                    Logger.i(LOG_TAG, "turn registered preempting=true isolated=$isIsolated")
                    return
                }

                TurnStart.DraftEmpty -> {
                    try {
                        cb.asBinder().unlinkToDeath(deathRecipient, 0)
                    } catch (_: Exception) {
                    }
                    sendError(cb, "Query is blank")
                    return
                }

                TurnStart.Started -> {
                    markHostTurnStarted(targetAgent, isIsolated)
                    Logger.i(
                        LOG_TAG,
                        "targetAgent.stream started successfully isolated=$isIsolated"
                    )
                }
            }

            val job = scope.launch { executeTurn(cb, targetAgent) }
            val turn = ActiveTurn(cb, job, targetAgent)
            activeTurn.set(turn)
            Logger.i(LOG_TAG, "turn registered callbackLinked=true isolated=$isIsolated")
        }

        /** 抢占上一回合：停止并等它真正结束，再重新发起。有界重试兜住 stop 落地的窗口。 */
        private suspend fun preemptAndStream(agent: Agent, isIsolated: Boolean): Boolean {
            val started = preemptPreviousTurn(agent)
            if (started) markHostTurnStarted(agent, isIsolated)
            return started
        }

        private fun rejectBusy(cb: IRenderFrameCallback) {
            try {
                cb.asBinder().unlinkToDeath(deathRecipient, 0)
            } catch (_: Exception) {
            }
            sendError(cb, "Another turn is already in progress")
        }

        private fun markHostTurnStarted(agent: Agent, isIsolated: Boolean) {
            val convId = agent.conversation.value.id?.value ?: if (isIsolated) "host" else ""
            if (convId.isNotBlank()) {
                TurnNotificationManager.markHostTurnStarted(convId)
            }
        }

        override fun cancel() {
            val turn = activeTurn.getAndSet(null)
            if (turn == null) {
                Logger.i(LOG_TAG, "cancel ignored noActiveTurn=true")
                return
            }
            turn.job.cancel()
            Logger.i(LOG_TAG, "cancel requested")
            scope.launch {
                try {
                    turn.agent.stop()
                    Logger.i(LOG_TAG, "cancel done agent.stop completed")
                } catch (_: Exception) {
                }
            }
        }

        override fun resetConversation() {
            val isIsolated = runBlocking { XRepo.voiceAssistantIsolatedSession() }
            if (isIsolated) {
                Logger.i(LOG_TAG, "reset conversation requested by host (isolated mode)")
                currentHostAgent?.release()
                currentHostAgent = null
            } else {
                Logger.i(
                    LOG_TAG,
                    "reset conversation requested by host (ignored to protect shared conversation)"
                )
            }
        }
    }

    private inner class StoreStubImpl : IAgentStoreService.Stub() {
        override fun readStore(storeId: String?): String? {
            if (!validateCaller()) return null
            val id = storeId ?: return null
            val startedAtMs = System.currentTimeMillis()
            val json = runBlocking {
                XIpcStoreRepository.readJson(this@AgentRuntimeService, id)
            }
            Logger.d(
                LOG_TAG,
                "StoreStub.readStore storeId=$id result=${json != null} " +
                        "jsonLength=${json?.length ?: 0} elapsedMs=${System.currentTimeMillis() - startedAtMs}"
            )
            return json
        }

        override fun writeStore(storeId: String?, json: String?) {
            if (!validateCaller()) return
            val id = storeId ?: return
            val j = json ?: return
            val startedAtMs = System.currentTimeMillis()
            runBlocking {
                XIpcStoreRepository.writeJson(this@AgentRuntimeService, id, j)
            }
            Logger.i(
                LOG_TAG,
                "StoreStub.writeStore storeId=$id jsonLength=${j.length} " +
                        "elapsedMs=${System.currentTimeMillis() - startedAtMs}"
            )
        }

        override fun mutateStore(storeId: String?, path: String?, valueJson: String?): String? {
            if (!validateCaller()) return null
            val id = storeId ?: return null
            val p = path ?: return null
            val v = valueJson ?: return null
            val startedAtMs = System.currentTimeMillis()
            val updatedJson = runBlocking {
                XIpcStoreRepository.mutateJson(this@AgentRuntimeService, id, p, v)
            }
            Logger.i(
                LOG_TAG,
                "StoreStub.mutateStore storeId=$id path=$p result=${updatedJson != null} " +
                        "elapsedMs=${System.currentTimeMillis() - startedAtMs}"
            )
            return updatedJson
        }

        override fun postNotification(title: String?, content: String?, uri: String?) {
            if (!validateCaller()) return
            val t = title ?: return
            val c = content ?: return
            postNotificationImpl(t, c, createContentIntent(uri))
        }


        private fun postNotificationImpl(
            title: String,
            content: String,
            contentIntent: PendingIntent?
        ) {
            // 只读查询只经过 PermissionManager 服务；业务方禁止直连原生权限 API（单测扫描兜底）
            if (permissionManager.status(Permission.NOTIFICATION) != PermissionState.GRANTED) return
            ensureNotificationChannel()

            val builder = NotificationCompat.Builder(this@AgentRuntimeService, STORE_CHANNEL_ID)
                .setSmallIcon(resolveSmallIcon())
                .setContentTitle(title)
                .setContentText(content)
                .setStyle(NotificationCompat.BigTextStyle().bigText(content))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setAutoCancel(true)

            contentIntent?.let { builder.setContentIntent(it) }
            NotificationManagerCompat.from(this@AgentRuntimeService).notify(
                notificationId(title, content),
                builder.build()
            )
        }

        private fun ensureNotificationChannel() {
            val manager =
                this@AgentRuntimeService.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                STORE_CHANNEL_ID,
                STORE_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT
            )
            manager.createNotificationChannel(channel)
        }

        // MainActivity is launchMode=singleTask; NEW_TASK reuses the existing task
        // and routes through onNewIntent, so no duplicate activity is created
        private fun createAppLaunchPendingIntent(): PendingIntent? {
            val intent = Intent(this@AgentRuntimeService, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return PendingIntent.getActivity(
                this@AgentRuntimeService,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun createContentIntent(uri: String?): PendingIntent? {
            if (uri.isNullOrBlank()) {
                return null
            }
            val intent = Intent(Intent.ACTION_VIEW, uri.toUri()).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            val resolved =
                this@AgentRuntimeService.packageManager.resolveActivity(intent, 0) ?: return null
            val pendingIntentFlags =
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            return PendingIntent.getActivity(
                this@AgentRuntimeService,
                resolved.activityInfo.packageName.hashCode(),
                intent,
                pendingIntentFlags
            )
        }

        private fun resolveSmallIcon(): Int {
            return this@AgentRuntimeService.applicationInfo.icon.takeIf { it != 0 }
                ?: android.R.drawable.ic_dialog_info
        }

        private fun notificationId(title: String, content: String): Int {
            var result = title.hashCode()
            result = 31 * result + content.hashCode()
            return result
        }
    }

    private suspend fun executeTurn(callback: IRenderFrameCallback, turnAgent: Agent) {
        val startedAtMs = System.currentTimeMillis()
        Logger.i(LOG_TAG, "turn started")
        var firstFrameSent = false
        var lastProjected: HostConversationProjector.ProjectedFrame? = null
        var frameIndex = 0

        val labels = ToolStatusLabels(
            called = getString(AppR.string.ui_tool_status_called),
            running = getString(AppR.string.ui_tool_status_running),
            success = getString(AppR.string.ui_tool_status_success),
            failed = getString(AppR.string.ui_tool_status_failed),
        )

        fun resolveErrorMessage(code: TurnFailureCode?): String = when (code) {
            TurnFailureCode.ConfigRequired -> getString(AppR.string.ui_home_error_config_required_title)
            TurnFailureCode.IdleTimeout -> getString(AppR.string.ui_home_error_idle_timeout_title)
            TurnFailureCode.OutputTruncated ->
                getString(AppR.string.ui_home_error_output_truncated_title)
            TurnFailureCode.Repetition ->
                getString(AppR.string.ui_home_error_repetition_title)

            else -> getString(AppR.string.runtime_error_internal)
        }

        val targetTurnId = turnAgent.conversation.value.turns.lastOrNull()?.id
        Logger.i(LOG_TAG, "executeTurn targetTurnId=$targetTurnId")

        try {
            coroutineScope {
                val conversationJob = launch {
                    turnAgent.conversation.collect { conv ->
                        val turn =
                            conv.turns.find { it.id == targetTurnId } ?: conv.turns.lastOrNull()
                        if (turn != null) {
                            val projected =
                                HostConversationProjector.project(turn, ::resolveErrorMessage)
                            if (projected != lastProjected || !firstFrameSent) {
                                frameIndex++
                                lastProjected = projected
                                val isFirst = !firstFrameSent
                                firstFrameSent = true
                                if (isFirst) {
                                    Logger.i(
                                        LOG_TAG,
                                        "first render frame elapsedMs=${System.currentTimeMillis() - startedAtMs} contentLength=${projected.content.length} thinkingLength=${projected.thinking?.length ?: 0} toolsCount=${projected.tools.size}"
                                    )
                                }
                                sendFrame(
                                    callback,
                                    RenderFrame(
                                        content = projected.content,
                                        thinking = projected.thinking,
                                        isThinkingComplete = projected.isThinkingComplete,
                                        tools = projected.tools,
                                        isFirst = isFirst,
                                        isFinal = false,
                                    ),
                                )
                            }
                        }
                    }
                }

                turnAgent.status
                    .dropWhile { !it.isRunning }
                    .first { !it.isRunning }
                conversationJob.cancel()
            }

            val finalTurn = turnAgent.conversation.value.turns.find { it.id == targetTurnId }
                ?: turnAgent.conversation.value.turns.lastOrNull()
            val finalProjected = if (finalTurn != null) {
                HostConversationProjector.project(finalTurn, ::resolveErrorMessage)
            } else {
                lastProjected ?: HostConversationProjector.ProjectedFrame("")
            }
            Logger.i(
                LOG_TAG,
                "final render frame elapsedMs=${System.currentTimeMillis() - startedAtMs} contentLength=${finalProjected.content.length}"
            )
            sendFrame(
                callback,
                RenderFrame(
                    content = finalProjected.content,
                    thinking = finalProjected.thinking,
                    isThinkingComplete = true,
                    tools = finalProjected.tools,
                    isFirst = !firstFrameSent,
                    isFinal = true,
                ),
            )
            Logger.i(
                LOG_TAG,
                "turn completed elapsedMs=${System.currentTimeMillis() - startedAtMs}"
            )
        } catch (e: CancellationException) {
            Logger.i(
                LOG_TAG,
                "turn cancelled elapsedMs=${System.currentTimeMillis() - startedAtMs}"
            )
            throw e
        } catch (e: Exception) {
            Logger.e(
                LOG_TAG,
                "turn failed elapsedMs=${System.currentTimeMillis() - startedAtMs} " +
                        "errorType=${e::class.simpleName} message=${e.message}"
            )
            sendFrame(
                callback,
                RenderFrame(
                    content = e.message ?: getString(AppR.string.runtime_error_internal),
                    isFirst = !firstFrameSent,
                    isFinal = true,
                ),
            )
        } finally {
            val convId = turnAgent.conversation.value.id?.value ?: ""
            // 抢占时旧回合的收尾晚于新回合的 markHostTurnStarted，无条件清理会抹掉新回合的
            // 宿主标记；只有仍持有 activeTurn 的回合才拥有该标记。
            val isCurrentTurn = activeTurn.get()?.callback === callback
            if (isCurrentTurn && convId.isNotBlank()) {
                TurnNotificationManager.markHostTurnEnded(convId)
            }
            try {
                callback.asBinder().unlinkToDeath(deathRecipient, 0)
            } catch (_: Exception) {
            }
            if (isCurrentTurn) {
                activeTurn.set(null)
            }
        }
    }

    private fun sendFrame(callback: IRenderFrameCallback, frame: RenderFrame) {
        try {
            callback.onFrame(frame)
        } catch (e: DeadObjectException) {
            handleBinderDeath()
        }
    }

    private fun sendError(callback: IRenderFrameCallback, message: String) {
        try {
            callback.onFrame(RenderFrame(content = message, isFirst = true, isFinal = true))
        } catch (_: DeadObjectException) {
        }
    }

    private val deathRecipient = IBinder.DeathRecipient {
        handleBinderDeath()
    }

    private fun handleBinderDeath() {
        val turn = activeTurn.getAndSet(null) ?: return
        turn.job.cancel()
        // TODO: 宿主（如 Breeno）进程被系统强杀时，AMS 解绑导致后台 Service 失去绑定上下文，
        // 进而引发网络套接字受限或级联 Stream interrupted。此问题涉及跨进程服务生命周期与系统级保活架构，后续专门迭代处理。
        Logger.i(LOG_TAG, "binder died, cancelled host frame collector without stopping agent")
    }

    private fun validateCaller(): Boolean {
        val callingUid = Binder.getCallingUid()
        val packages = packageManager.getPackagesForUid(callingUid) ?: return false
        val allowedPackages = setOf(packageName) + HostApp.packageNames.toSet()
        return packages.any { it in allowedPackages }
    }
}

private const val PREEMPT_TAG = "niki914_zafiro_AgentRuntimeService"
private const val PREEMPT_MAX_ATTEMPTS = 3
private const val PREEMPT_STOP_TIMEOUT_MS = 10_000L

/**
 * 停止正在运行的回合并等它真正落地，再重新发起；有界重试兜住 stop 的异步落地窗口。
 *
 * 单独提出是为了可在不依赖 Service 的情况下验证这条重试/取消契约。
 *
 * @return 新回合是否已开始。false = 已耗尽重试或草稿为空，调用方应发回忙错误。
 */
internal suspend fun preemptPreviousTurn(
    agent: Agent,
    maxAttempts: Int = PREEMPT_MAX_ATTEMPTS,
    stopTimeoutMs: Long = PREEMPT_STOP_TIMEOUT_MS,
): Boolean {
    repeat(maxAttempts) { attempt ->
        val stopStartMs = System.currentTimeMillis()
        agent.stop()
        val stopped = withTimeoutOrNull(stopTimeoutMs) {
            agent.status.first { it is AgentState.Idle }
        }
        val stopWaitMs = System.currentTimeMillis() - stopStartMs
        if (stopped == null) {
            Logger.w(
                PREEMPT_TAG,
                "preempt stop timed out attempt=${attempt + 1} stopWaitMs=$stopWaitMs"
            )
            return@repeat
        }
        val streamStartMs = System.currentTimeMillis()
        val result = agent.stream()
        Logger.i(
            PREEMPT_TAG,
            "preempt stage attempt=${attempt + 1} stopWaitMs=$stopWaitMs " +
                    "streamCallMs=${System.currentTimeMillis() - streamStartMs} result=$result"
        )
        when (result) {
            TurnStart.Started -> {
                Logger.i(PREEMPT_TAG, "preempt restart started attempt=${attempt + 1}")
                return true
            }

            TurnStart.Busy -> Logger.w(
                PREEMPT_TAG,
                "preempt restart still busy attempt=${attempt + 1}/$maxAttempts"
            )

            TurnStart.DraftEmpty -> {
                Logger.w(PREEMPT_TAG, "preempt restart draftEmpty=true")
                return false
            }
        }
    }
    Logger.w(PREEMPT_TAG, "preempt exhausted attempts=$maxAttempts")
    return false
}
