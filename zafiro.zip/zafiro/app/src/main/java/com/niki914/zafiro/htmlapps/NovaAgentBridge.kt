package com.niki914.zafiro.htmlapps

import com.niki914.zafiro.api.AgentManager
import com.niki914.zafiro.api.TurnStart
import com.niki914.zafiro.api.model.AgentState
import com.niki914.zafiro.api.model.DraftImage
import com.niki914.zafiro.api.model.TurnBlock
import com.niki914.zafiro.business.files.FileAttachResult
import com.niki914.zafiro.business.files.FilesService
import com.niki914.zafiro.service.findService
import com.niki914.zafiro.service.requireService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Java-friendly façade over the main Zafiro agent for the HtmlApps floating panel.
 *
 * The panel lives in the app process, so it talks to the real agent instead of opening
 * MainActivity. Replies are read from the conversation's text blocks; the coarse status is used
 * for "thinking / tool / approval" lines.
 */
object NovaAgentBridge {

    @JvmStatic
    fun available(): Boolean = findService<AgentManager>() != null

    @JvmStatic
    fun control(): com.niki914.zafiro.api.AgentControl? =
        findService<AgentManager>()?.control

    /** @return started | empty | busy | no_agent */
    @JvmStatic
    fun send(text: String?, imageUri: String?): String {
        val manager = findService<AgentManager>() ?: return "no_agent"
        val agent = manager.main
        if (agent.status.value !is AgentState.Idle) return "busy"
        val value = text?.trim().orEmpty()
        val image = imageUri?.trim().orEmpty()
        if (value.isEmpty() && image.isEmpty()) return "empty"
        agent.updateDraft { draft ->
            draft.copy(
                text = value,
                images = if (image.isEmpty()) draft.images
                else draft.images + DraftImage.Pending(image),
            )
        }
        return when (agent.stream()) {
            TurnStart.Started -> "started"
            TurnStart.DraftEmpty -> "empty"
            TurnStart.Busy -> "busy"
        }
    }

    @JvmStatic
    fun stop() {
        findService<AgentManager>()?.main?.stop()
    }

    /** Starts a fresh conversation in the panel without opening the Zafiro UI. */
    @JvmStatic
    fun newConversation(): Boolean {
        val manager = findService<AgentManager>() ?: return false
        manager.startNewConversation()
        return true
    }

    interface ResultCallback {
        fun onResult(result: String)
    }

    /**
     * Resolves a SAF URI into a file reference first; used by the panel's "any file" import.
     * The callback is delivered on the main thread.
     */
    @JvmStatic
    fun sendFileAsync(text: String?, fileUri: String?, callback: ResultCallback) {
        val manager = findService<AgentManager>()
        if (manager == null) {
            callback.onResult("no_agent")
            return
        }
        val agent = manager.main
        if (agent.status.value !is AgentState.Idle) {
            callback.onResult("busy")
            return
        }
        val uri = fileUri?.trim().orEmpty()
        if (uri.isEmpty()) {
            callback.onResult("empty")
            return
        }
        val value = text?.trim().orEmpty()
        CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate).launch {
            val result = runCatching { requireService<FilesService>().attach(uri) }.getOrNull()
            if (result !is FileAttachResult.Ok) {
                callback.onResult("unreadable")
                return@launch
            }
            agent.updateDraft { draft ->
                draft.copy(text = value, files = draft.files + result.file)
            }
            callback.onResult(
                when (agent.stream()) {
                    TurnStart.Started -> "started"
                    TurnStart.DraftEmpty -> "empty"
                    TurnStart.Busy -> "busy"
                },
            )
        }
    }

    @JvmStatic
    fun isRunning(): Boolean {
        val agent = findService<AgentManager>()?.main ?: return false
        return agent.status.value !is AgentState.Idle
    }

    /** Full text of the latest turn's answer blocks (streaming included). */
    @JvmStatic
    fun replyText(): String {
        val agent = findService<AgentManager>()?.main ?: return ""
        val turn = agent.conversation.value.turns.lastOrNull() ?: return ""
        val text = turn.blocks
            .filterIsInstance<TurnBlock.Text>()
            .joinToString("\n\n") { it.text }
            .trim()
        if (text.isNotEmpty()) return plainText(text)
        val failure = turn.blocks.filterIsInstance<TurnBlock.Failure>().lastOrNull()
        if (failure != null) {
            val reason = failure.message?.takeIf { it.isNotBlank() }
                ?: failure.code?.name
                ?: "yanıt üretilemedi"
            return "⚠ $reason"
        }
        return ""
    }

    /**
     * The dialogue as shown in the panel: user line + assistant answer for the last turns.
     * The panel scrolls, so the whole answer stays readable.
     */
    @JvmStatic
    fun transcriptText(): String {
        val agent = findService<AgentManager>()?.main ?: return ""
        val turns = agent.conversation.value.turns
        if (turns.isEmpty()) return ""
        val builder = StringBuilder()
        for (turn in turns.takeLast(20)) {
            val user = turn.userText.trim()
            if (user.isNotEmpty()) {
                builder.append("🧑 ").append(user).append('\n')
            }
            val answer = turn.blocks
                .filterIsInstance<TurnBlock.Text>()
                .joinToString("\n") { it.text }
                .trim()
            if (answer.isNotEmpty()) {
                builder.append("✦ ").append(plainText(answer))
            } else {
                val failure = turn.blocks.filterIsInstance<TurnBlock.Failure>().lastOrNull()
                if (failure != null) {
                    val reason = failure.message?.takeIf { it.isNotBlank() }
                        ?: failure.code?.name
                        ?: "yanıt üretilemedi"
                    builder.append("⚠ ").append(reason)
                }
            }
            builder.append("\n\n")
        }
        return builder.toString().trim()
    }

    /** One-line status for the panel while no answer text exists yet. */
    @JvmStatic
    fun statusText(): String {
        val agent = findService<AgentManager>()?.main ?: return "Zafiro ajanı hazır değil"
        return when (val status = agent.status.value) {
            is AgentState.Generating -> status.text?.takeIf { it.isNotBlank() } ?: "Yazıyor…"
            is AgentState.Thinking -> "🧠 " + (status.text?.takeIf { it.isNotBlank() } ?: "Düşünüyor…")
            is AgentState.ToolRunning -> "🔧 " + status.label
            is AgentState.WaitingApproval -> "⚠ Onay bekliyor…"
            AgentState.Stopping -> "Durduruluyor…"
            is AgentState.Idle -> status.lastText?.takeIf { it.isNotBlank() } ?: "Hazır"
        }
    }

    /** True when the answer is complete (Idle) — the panel can then keep the text. */
    @JvmStatic
    fun isIdle(): Boolean {
        val agent = findService<AgentManager>()?.main ?: return true
        return agent.status.value is AgentState.Idle
    }

    /** The panel is a plain TextView; strip the markdown markers that would show as noise. */
    private fun plainText(source: String): String {
        var text = source
        text = text.replace(Regex("```[a-zA-Z0-9_+-]*\\n?"), "")
        text = text.replace("```", "")
        text = text.replace(Regex("`([^`\\n]*)`"), "$1")
        text = text.replace(Regex("\\*\\*(.+?)\\*\\*"), "$1")
        text = text.replace(Regex("__(.+?)__"), "$1")
        text = text.replace(Regex("(?<!\\*)\\*([^*\\n]+)\\*(?!\\*)"), "$1")
        text = text.replace(Regex("(?m)^#{1,6}\\s*"), "")
        text = text.replace(Regex("(?m)^\\s*[-*+]\\s+"), "• ")
        text = text.replace(Regex("~~(.+?)~~"), "$1")
        return text.trim()
    }
}
