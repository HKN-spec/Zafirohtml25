package com.niki914.zafiro.htmlapps.floating;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

/**
 * Restarts the HtmlApps floating panel after boot, package update or user unlock.
 * The overlay can be removed by the system while the phone is locked; this brings it back
 * even when the app process was not alive.
 */
public class HtmlAppsPanelRestartReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;
        if (!HtmlAppsFloatingButtonService.isEnabled(context)) return;
        if (!Settings.canDrawOverlays(context)) return;
        Intent service = new Intent(context, HtmlAppsFloatingButtonService.class);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(service);
            } else {
                context.startService(service);
            }
        } catch (Exception e) {
            try {
                context.startService(service);
            } catch (Exception ignored) {
            }
        }
    }
}
