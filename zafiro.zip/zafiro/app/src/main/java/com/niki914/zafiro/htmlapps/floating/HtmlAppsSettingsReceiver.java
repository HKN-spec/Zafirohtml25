package com.niki914.zafiro.htmlapps.floating;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;

import com.niki914.zafiro.app.MainActivity;
import com.niki914.zafiro.htmlapps.NovaAgentBridge;
import com.niki914.zafiro.htmlapps.library.HtmlAppsLibraryActivity;

/**
 * Natural-language control surface for the floating panel.
 *
 * The agent's htmlapps_settings builtin broadcasts one setting per call. Colours accept #RRGGBB
 * (and a few Turkish names); numeric values are integers; booleans are true/false.
 */
public class HtmlAppsSettingsReceiver extends BroadcastReceiver {

    public static final String ACTION = "com.niki914.zafiro.htmlapps.SETTINGS";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null || !ACTION.equals(intent.getAction())) return;
        String setting = intent.getStringExtra("setting");
        String value = intent.getStringExtra("value");
        int alpha = intent.getIntExtra("alpha", -1);
        if (setting == null) return;
        switch (setting) {
            case "bubble_color": {
                int color = parseColor(value, HtmlAppsFloatStyle.bubbleColor(context));
                int a = alpha >= 0 ? alpha : HtmlAppsFloatStyle.bubbleAlpha(context);
                if (a == 0) a = 180;
                HtmlAppsFloatStyle.setBubble(context, color, a);
                refresh(context);
                break;
            }
            case "panel_color": {
                int color = parseColor(value, HtmlAppsFloatStyle.panelColor(context));
                int a = alpha >= 0 ? alpha : HtmlAppsFloatStyle.panelAlpha(context);
                if (a == 0) a = 242;
                HtmlAppsFloatStyle.setPanel(context, color, a);
                refresh(context);
                break;
            }
            case "text_color": {
                int color = parseColor(value, HtmlAppsFloatStyle.textColor(context));
                int a = alpha >= 0 ? alpha : HtmlAppsFloatStyle.textAlpha(context);
                HtmlAppsFloatStyle.setTextColor(context, color, a);
                refresh(context);
                break;
            }
            case "bubble_alpha":
                HtmlAppsFloatStyle.setBubble(context, HtmlAppsFloatStyle.bubbleColor(context),
                        number(value, HtmlAppsFloatStyle.bubbleAlpha(context)));
                refresh(context);
                break;
            case "panel_alpha":
                HtmlAppsFloatStyle.setPanel(context, HtmlAppsFloatStyle.panelColor(context),
                        number(value, HtmlAppsFloatStyle.panelAlpha(context)));
                refresh(context);
                break;
            case "text_alpha":
                HtmlAppsFloatStyle.setTextColor(context, HtmlAppsFloatStyle.textColor(context),
                        number(value, HtmlAppsFloatStyle.textAlpha(context)));
                refresh(context);
                break;
            case "font_size":
                HtmlAppsFloatStyle.setFontSize(context,
                        number(value, HtmlAppsFloatStyle.fontSize(context)));
                refresh(context);
                break;
            case "edge_fade":
                HtmlAppsFloatStyle.setEdgeFade(context,
                        number(value, HtmlAppsFloatStyle.edgeFade(context)));
                refresh(context);
                break;
            case "auto_open":
                HtmlAppsFloatStyle.setAutoOpen(context, bool(value,
                        HtmlAppsFloatStyle.autoOpen(context)));
                break;
            case "reply_position":
                HtmlAppsFloatStyle.setReplyTop(context,
                        "top".equalsIgnoreCase(value == null ? "" : value.trim()));
                HtmlAppsFloatingButtonService.rebuildPanel(context);
                break;
            case "panel_enabled":
                HtmlAppsFloatingButtonService.setEnabled(context,
                        bool(value, HtmlAppsFloatingButtonService.isEnabled(context)));
                break;
            case "show_panel":
                HtmlAppsFloatingButtonService.showPanel(context);
                break;
            case "hide_panel":
                HtmlAppsFloatingButtonService.hidePanel(context);
                break;
            case "new_chat":
                NovaAgentBridge.newConversation();
                HtmlAppsFloatingButtonService.showPanel(context);
                break;
            case "open_library":
                try {
                    context.startActivity(new Intent(context, HtmlAppsLibraryActivity.class)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } catch (Exception ignored) {
                }
                break;
            case "open_app":
                try {
                    context.startActivity(new Intent(context, MainActivity.class)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                    | Intent.FLAG_ACTIVITY_CLEAR_TOP));
                } catch (Exception ignored) {
                }
                break;
            default:
                break;
        }
    }

    private static void refresh(Context context) {
        HtmlAppsFloatingButtonService.refreshStyle(context);
    }

    private static int number(String value, int fallback) {
        try {
            return Math.round(Float.parseFloat(value.trim()));
        } catch (Exception e) {
            return fallback;
        }
    }

    private static boolean bool(String value, boolean fallback) {
        if (value == null) return fallback;
        String clean = value.trim();
        if ("true".equalsIgnoreCase(clean) || "1".equals(clean)
                || "on".equalsIgnoreCase(clean) || "aç".equalsIgnoreCase(clean)) {
            return true;
        }
        if ("false".equalsIgnoreCase(clean) || "0".equals(clean)
                || "off".equalsIgnoreCase(clean) || "kapat".equalsIgnoreCase(clean)) {
            return false;
        }
        return fallback;
    }

    private static int parseColor(String value, int fallback) {
        if (value == null) return fallback;
        String clean = value.trim();
        if ("kırmızı".equalsIgnoreCase(clean)) return 0xFFF44336;
        if ("yeşil".equalsIgnoreCase(clean)) return 0xFF4CAF50;
        if ("mavi".equalsIgnoreCase(clean)) return 0xFF3D6BFF;
        if ("sarı".equalsIgnoreCase(clean)) return 0xFFFFD166;
        if ("turuncu".equalsIgnoreCase(clean)) return 0xFFFF9F0A;
        if ("mor".equalsIgnoreCase(clean)) return 0xFFBF5AF2;
        if ("beyaz".equalsIgnoreCase(clean)) return 0xFFFFFFFF;
        if ("siyah".equalsIgnoreCase(clean)) return 0xFF111111;
        try {
            return Color.parseColor(clean);
        } catch (Exception e) {
            return fallback;
        }
    }
}
