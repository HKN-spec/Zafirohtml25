package com.niki914.zafiro.repo

import android.content.Context
import com.niki914.zafiro.app.R
import com.niki914.zafiro.settings.model.RuntimeExecutionRule
import com.niki914.zafiro.settings.model.RuntimeExecutionRuleEnabledMode
import com.niki914.zafiro.settings.model.RuntimeMaskingRule

internal object LocalSettingsDefaults {
    const val DEFAULT_SYSTEM_PROMPT = ""

    /** 内置安全规则 id；onboarding 配置页保存时复用同一 id，两条默认互相覆盖。 */
    const val DEFAULT_EXECUTION_RULE_ID = "builtin-dangerous"

    /** 内置规则与 onboarding 配置页的默认规则共用同一显示名。 */
    const val DEFAULT_EXECUTION_RULE_NAME = "default"

    const val DEFAULT_MASKING_RULE_ID = "builtin-default"
    const val DEFAULT_MASKING_RULE_NAME = "default"

    /**
     * 内置默认规则。onboarding 配置页以它的 patterns 为初值（可删减），
     * 因此这里必须只有一条——多出来的规则不会出现在那个页面上。
     */
    val defaultExecutionRule: RuntimeExecutionRule
        get() = defaultExecutionRules.first()

    /** 默认规则的命中条目；onboarding 页初值与首次 seed 共用同一份。 */
    val defaultExecutionPatterns: List<String>
        get() = defaultExecutionRule.patterns

    // Seed memories live in res/raw/seed_memories.txt，一行一条（与 seed_py_*.py 同一模式）。
    fun defaultMemories(context: Context): List<String> {
        val text = context.resources.openRawResource(R.raw.seed_memories)
            .bufferedReader().use { it.readText() }
        return text.lines().map(String::trim).filter(String::isNotEmpty)
    }

    val defaultExecutionRules = listOf(
        RuntimeExecutionRule(
            id = DEFAULT_EXECUTION_RULE_ID,
            name = DEFAULT_EXECUTION_RULE_NAME,
            enabledMode = RuntimeExecutionRuleEnabledMode.CONFIRM,
            patterns = listOf(
                // 危险删改
                "\\brm\\s+-rf\\b",
                "\\brm\\s+-(?=[^\\s]*r)(?=[^\\s]*f)[^\\s]*\\b",
                "\\brm\\s+-r\\s+-f\\b",
                "\\brm\\s+(?=[^\\n]*--recursive\\b)(?=[^\\n]*--force\\b)[^\\n]*",
                "\\brm\\s+(?=[^\\n]*-(?:[^\\s-]*r[^\\s-]*|-[^-\\s]*recursive)\\b)(?=[^\\n]*-(?:[^\\s-]*f[^\\s-]*|-[^-\\s]*force)\\b)[^\\n]*",
                "\\bmkfs\\b",
                // 卸载相关
                "\\bpm\\s+uninstall\\b",
                "\\bcmd\\s+package\\s+uninstall\\b",
                // 高危提权
                "\\bsu\\b",
                "\\bsetprop\\b",
                "\\bdd\\b",
                "\\breboot\\b",
            ),
        ),
    )

    val defaultMaskingRules = listOf(
        RuntimeMaskingRule(
            id = DEFAULT_MASKING_RULE_ID,
            name = DEFAULT_MASKING_RULE_NAME,
            enabled = true,
            kind = "API_KEY",
            patterns = listOf(
                """\bsk-[a-zA-Z0-9_\-]{20,}\b""",
            ),
        ),
    )
}
