package com.niki914.zafiro.htmlapps.floating;

import android.Manifest;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;
import java.util.Locale;

/**
 * One-shot speech-to-text for the HtmlApps floating panel.
 *
 * The panel's microphone button starts listening; partial results fill the input live and the
 * final result stops the recognizer. No always-on microphone, so the red/green state is honest.
 */
public class HtmlAppsSpeech {

    public interface Listener {
        void onText(String text, boolean finalResult);

        void onState(boolean listening);

        void onError(String message);
    }

    private final Service service;
    private final Listener listener;
    private SpeechRecognizer recognizer;
    private boolean listening;

    public HtmlAppsSpeech(Service service, Listener listener) {
        this.service = service;
        this.listener = listener;
    }

    public boolean isListening() {
        return listening;
    }

    public void start() {
        if (service.checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            listener.onError("Mikrofon izni gerekli");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(service)) {
            listener.onError("Cihazda konuşma tanıma yok");
            return;
        }
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(service);
                recognizer.setRecognitionListener(recognitionListener);
            }
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag());
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            listening = true;
            listener.onState(true);
            recognizer.startListening(intent);
        } catch (Exception e) {
            listening = false;
            listener.onState(false);
            listener.onError("Mikrofon başlatılamadı");
        }
    }

    public void stop() {
        listening = false;
        if (recognizer != null) {
            try {
                recognizer.stopListening();
            } catch (Exception ignored) {
            }
        }
        listener.onState(false);
    }

    public void destroy() {
        listening = false;
        if (recognizer != null) {
            try {
                recognizer.destroy();
            } catch (Exception ignored) {
            }
            recognizer = null;
        }
    }

    private final RecognitionListener recognitionListener = new RecognitionListener() {
        @Override
        public void onReadyForSpeech(Bundle params) {
        }

        @Override
        public void onBeginningOfSpeech() {
        }

        @Override
        public void onRmsChanged(float rmsdB) {
        }

        @Override
        public void onBufferReceived(byte[] buffer) {
        }

        @Override
        public void onEndOfSpeech() {
        }

        @Override
        public void onError(int error) {
            listening = false;
            listener.onState(false);
            String message;
            switch (error) {
                case SpeechRecognizer.ERROR_NO_MATCH:
                    message = "Söyleneni anlayamadım";
                    break;
                case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                    message = "Ses duyulmadı";
                    break;
                case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                    message = "Mikrofon izni yok";
                    break;
                case SpeechRecognizer.ERROR_NETWORK:
                case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                    message = "Konuşma tanıma için ağ gerekli";
                    break;
                default:
                    message = "Konuşma tanıma hatası";
                    break;
            }
            listener.onError(message);
        }

        @Override
        public void onResults(Bundle results) {
            listening = false;
            listener.onState(false);
            String text = firstResult(results);
            if (text != null) listener.onText(text, true);
        }

        @Override
        public void onPartialResults(Bundle partialResults) {
            String text = firstResult(partialResults);
            if (text != null) listener.onText(text, false);
        }

        @Override
        public void onEvent(int eventType, Bundle params) {
        }
    };

    private static String firstResult(Bundle bundle) {
        if (bundle == null) return null;
        ArrayList<String> matches = bundle.getStringArrayList(
                SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches == null || matches.isEmpty()) return null;
        String best = matches.get(0);
        return best == null || best.trim().isEmpty() ? null : best.trim();
    }
}
