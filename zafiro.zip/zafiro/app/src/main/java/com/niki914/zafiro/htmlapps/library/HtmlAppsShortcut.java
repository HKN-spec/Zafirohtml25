package com.niki914.zafiro.htmlapps.library;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Icon;
import android.os.Build;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Pins a launcher shortcut that opens the in-app HtmlApps viewer with a target folder.
 *
 * requestPinShortcut asks the launcher for confirmation and is the documented path; when the
 * launcher refuses (or is older than API 26) a dynamic shortcut is added instead so the action is
 * never silently lost.
 */
public final class HtmlAppsShortcut {

    public static final String ACTION_PIN = "com.niki914.zafiro.htmlapps.SHORTCUT_PIN";
    private static final String HTMLAPPS_PKG = "com.htmlruntime";
    private static final String HTMLAPPS_MAIN = "com.htmlruntime.MainActivity";
    private static final String HTMLAPPS_LAUNCH = "com.htmlruntime.LAUNCH_APP";

    private HtmlAppsShortcut() {
    }

    public static boolean register(Context ctx, String folder, String appName, File iconFile) {
        return register(ctx, folder, appName, iconFile, null);
    }

    public static boolean register(Context ctx, String folder, String appName, File iconFile,
                                   PendingIntent callback) {
        if (Build.VERSION.SDK_INT < 25) return false;
        ShortcutManager manager = ctx.getSystemService(ShortcutManager.class);
        if (manager == null) return false;

        Intent launch = launchIntent(ctx, folder);

        ShortcutInfo info;
        try {
            info = new ShortcutInfo.Builder(ctx, shortcutId(folder))
                    .setShortLabel(shortLabel(appName))
                    .setLongLabel(appName == null ? folder : appName)
                    .setIcon(icon(ctx, iconFile))
                    .setIntent(launch)
                    .build();
        } catch (Exception e) {
            return false;
        }

        try {
            if (manager.isRequestPinShortcutSupported()) {
                boolean requested = manager.requestPinShortcut(info, callback == null
                        ? null : callback.getIntentSender());
                if (requested) return true;
            }
        } catch (Exception ignored) {
        }
        // Do NOT fall back to a dynamic shortcut: launchers badge those with the Zafiro app
        // icon in the corner, which is exactly what the user asked us to avoid.
        return false;
    }

    /** Opens an app in the full HtmlApps runtime when it is installed, else in the fallback viewer. */
    public static void launch(Context ctx, String folder) {
        try {
            Intent intent = launchIntent(ctx, folder);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            ctx.startActivity(intent);
        } catch (Exception ignored) {
        }
    }

    private static Intent launchIntent(Context ctx, String folder) {
        if (isHtmlAppsInstalled(ctx)) {
            Intent launch = new Intent(HTMLAPPS_LAUNCH);
            launch.setClassName(HTMLAPPS_PKG, HTMLAPPS_MAIN);
            launch.putExtra("target_folder", folder);
            return launch;
        }
        Intent launch = new Intent(ctx, HtmlAppsViewerActivity.class);
        launch.setAction(Intent.ACTION_VIEW);
        launch.putExtra(HtmlAppsViewerActivity.EXTRA_FOLDER, folder);
        return launch;
    }

    public static boolean isHtmlAppsInstalled(Context context) {
        try {
            context.getPackageManager().getPackageInfo(HTMLAPPS_PKG, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static void removeDynamic(Context ctx, String folder) {
        try {
            ShortcutManager manager = ctx.getSystemService(ShortcutManager.class);
            if (manager == null) return;
            List<ShortcutInfo> keep = new ArrayList<>();
            for (ShortcutInfo shortcut : manager.getDynamicShortcuts()) {
                if (!shortcut.getId().equals(shortcutId(folder))) keep.add(shortcut);
            }
            manager.setDynamicShortcuts(keep);
        } catch (Exception ignored) {
        }
    }

    private static boolean addDynamic(ShortcutManager manager, ShortcutInfo info) {
        try {
            int max = Math.max(1, manager.getMaxShortcutCountPerActivity());
            List<ShortcutInfo> list = new ArrayList<>();
            list.add(info);
            for (ShortcutInfo existing : manager.getDynamicShortcuts()) {
                if (!existing.getId().equals(info.getId()) && list.size() < max) {
                    list.add(existing);
                }
            }
            return manager.setDynamicShortcuts(list);
        } catch (Exception e) {
            return false;
        }
    }

    private static String shortcutId(String folder) {
        return "htmlapps_" + folder;
    }

    private static String shortLabel(String name) {
        if (name == null || name.trim().isEmpty()) return "Uygulama";
        String value = name.trim();
        return value.length() <= 12 ? value : value.substring(0, 11) + "…";
    }

    private static Icon icon(Context ctx, File iconFile) {
        if (iconFile != null && iconFile.isFile()) {
            Bitmap bitmap = BitmapFactory.decodeFile(iconFile.getAbsolutePath());
            if (bitmap != null) {
                try {
                    return Icon.createWithBitmap(Bitmap.createScaledBitmap(bitmap, 192, 192, true));
                } catch (Exception ignored) {
                }
            }
        }
        return Icon.createWithResource(ctx, android.R.drawable.sym_def_app_icon);
    }
}
