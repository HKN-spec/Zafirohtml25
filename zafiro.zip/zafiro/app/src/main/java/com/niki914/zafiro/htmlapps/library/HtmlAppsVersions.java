package com.niki914.zafiro.htmlapps.library;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Per-app version history under {@code <app>/.versions/}.
 *
 * index.json lists the versions; each version is a full HTML snapshot, so a restore never depends
 * on a diff chain. The library skips dot folders, so history never shows up as an app.
 */
public class HtmlAppsVersions {

    public static class Version {
        public int index;
        public String timestamp;
        public String note;
        public String file;
        public long size;
    }

    private static final String DIR = ".versions";
    private static final String INDEX = "index.json";

    private final File appDir;

    public HtmlAppsVersions(File appDir) {
        this.appDir = appDir;
    }

    private File versionsDir() {
        File dir = new File(appDir, DIR);
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private File indexPath() {
        return new File(versionsDir(), INDEX);
    }

    public JSONArray loadIndex() {
        try {
            File file = indexPath();
            if (!file.isFile()) return new JSONArray();
            return new JSONArray(readText(file));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private void saveIndex(JSONArray index) throws IOException {
        try (FileOutputStream out = new FileOutputStream(indexPath())) {
            out.write(index.toString().getBytes(StandardCharsets.UTF_8));
        }
    }

    /** Snapshots the current index.html; returns null when there is nothing to save. */
    public Version snapshot(String note) throws IOException {
        File index = new File(appDir, "index.html");
        if (!index.isFile()) return null;
        String html = readText(index);
        if (html == null || html.isEmpty()) return null;
        JSONArray entries = loadIndex();
        Version version = new Version();
        version.index = entries.length() + 1;
        version.timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                .format(new Date());
        version.note = note == null ? "" : note;
        version.file = "v" + String.format(Locale.US, "%03d", version.index) + "_"
                + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".html";
        version.size = html.length();
        try (FileOutputStream out = new FileOutputStream(new File(versionsDir(), version.file))) {
            out.write(html.getBytes(StandardCharsets.UTF_8));
        }
        try {
            JSONObject entry = new JSONObject();
            entry.put("index", version.index);
            entry.put("timestamp", version.timestamp);
            entry.put("note", version.note);
            entry.put("file", version.file);
            entry.put("size", version.size);
            entries.put(entry);
            saveIndex(entries);
        } catch (Exception e) {
            throw new IOException("Sürüm dizini yazılamadı: " + e.getMessage(), e);
        }
        return version;
    }

    public String loadHtml(int index) throws IOException {
        JSONArray entries = loadIndex();
        for (int i = 0; i < entries.length(); i++) {
            JSONObject entry = entries.optJSONObject(i);
            if (entry != null && entry.optInt("index") == index) {
                File file = new File(versionsDir(), entry.optString("file", ""));
                if (file.isFile()) return readText(file);
            }
        }
        return null;
    }

    public List<Version> list() {
        List<Version> out = new ArrayList<>();
        JSONArray entries = loadIndex();
        for (int i = entries.length() - 1; i >= 0; i--) {
            JSONObject entry = entries.optJSONObject(i);
            if (entry == null) continue;
            Version version = new Version();
            version.index = entry.optInt("index", 0);
            version.timestamp = entry.optString("timestamp", "");
            version.note = entry.optString("note", "");
            version.file = entry.optString("file", "");
            version.size = entry.optLong("size", 0);
            out.add(version);
        }
        return out;
    }

    /** Restores a snapshot, first keeping the current document as a new version. */
    public boolean restore(int index, String note) throws IOException {
        File current = new File(appDir, "index.html");
        if (current.isFile()) snapshot(note == null ? "Geri yükleme öncesi" : note);
        String html = loadHtml(index);
        if (html == null) return false;
        try (FileOutputStream out = new FileOutputStream(current)) {
            out.write(html.getBytes(StandardCharsets.UTF_8));
        }
        HtmlAppsMeta meta = HtmlAppsMeta.load(appDir);
        meta.lastUsedAt = System.currentTimeMillis();
        meta.save(appDir);
        return true;
    }

    private static String readText(File file) throws IOException {
        try (FileInputStream in = new FileInputStream(file)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) > 0) out.write(buffer, 0, read);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
