package com.niki914.zafiro.htmlapps.floating;

import android.Manifest;
import android.app.Service;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.graphics.YuvImage;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Live camera preview for the HtmlApps floating panel.
 *
 * Uses the platform camera API (no extra dependency): a TextureView shows the preview, a tap
 * captures a JPEG into the app cache and hands a FileProvider URI to the panel, which attaches it
 * to the next agent prompt.
 */
public class HtmlAppsLiveCamera implements TextureView.SurfaceTextureListener, Camera.PreviewCallback {

    public interface Listener {
        void onCaptured(String uri);

        void onError(String message);
    }

    private final Service service;
    private final FrameLayout host;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private TextureView textureView;
    private Camera camera;
    private int cameraId = 0;
    private int previewWidth;
    private int previewHeight;
    private int previewFormat;
    private int jpegRotation;
    private ExecutorService frameExecutor;
    private volatile String latestFrameUri;
    private volatile long latestFrameAt;
    private volatile boolean frameBusy;

    public HtmlAppsLiveCamera(Service service, FrameLayout host, Listener listener) {
        this.service = service;
        this.host = host;
        this.listener = listener;
    }

    public boolean isOpen() {
        return camera != null;
    }

    public void start() {
        if (service.checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            listener.onError("Kamera izni gerekli");
            return;
        }
        host.setVisibility(ViewGroup.VISIBLE);
        if (textureView == null) {
            textureView = new TextureView(service);
            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            params.gravity = Gravity.CENTER;
            textureView.setLayoutParams(params);
            textureView.setSurfaceTextureListener(this);
            host.addView(textureView);
        } else if (textureView.isAvailable()) {
            openCamera(textureView.getSurfaceTexture());
        }
    }

    public void stop() {
        releaseCamera();
        host.setVisibility(ViewGroup.GONE);
        if (textureView != null) {
            try {
                textureView.setSurfaceTextureListener(null);
                host.removeView(textureView);
            } catch (Exception ignored) {
            }
            textureView = null;
        }
    }

    public boolean hasRecentFrame() {
        return latestFrameUri != null
                && System.currentTimeMillis() - latestFrameAt < 3000;
    }

    public String latestFrameUri() {
        return latestFrameUri;
    }

    @Override
    public void onPreviewFrame(byte[] data, Camera cam) {
        if (data == null || cam == null) return;
        long now = System.currentTimeMillis();
        if (frameBusy || now - latestFrameAt < 900) {
            try {
                cam.addCallbackBuffer(data);
            } catch (Exception ignored) {
            }
            return;
        }
        frameBusy = true;
        final byte[] buffer = data;
        final byte[] copy = Arrays.copyOf(data, data.length);
        final int width = previewWidth;
        final int height = previewHeight;
        final int format = previewFormat;
        final int rotation = jpegRotation;
        ExecutorService executor = frameExecutor;
        if (executor == null) {
            frameBusy = false;
            try {
                cam.addCallbackBuffer(buffer);
            } catch (Exception ignored) {
            }
            return;
        }
        executor.execute(() -> {
            try {
                ByteArrayOutputStream jpeg = new ByteArrayOutputStream();
                YuvImage yuv = new YuvImage(copy, format, width, height, null);
                yuv.compressToJpeg(new Rect(0, 0, width, height), 60, jpeg);
                byte[] bytes = jpeg.toByteArray();
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bitmap != null) {
                    if (rotation != 0) {
                        Matrix matrix = new Matrix();
                        matrix.postRotate(rotation);
                        Bitmap rotated = Bitmap.createBitmap(bitmap, 0, 0,
                                bitmap.getWidth(), bitmap.getHeight(), matrix, true);
                        bitmap.recycle();
                        bitmap = rotated;
                    }
                    String uri = saveBitmap(bitmap, "frame_");
                    if (uri != null) {
                        latestFrameUri = uri;
                        latestFrameAt = System.currentTimeMillis();
                    }
                    bitmap.recycle();
                }
            } catch (Exception ignored) {
            } finally {
                frameBusy = false;
                main.post(() -> {
                    try {
                        if (cam != null) cam.addCallbackBuffer(buffer);
                    } catch (Exception ignored) {
                    }
                });
            }
        });
    }

    private String saveBitmap(Bitmap bitmap, String prefix) {
        try {
            File dir = new File(service.getCacheDir(), "capture");
            if (!dir.isDirectory() && !dir.mkdirs()) return null;
            File file = new File(dir, prefix + System.currentTimeMillis() + ".jpg");
            try (FileOutputStream out = new FileOutputStream(file)) {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 65, out);
            }
            pruneFrames(dir);
            Uri uri = FileProvider.getUriForFile(service,
                    service.getPackageName() + ".fileprovider", file);
            return uri.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private void pruneFrames(File dir) {
        try {
            File[] files = dir.listFiles((d, name) -> name.startsWith("frame_"));
            if (files == null || files.length <= 4) return;
            Arrays.sort(files, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
            for (int i = 0; i < files.length - 4; i++) files[i].delete();
        } catch (Exception ignored) {
        }
    }

    public void capture() {
        final Camera active = camera;
        if (active == null) {
            listener.onError("Kamera hazır değil");
            return;
        }
        try {
            active.takePicture(null, null, (data, cam) -> {
                String uri = save(data);
                if (uri == null) {
                    main.post(() -> listener.onError("Fotoğraf kaydedilemedi"));
                } else {
                    main.post(() -> listener.onCaptured(uri));
                }
                main.post(() -> {
                    try {
                        cam.startPreview();
                    } catch (Exception ignored) {
                    }
                });
            });
        } catch (Exception e) {
            listener.onError("Fotoğraf çekilemedi");
        }
    }

    private String save(byte[] data) {
        try {
            File dir = new File(service.getCacheDir(), "capture");
            if (!dir.isDirectory() && !dir.mkdirs()) return null;
            File file = new File(dir, "panel_" + System.currentTimeMillis() + ".jpg");
            try (FileOutputStream out = new FileOutputStream(file)) {
                out.write(data);
            }
            Uri uri = FileProvider.getUriForFile(service,
                    service.getPackageName() + ".fileprovider", file);
            return uri.toString();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
        openCamera(surface);
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
        applyPreviewLayout();
    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
        releaseCamera();
        return true;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture surface) {
    }

    private void openCamera(SurfaceTexture surface) {
        if (camera != null || surface == null) return;
        try {
            camera = Camera.open(cameraId);
            if (camera == null) {
                listener.onError("Kamera açılamadı");
                return;
            }
            Camera.Parameters parameters = camera.getParameters();
            Camera.Size size = bestSize(parameters.getSupportedPreviewSizes());
            if (size != null) {
                parameters.setPreviewSize(size.width, size.height);
                previewWidth = size.width;
                previewHeight = size.height;
            }
            parameters.setPictureFormat(ImageFormat.JPEG);
            // Rotate the captured JPEG upright; without this the photo is 90° sideways.
            jpegRotation = displayOrientation();
            parameters.setRotation(jpegRotation);
            previewFormat = parameters.getPreviewFormat();
            List<String> focusModes = parameters.getSupportedFocusModes();
            if (focusModes != null
                    && focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            }
            camera.setParameters(parameters);
            camera.setDisplayOrientation(displayOrientation());
            camera.setPreviewTexture(surface);
            camera.startPreview();
            applyPreviewLayout();
            startFrameStream();
        } catch (Exception e) {
            releaseCamera();
            listener.onError("Kamera açılamadı: " + e.getMessage());
        }
    }

    private void startFrameStream() {
        if (camera == null || previewWidth <= 0 || previewHeight <= 0) return;
        try {
            frameExecutor = Executors.newSingleThreadExecutor();
            int bits = ImageFormat.getBitsPerPixel(previewFormat);
            if (bits <= 0) bits = 12;
            int bufferSize = previewWidth * previewHeight * bits / 8;
            for (int i = 0; i < 3; i++) camera.addCallbackBuffer(new byte[bufferSize]);
            camera.setPreviewCallbackWithBuffer(this);
        } catch (Exception ignored) {
        }
    }

    private Camera.Size bestSize(List<Camera.Size> sizes) {
        if (sizes == null || sizes.isEmpty()) return null;
        // Portrait host: compare the rotated preview aspect against the host aspect.
        float hostW = host.getWidth() > 0 ? host.getWidth() : 300f;
        float hostH = host.getHeight() > 0 ? host.getHeight() : 200f;
        float target = hostW / hostH;
        Camera.Size best = sizes.get(0);
        float bestScore = Float.MAX_VALUE;
        for (Camera.Size size : sizes) {
            // After a 90°/270° display rotation the preview is portrait: w/h swapped.
            float aspect = (float) size.height / (float) size.width;
            float aspectScore = Math.abs(aspect - target);
            long pixels = (long) size.width * size.height;
            float sizeScore = Math.abs(pixels - 1280L * 720L) / (1280f * 720f);
            float score = aspectScore * 4f + sizeScore;
            if (score < bestScore) {
                bestScore = score;
                best = size;
            }
        }
        return best;
    }

    /** Center-crops the preview inside the 120-200 dp host without stretching it. */
    private void applyPreviewLayout() {
        if (textureView == null || previewWidth <= 0 || previewHeight <= 0) return;
        final int hostW = host.getWidth();
        final int hostH = host.getHeight();
        if (hostW <= 0 || hostH <= 0) {
            host.post(this::applyPreviewLayout);
            return;
        }
        boolean rotated = displayOrientation() % 180 != 0;
        int contentW = rotated ? previewHeight : previewWidth;
        int contentH = rotated ? previewWidth : previewHeight;
        float scale = Math.max(hostW / (float) contentW, hostH / (float) contentH);
        int childW = Math.round(contentW * scale);
        int childH = Math.round(contentH * scale);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(childW, childH);
        params.gravity = Gravity.CENTER;
        textureView.setLayoutParams(params);
    }

    private int displayOrientation() {
        try {
            Camera.CameraInfo info = new Camera.CameraInfo();
            Camera.getCameraInfo(cameraId, info);
            int rotation = ((android.view.WindowManager) service
                    .getSystemService(Service.WINDOW_SERVICE))
                    .getDefaultDisplay().getRotation();
            int degrees;
            switch (rotation) {
                case Surface.ROTATION_90:
                    degrees = 90;
                    break;
                case Surface.ROTATION_180:
                    degrees = 180;
                    break;
                case Surface.ROTATION_270:
                    degrees = 270;
                    break;
                default:
                    degrees = 0;
                    break;
            }
            if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
                return (360 - ((info.orientation + degrees) % 360)) % 360;
            }
            return (info.orientation - degrees + 360) % 360;
        } catch (Exception e) {
            return 90;
        }
    }

    private void releaseCamera() {
        Camera active = camera;
        camera = null;
        if (frameExecutor != null) {
            frameExecutor.shutdownNow();
            frameExecutor = null;
        }
        latestFrameUri = null;
        if (active != null) {
            try {
                active.setPreviewCallbackWithBuffer(null);
            } catch (Exception ignored) {
            }
            try {
                active.stopPreview();
            } catch (Exception ignored) {
            }
            try {
                active.release();
            } catch (Exception ignored) {
            }
        }
    }
}
