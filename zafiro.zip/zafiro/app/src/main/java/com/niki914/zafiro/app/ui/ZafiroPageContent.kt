package com.niki914.zafiro.app.ui

import androidx.compose.runtime.Composable
import com.niki914.uikit.infra.nav.NavigationEntry
import com.niki914.zafiro.app.ui.content.CustomPyToolDetailContent
import com.niki914.zafiro.app.ui.content.CustomPyToolsSettingsContent
import com.niki914.zafiro.app.ui.model.StartupAssistantUi
import com.niki914.zafiro.app.ui.nav.BuiltinToolGroupDetailPage
import com.niki914.zafiro.app.ui.nav.ConfigurePage
import com.niki914.zafiro.app.ui.nav.ConversationHistoryPage
import com.niki914.zafiro.app.ui.nav.CustomPyToolDetailPage
import com.niki914.zafiro.app.ui.nav.CustomPyToolsPage
import com.niki914.zafiro.app.ui.nav.DonePage
import com.niki914.zafiro.app.ui.nav.EnvContextVariableDetailPage
import com.niki914.zafiro.app.ui.nav.ExecutionRuleDetailPage
import com.niki914.zafiro.app.ui.nav.FloatingBallSettingsPage
import com.niki914.zafiro.app.ui.nav.MaskingRuleDetailPage
import com.niki914.zafiro.app.ui.nav.HomePage
import com.niki914.zafiro.app.ui.nav.MarkdownScalePage
import com.niki914.zafiro.app.ui.nav.McpServerDetailPage
import com.niki914.zafiro.app.ui.nav.OnboardingPreferencesPage
import com.niki914.zafiro.app.ui.nav.OnboardingThemePage
import com.niki914.zafiro.app.ui.nav.PromptEditPage
import com.niki914.zafiro.app.ui.nav.ProviderPickPage
import com.niki914.zafiro.app.ui.nav.SavedConfigDetailPage
import com.niki914.zafiro.app.ui.nav.SavedConfigPromptEditPage
import com.niki914.zafiro.app.ui.nav.SettingsDetailPage
import com.niki914.zafiro.app.ui.nav.SettingsHomePage
import com.niki914.zafiro.app.ui.nav.SettingsProviderPickPage
import com.niki914.zafiro.app.ui.nav.SkillDetailPage
import com.niki914.zafiro.app.ui.nav.StartupPage
import com.niki914.zafiro.app.ui.nav.TakeoverRuleDetailPage
import com.niki914.zafiro.app.ui.nav.TextActionDetailPage
import com.niki914.zafiro.app.ui.nav.ViewerPage
import com.niki914.zafiro.app.ui.nav.ZafiroPage
import com.niki914.zafiro.app.ui.route.BuiltinToolGroupDetailRoute
import com.niki914.zafiro.app.ui.route.ConfigurePageRoute
import com.niki914.zafiro.app.ui.route.ConversationHistoryPageRoute
import com.niki914.zafiro.app.ui.route.DonePageRoute
import com.niki914.zafiro.app.ui.route.EnvContextVariableDetailRoute
import com.niki914.zafiro.app.ui.route.ExecutionRuleDetailRoute
import com.niki914.zafiro.app.ui.route.FloatingBallSettingsPageRoute
import com.niki914.zafiro.app.ui.route.MaskingRuleDetailRoute
import com.niki914.zafiro.app.ui.route.HomePageRoute
import com.niki914.zafiro.app.ui.route.MarkdownScalePageRoute
import com.niki914.zafiro.app.ui.route.McpServerDetailRoute
import com.niki914.zafiro.app.ui.route.OnboardingPreferencesRoute
import com.niki914.zafiro.app.ui.route.OnboardingThemeRoute
import com.niki914.zafiro.app.ui.route.PromptEditRoute
import com.niki914.zafiro.app.ui.route.ProviderPickPageRoute
import com.niki914.zafiro.app.ui.route.SavedConfigDetailRoute
import com.niki914.zafiro.app.ui.route.SavedConfigPromptEditRoute
import com.niki914.zafiro.app.ui.route.SettingsDetailPageRoute
import com.niki914.zafiro.app.ui.route.SettingsHomePageRoute
import com.niki914.zafiro.app.ui.route.SettingsProviderPickPageRoute
import com.niki914.zafiro.app.ui.route.SkillDetailRoute
import com.niki914.zafiro.app.ui.route.StartupPageRoute
import com.niki914.zafiro.app.ui.route.TakeoverRuleDetailRoute
import com.niki914.zafiro.app.ui.route.TextActionDetailRoute
import com.niki914.zafiro.app.ui.route.ViewerPageRoute

@Composable
fun ZafiroPageContent(
    entry: NavigationEntry<ZafiroPage>,
    startupAssistantUi: StartupAssistantUi,
    isTopPage: Boolean = true,
    onPush: (ZafiroPage) -> Unit,
    onPushFromLeft: (ZafiroPage) -> Unit,
    onPop: () -> Unit,
    onPopMultiple: (Int) -> Unit,
    onPopToRight: () -> Unit,
    onResetTo: (ZafiroPage) -> Unit,
    selectedConversationId: String?,
    onConversationSelected: (String) -> Unit,
    onConversationSelectionConsumed: (String) -> Unit,
    activeConversationId: String?,
    onActiveConversationChanged: (String?) -> Unit,
    onCurrentConversationDeleted: suspend (String) -> Unit,
) {
    when (val page = entry.page) {
        StartupPage -> StartupPageRoute(
            startupAssistantUi = startupAssistantUi,
            onPush = onPush,
        )

        OnboardingThemePage -> OnboardingThemeRoute(
            onPush = onPush,
        )

        ProviderPickPage -> ProviderPickPageRoute(
            onPush = onPush,
        )

        SettingsProviderPickPage -> SettingsProviderPickPageRoute(
            onPush = onPush,
        )

        is ConfigurePage -> ConfigurePageRoute(
            page = page,
            onPush = onPush,
        )

        is SavedConfigDetailPage -> SavedConfigDetailRoute(
            page = page,
            onBack = onPop,
            onPopMultiple = onPopMultiple,
            onPush = onPush,
        )

        DonePage -> DonePageRoute(
            onPush = onPush,
            onResetTo = onResetTo,
        )

        OnboardingPreferencesPage -> OnboardingPreferencesRoute(
            onResetTo = onResetTo,
        )

        HomePage -> HomePageRoute(
            isCurrentPage = isTopPage,
            onPush = onPush,
            onPushFromLeft = onPushFromLeft,
            selectedConversationId = selectedConversationId,
            onConversationSelectionConsumed = onConversationSelectionConsumed,
            onActiveConversationChanged = onActiveConversationChanged,
        )

        ConversationHistoryPage -> ConversationHistoryPageRoute(
            activeConversationId = activeConversationId,
            onBack = onPopToRight,
            onConversationSelected = { id ->
                onConversationSelected(id)
                onPopToRight()
            },
            onCurrentConversationDeleted = onCurrentConversationDeleted,
        )

        SettingsHomePage -> SettingsHomePageRoute(
            onPush = onPush,
        )

        is SettingsDetailPage -> SettingsDetailPageRoute(
            page = page,
            onPush = onPush,
            onBack = onPop,
        )

        PromptEditPage -> PromptEditRoute(
            onBack = onPop,
        )

        is EnvContextVariableDetailPage -> EnvContextVariableDetailRoute(
            page = page,
            onBack = onPop,
        )

        is SavedConfigPromptEditPage -> SavedConfigPromptEditRoute(
            page = page,
            onBack = onPop,
        )

        is McpServerDetailPage -> McpServerDetailRoute(
            page = page,
            onBack = onPop,
        )

        is TextActionDetailPage -> TextActionDetailRoute(
            page = page,
            onBack = onPop,
        )

        is ExecutionRuleDetailPage -> ExecutionRuleDetailRoute(
            page = page,
            onBack = onPop,
        )

        is TakeoverRuleDetailPage -> TakeoverRuleDetailRoute(
            page = page,
            onBack = onPop,
        )

        is MaskingRuleDetailPage -> MaskingRuleDetailRoute(
            page = page,
            onBack = onPop,
        )

        is SkillDetailPage -> SkillDetailRoute(
            page = page,
            onBack = onPop,
        )

        is CustomPyToolDetailPage -> CustomPyToolDetailContent(
            page = page,
            onBack = onPop,
        )

        is BuiltinToolGroupDetailPage -> BuiltinToolGroupDetailRoute(
            page = page,
            onBack = onPop,
            onPush = onPush,
        )

        CustomPyToolsPage -> CustomPyToolsSettingsContent(
            onOpenToolDetail = { name, index, isCreating ->
                onPush(CustomPyToolDetailPage(name, index, isCreating))
            },
        )

        MarkdownScalePage -> MarkdownScalePageRoute()

        FloatingBallSettingsPage -> FloatingBallSettingsPageRoute()

        is ViewerPage -> ViewerPageRoute(
            page = page,
            onBack = onPop,
        )
    }
}
