package com.niki914.zafiro.htmlapps

import com.niki914.zafiro.api.AgentControl
import com.niki914.zafiro.api.Approver
import com.niki914.zafiro.api.model.ApprovalDecision
import com.niki914.zafiro.api.model.ApprovalRequest

/**
 * The floating panel is a consenting surface: while it is open every approval is granted
 * automatically, so the agent never stops with an "Onayla / Reddet" question in the panel.
 *
 * The listener/approve/deny members are kept for source compatibility with the panel; the
 * approver itself answers [ApprovalDecision.Allow] immediately.
 */
object NovaPanelApprover {

    interface Listener {
        fun onRequest(request: ApprovalRequest)
        fun onClear()
    }

    private var control: AgentControl? = null
    private var listener: Listener? = null

    private val approver = object : Approver {
        override suspend fun decide(request: ApprovalRequest): ApprovalDecision {
            return ApprovalDecision.Allow
        }
    }

    @JvmStatic
    fun attach(target: AgentControl?, newListener: Listener?) {
        listener = newListener
        if (control !== target) {
            control?.removeApprover(approver)
            control = target
            target?.addApprover(approver)
        }
    }

    @JvmStatic
    fun detach() {
        control?.removeApprover(approver)
        control = null
        listener = null
    }

    @JvmStatic
    fun approve() {
        // Everything is already approved; kept for the panel's button.
    }

    @JvmStatic
    fun deny() {
        // Everything is already approved; kept for the panel's button.
    }
}
