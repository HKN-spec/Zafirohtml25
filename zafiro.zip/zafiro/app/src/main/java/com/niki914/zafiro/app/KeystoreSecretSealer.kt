package com.niki914.zafiro.app

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.niki914.zafiro.evolution.core.SecretSealer
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * N60 (v13): device-bound sealing for the ledger's secret directory. The key never
 * leaves the Android keystore, so a backup can restore *memory* but the token only
 * opens on the same device — which is the honest compromise: portability without
 * shipping a plaintext token in Download.
 */
class KeystoreSecretSealer : SecretSealer {

    override fun seal(plain: ByteArray): ByteArray? = runCatching {
        val cipher = Cipher.getInstance(TRANSFORM)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plain)
        val out = ByteArray(1 + iv.size + encrypted.size)
        out[0] = iv.size.toByte()
        iv.copyInto(out, 1)
        encrypted.copyInto(out, 1 + iv.size)
        out
    }.getOrNull()

    override fun open(sealed: ByteArray): ByteArray? = runCatching {
        if (sealed.size < 2) return null
        val ivSize = sealed[0].toInt()
        if (ivSize <= 0 || ivSize > 32 || sealed.size <= 1 + ivSize) return null
        val iv = sealed.copyOfRange(1, 1 + ivSize)
        val body = sealed.copyOfRange(1 + ivSize, sealed.size)
        val cipher = Cipher.getInstance(TRANSFORM)
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        cipher.doFinal(body)
    }.getOrNull()

    private fun key(): SecretKey {
        val store = KeyStore.getInstance(KEYSTORE).apply { load(null) }
        (store.getEntry(ALIAS, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    private companion object {
        const val KEYSTORE = "AndroidKeyStore"
        const val ALIAS = "zafiro-ledger-secrets"
        const val TRANSFORM = "AES/GCM/NoPadding"
    }
}
