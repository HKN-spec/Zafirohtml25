package com.niki914.zafiro.htmlapps.floating;

import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * HSV + alpha colour picker used by the floating panel's appearance menu and the settings page.
 *
 * Works from an Activity (normal dialog) and from the overlay Service (the dialog window gets
 * TYPE_APPLICATION_OVERLAY, otherwise a Service context cannot show a dialog).
 */
public final class HtmlAppsColorDialog {

    public interface OnPick {
        void onPick(int color, int alpha);
    }

    private HtmlAppsColorDialog() {
    }

    public static void show(Context context, String title, int initialColor, int initialAlpha,
                            OnPick callback) {
        if (context == null) return;
        int density = Math.max(1, Math.round(
                context.getResources().getDisplayMetrics().density));
        final float[] hsv = new float[3];
        Color.colorToHSV(initialColor, hsv);
        final int[] alpha = {clamp(initialAlpha)};

        LinearLayout root = new LinearLayout(context);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = 16 * density;
        root.setPadding(pad, pad, pad, pad);

        View preview = new View(context);
        LinearLayout.LayoutParams previewParams =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 54 * density);
        previewParams.bottomMargin = 10 * density;
        root.addView(preview, previewParams);

        TextView previewLabel = new TextView(context);
        previewLabel.setTextSize(12);
        previewLabel.setGravity(Gravity.CENTER);
        previewLabel.setPadding(0, 0, 0, 8 * density);
        root.addView(previewLabel);

        SeekBar hue = slider(context, 360);
        SeekBar saturation = slider(context, 100);
        SeekBar value = slider(context, 100);
        SeekBar opacity = slider(context, 255);

        hue.setProgress(Math.round(hsv[0]));
        saturation.setProgress(Math.round(hsv[1] * 100f));
        value.setProgress(Math.round(hsv[2] * 100f));
        opacity.setProgress(alpha[0]);

        root.addView(label(context, "Renk tonu (H)"));
        root.addView(hue);
        root.addView(label(context, "Doygunluk (S)"));
        root.addView(saturation);
        root.addView(label(context, "Parlaklık (V)"));
        root.addView(value);
        root.addView(label(context, "Saydamlık"));
        root.addView(opacity);

        Runnable update = () -> {
            float[] current = {
                    hue.getProgress(),
                    saturation.getProgress() / 100f,
                    value.getProgress() / 100f,
            };
            int color = Color.HSVToColor(current);
            int argb = Color.HSVToColor(alpha[0], current);
            GradientDrawable background = new GradientDrawable();
            background.setColor(argb);
            background.setCornerRadius(12 * density);
            background.setStroke(1 * density, 0xFF888888);
            preview.setBackground(background);
            previewLabel.setText(String.format("#%06X · %%%d",
                    color & 0xFFFFFF, Math.round(alpha[0] * 100f / 255f)));
        };
        update.run();

        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (seekBar == opacity) alpha[0] = clamp(progress);
                update.run();
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override public void onStopTrackingTouch(SeekBar seekBar) {
            }
        };
        hue.setOnSeekBarChangeListener(listener);
        saturation.setOnSeekBarChangeListener(listener);
        value.setOnSeekBarChangeListener(listener);
        opacity.setOnSeekBarChangeListener(listener);

        AlertDialog dialog = new AlertDialog.Builder(context,
                android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(title)
                .setView(root)
                .setPositiveButton("Tamam", (d, which) -> {
                    float[] chosen = {
                            hue.getProgress(),
                            saturation.getProgress() / 100f,
                            value.getProgress() / 100f,
                    };
                    callback.onPick(Color.HSVToColor(chosen), alpha[0]);
                })
                .setNegativeButton("İptal", null)
                .create();
        if (context instanceof Service) {
            try {
                if (dialog.getWindow() != null) {
                    dialog.getWindow().setType(
                            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
                }
            } catch (Exception ignored) {
            }
        }
        dialog.show();
    }

    private static SeekBar slider(Context context, int max) {
        SeekBar bar = new SeekBar(context);
        bar.setMax(max);
        bar.setPadding(0, 0, 0, 6);
        return bar;
    }

    private static TextView label(Context context, String text) {
        TextView view = new TextView(context);
        view.setText(text);
        view.setTextSize(12);
        view.setPadding(0, 10, 0, 2);
        return view;
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }
}
