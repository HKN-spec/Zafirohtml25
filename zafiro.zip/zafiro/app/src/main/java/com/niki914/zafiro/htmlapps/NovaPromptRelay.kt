package com.niki914.zafiro.htmlapps

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Carries a whole prompt from the HtmlApps surfaces (library and floating panel) into the
 * running Zafiro chat. The activity is a single process, so an in-memory relay is enough and no
 * runtime bridge is needed.
 *
 * An attachment can travel with the text; Zafiro attaches it to the next message exactly like a
 * file picked from the chat composer.
 */
object NovaPromptRelay {

    data class Prompt(
        val text: String,
        val source: String,
        val imageUri: String? = null,
        val fileUri: String? = null,
    )

    var pending: Prompt? by mutableStateOf<Prompt?>(null)
        private set

    @JvmStatic
    fun offer(text: String?, source: String?) {
        offer(text, source, null, null)
    }

    @JvmStatic
    fun offer(text: String?, source: String?, imageUri: String?, fileUri: String?) {
        val value = text?.trim().orEmpty()
        val image = imageUri?.trim().orEmpty()
        val file = fileUri?.trim().orEmpty()
        if (value.isEmpty() && image.isEmpty() && file.isEmpty()) return
        pending = Prompt(
            text = value,
            source = source?.trim().orEmpty(),
            imageUri = image.ifEmpty { null },
            fileUri = file.ifEmpty { null },
        )
    }

    @JvmStatic
    fun offerImage(imageUri: String?, text: String?, source: String?) {
        offer(text, source, imageUri, null)
    }

    @JvmStatic
    fun offerFile(fileUri: String?, text: String?, source: String?) {
        offer(text, source, null, fileUri)
    }

    /** Clears only the prompt that was handled, so a newer request is not dropped. */
    @JvmStatic
    fun clear(prompt: Prompt?) {
        if (prompt != null && pending === prompt) pending = null
    }
}
