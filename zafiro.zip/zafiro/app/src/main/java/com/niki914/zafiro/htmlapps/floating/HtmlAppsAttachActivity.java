package com.niki914.zafiro.htmlapps.floating;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.niki914.zafiro.app.MainActivity;
import com.niki914.zafiro.htmlapps.NovaPromptRelay;

import java.io.File;

/**
 * Transparent helper used by the floating panel to attach a camera photo, gallery image or any
 * file to the next Nova prompt. A Service cannot receive an activity result, so this tiny activity
 * owns the picker and hands the URI to {@link NovaPromptRelay}.
 */
public class HtmlAppsAttachActivity extends Activity {

    public static final String EXTRA_MODE = "mode";
    public static final String EXTRA_TEXT = "text";
    public static final String EXTRA_TARGET = "target";
    public static final String TARGET_PANEL = "panel";
    public static final String TARGET_CHAT = "chat";
    public static final String MODE_CAMERA = "camera";
    public static final String MODE_IMAGE = "image";
    public static final String MODE_FILE = "file";

    private static final int REQ_CAMERA = 71;
    private static final int REQ_PICK = 72;

    private String mode = MODE_FILE;
    private String text = "";
    private String target = TARGET_CHAT;
    private File cameraFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mode = getIntent().getStringExtra(EXTRA_MODE);
        if (mode == null) mode = MODE_FILE;
        text = getIntent().getStringExtra(EXTRA_TEXT);
        if (text == null) text = "";
        target = getIntent().getStringExtra(EXTRA_TARGET);
        if (target == null) target = TARGET_CHAT;
        if (MODE_CAMERA.equals(mode)) {
            openCamera();
        } else {
            openPicker(MODE_IMAGE.equals(mode) ? "image/*" : "*/*");
        }
    }

    private void openCamera() {
        try {
            File dir = new File(getCacheDir(), "capture");
            if (!dir.isDirectory()) dir.mkdirs();
            cameraFile = new File(dir, "attach_" + System.currentTimeMillis() + ".jpg");
            Uri output = FileProvider.getUriForFile(this,
                    getPackageName() + ".fileprovider", cameraFile);
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, output);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (intent.resolveActivity(getPackageManager()) == null) {
                toast("Kamera uygulaması bulunamadı");
                finish();
                return;
            }
            startActivityForResult(intent, REQ_CAMERA);
        } catch (Exception e) {
            toast("Kamera açılamadı: " + e.getMessage());
            finish();
        }
    }

    private void openPicker(String mime) {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(mime);
            startActivityForResult(intent, REQ_PICK);
        } catch (Exception e) {
            toast("Dosya seçici açılamadı");
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) {
            finish();
            return;
        }
        if (requestCode == REQ_CAMERA) {
            if (cameraFile == null || !cameraFile.isFile() || cameraFile.length() == 0) {
                toast("Fotoğraf alınamadı");
                finish();
                return;
            }
            try {
                Uri uri = FileProvider.getUriForFile(this,
                        getPackageName() + ".fileprovider", cameraFile);
                if (TARGET_PANEL.equals(target)) {
                    HtmlAppsFloatingButtonService.attachToPanel(uri.toString(), true);
                    finish();
                    return;
                }
                NovaPromptRelay.offerImage(uri.toString(),
                        text.isEmpty() ? "Bu fotoğrafta ne var?" : text, "float");
                toast("Fotoğraf eklendi");
                launchChat();
            } catch (Exception e) {
                toast("Fotoğraf eklenemedi");
                finish();
            }
            return;
        }
        if (requestCode == REQ_PICK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            if (TARGET_PANEL.equals(target)) {
                HtmlAppsFloatingButtonService.attachToPanel(uri.toString(),
                        MODE_IMAGE.equals(mode));
                finish();
                return;
            }
            if (MODE_IMAGE.equals(mode)) {
                NovaPromptRelay.offerImage(uri.toString(),
                        text.isEmpty() ? "Bu görselde ne var?" : text, "float");
                toast("Görsel eklendi");
            } else {
                NovaPromptRelay.offerFile(uri.toString(),
                        text.isEmpty() ? "Bu dosyayı incele ve özetle." : text, "float");
                toast("Dosya eklendi");
            }
            launchChat();
            return;
        }
        finish();
    }

    private void launchChat() {
        try {
            startActivity(new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
        } catch (Exception ignored) {
        }
        finish();
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }
}
