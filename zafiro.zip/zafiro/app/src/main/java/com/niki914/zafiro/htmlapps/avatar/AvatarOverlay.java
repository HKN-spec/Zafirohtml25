package com.niki914.zafiro.htmlapps.avatar;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;

import org.json.JSONObject;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * The on-screen character. Two overlay windows:
 *
 *  - a small touchable AvatarView the user can drag/tap;
 *  - a full-screen, non-touchable AvatarEffectsView for long pointing arms, circles, underlines,
 *    pen trails and tap ripples.
 *
 * The character can walk, point, circle, underline, draw and speak. Zafiro's own accessibility
 * pointer remains responsible for the actual gesture; this overlay is the visible body.
 */
public final class AvatarOverlay {

    private static final String PREFS = "htmlapps_avatar";
    private static volatile AvatarOverlay instance;

    private final Context ctx;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final int dp1;

    private WindowManager windowManager;
    private AvatarView avatar;
    private AvatarEffectsView effects;
    private View touchView;
    private WindowManager.LayoutParams avatarParams;
    private WindowManager.LayoutParams effectsParams;
    private WindowManager.LayoutParams touchParams;

    private int screenW;
    private int screenH;
    private int avatarW;
    private int avatarH;
    private int homeX;
    private int homeY;
    private volatile boolean visible;

    private ValueAnimator walkAnimator;
    private Runnable homeRunnable;
    private long speechToken;
    private String mood = "happy";
    private boolean handActive;
    private boolean followingPointer;
    private float followWalkPhase;
    private final Runnable stopFollowWalk = () -> {
        if (avatar != null) avatar.setWalking(false, 0f);
    };
    private float handTargetX;
    private float handTargetY;

    private AvatarOverlay(Context context) {
        this.ctx = context.getApplicationContext();
        this.dp1 = Math.round(ctx.getResources().getDisplayMetrics().density);
    }

    public static AvatarOverlay get(Context context) {
        AvatarOverlay local = instance;
        if (local == null) {
            synchronized (AvatarOverlay.class) {
                local = instance;
                if (local == null) {
                    local = new AvatarOverlay(context);
                    instance = local;
                }
            }
        }
        return local;
    }

    public boolean isVisible() {
        return visible;
    }

    public static boolean enabled(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean("enabled", true);
    }

    public static String style(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString("style", "nova");
    }

    /** Settings toggle: widget and character can be enabled independently. */
    public void setEnabled(boolean value) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean("enabled", value).apply();
        if (!value) hide();
        else show();
    }

    /** Six outfit palettes; persists across restarts. */
    public void setStyle(String value) {
        String style = value == null || value.isEmpty() ? "nova" : value;
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("style", style).apply();
        runOnMain(() -> {
            if (avatar != null) avatar.setStyle(style);
        });
    }

    // ------------------------------------------------------------------ windows

    public void show() {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            showInternal();
            return;
        }
        final CountDownLatch latch = new CountDownLatch(1);
        main.post(() -> {
            try {
                showInternal();
            } finally {
                latch.countDown();
            }
        });
        try {
            latch.await(1500, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void showInternal() {
        if (!enabled(ctx)) return;
        if (visible) return;
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(ctx)) return;
        if (avatar != null || effects != null) removeViews();
        try {
            windowManager = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            if (windowManager == null) return;
            DisplayMetrics dm = new DisplayMetrics();
            windowManager.getDefaultDisplay().getRealMetrics(dm);
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;
            avatarW = dp(160);
            avatarH = dp(250);
            homeX = dp(8);
            homeY = Math.max(dp(30), (int) (screenH * 0.34f));

            effects = new AvatarEffectsView(ctx);
            effectsParams = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    Build.VERSION.SDK_INT >= 26
                            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                            : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            effectsParams.gravity = Gravity.TOP | Gravity.START;
            effects.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            windowManager.addView(effects, effectsParams);

            avatar = new AvatarView(ctx);
            avatar.setStyle(style(ctx));
            avatarParams = new WindowManager.LayoutParams(
                    avatarW, avatarH,
                    Build.VERSION.SDK_INT >= 26
                            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                            : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            avatarParams.gravity = Gravity.TOP | Gravity.START;
            avatarParams.x = homeX;
            avatarParams.y = homeY;
            windowManager.addView(avatar, avatarParams);

            // Only the body is touchable: a transparent window exactly over it.
            touchView = new View(ctx);
            touchView.setBackgroundColor(0x00000000);
            touchView.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            touchView.setOnTouchListener(createTouchListener());
            touchParams = new WindowManager.LayoutParams(
                    Math.max(dp(40), (int) (avatarW * 0.5f)),
                    Math.max(dp(80), (int) (avatarH * 0.75f)),
                    Build.VERSION.SDK_INT >= 26
                            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                            : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            touchParams.gravity = Gravity.TOP | Gravity.START;
            windowManager.addView(touchView, touchParams);
            updateTouchWindow();

            visible = true;
            sayInternal("Merhaba! Buradayım. İstersen beni sürükle.", 3200);
        } catch (Throwable t) {
            visible = false;
            removeViews();
        }
    }

    public void hide() {
        runOnMain(this::hideInternal);
    }

    private void hideInternal() {
        visible = false;
        if (walkAnimator != null) walkAnimator.cancel();
        if (homeRunnable != null) main.removeCallbacks(homeRunnable);
        removeViews();
    }

    private void removeViews() {
        try {
            if (touchView != null && windowManager != null) windowManager.removeView(touchView);
        } catch (Exception ignored) {
        }
        try {
            if (avatar != null && windowManager != null) windowManager.removeView(avatar);
        } catch (Exception ignored) {
        }
        try {
            if (effects != null && windowManager != null) windowManager.removeView(effects);
        } catch (Exception ignored) {
        }
        avatar = null;
        effects = null;
        touchView = null;
        avatarParams = null;
        effectsParams = null;
        touchParams = null;
    }

    private int dp(int value) {
        return value * dp1;
    }

    private void moveBy(float dx, float dy) {
        if (!visible || avatarParams == null) return;
        followingPointer = false;
        setTouchableInternal(true);
        if (avatar != null) avatar.setPointing(false, 0, 0);
        avatarParams.x = clampX((int) (avatarParams.x + dx));
        avatarParams.y = clampY((int) (avatarParams.y + dy));
        homeX = avatarParams.x;
        homeY = avatarParams.y;
        try { windowManager.updateViewLayout(avatar, avatarParams); } catch (Exception ignored) {}
        updateTouchWindow();
    }

    private View.OnTouchListener createTouchListener() {
        final int slop = dp(6);
        return new View.OnTouchListener() {
            private float downRawX;
            private float downRawY;
            private float lastRawX;
            private float lastRawY;
            private boolean dragging;

            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = lastRawX = event.getRawX();
                        downRawY = lastRawY = event.getRawY();
                        dragging = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - lastRawX;
                        float dy = event.getRawY() - lastRawY;
                        if (Math.abs(event.getRawX() - downRawX) > slop
                                || Math.abs(event.getRawY() - downRawY) > slop) {
                            dragging = true;
                        }
                        if (dragging) moveBy(dx, dy);
                        lastRawX = event.getRawX();
                        lastRawY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (!dragging) onAvatarTapped();
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    /** Transparent touch window exactly over the body, so empty margins pass taps through. */
    private void updateTouchWindow() {
        if (touchView == null || touchParams == null || avatarParams == null) return;
        float scale = Math.min(avatarW / 180f, avatarH / 280f);
        int left = Math.round(46 * scale);
        int top = Math.round(38 * scale);
        int width = Math.max(dp(40), Math.round((134 - 46) * scale));
        int height = Math.max(dp(80), Math.round((266 - 38) * scale));
        touchParams.width = width;
        touchParams.height = height;
        touchParams.x = Math.max(0, Math.min(screenW - width, avatarParams.x + left));
        touchParams.y = Math.max(0, Math.min(screenH - height, avatarParams.y + top));
        try {
            windowManager.updateViewLayout(touchView, touchParams);
        } catch (Exception ignored) {
        }
    }

    private int clampX(int x) {
        return Math.max(-avatarW / 3, Math.min(screenW - avatarW / 2, x));
    }

    private int clampY(int y) {
        return Math.max(0, Math.min(screenH - dp(70), y));
    }

    // ------------------------------------------------------------------ speech

    public void say(String text) {
        say(text, 3600);
    }

    public void say(String text, long durationMs) {
        runOnMain(() -> {
            if (!visible) showInternal();
            if (!visible) return;
            sayInternal(text, durationMs);
        });
    }

    private void sayInternal(String text, long durationMs) {
        if (avatar == null) return;
        final long token = ++speechToken;
        avatar.setSpeech(text);
        main.postDelayed(() -> {
            if (token == speechToken && avatar != null) avatar.setSpeech("");
        }, Math.max(900, durationMs));
    }

    public void setMood(String mood) {
        runOnMain(() -> {
            if (mood != null) this.mood = mood;
            if (avatar != null) avatar.setMood(this.mood);
        });
    }

    private void onAvatarTapped() {
        if (avatar == null) return;
        avatar.setMood("happy");
        sayInternal("Buradayım! Bir şey göstermemi veya yapmamı ister misin?", 2600);
        avatar.tapPulse();
    }

    // ------------------------------------------------------------------ motion

    public void walkTo(int x, int y, long durationMs) {
        runOnMain(() -> {
            if (!visible) showInternal();
            if (!visible) return;
            int[] pos = placeNear(x, y);
            walkToInternal(pos[0], pos[1], Math.max(200, durationMs), null);
        });
    }

    /**
     * Moves the character so the fixed right hand sits exactly on the pointer. No stretched
     * rubber arm: the pointer and the hand travel together.
     */
    public void followPointer(float x, float y) {
        runOnMain(() -> {
            if (!enabled(ctx)) return;
            if (!visible) showInternal();
            if (!visible || avatar == null || avatarParams == null) return;
            if (!followingPointer) {
                followingPointer = true;
                avatar.setPointing(true, 142f, 178f);
                setTouchableInternal(false);
            }
            int targetX = clampX(Math.round(x) - handOffsetX());
            int targetY = clampY(Math.round(y) - handOffsetY());
            if (avatarParams.x == targetX && avatarParams.y == targetY) return;
            int oldX = avatarParams.x;
            int oldY = avatarParams.y;
            avatarParams.x = targetX;
            avatarParams.y = targetY;
            try { windowManager.updateViewLayout(avatar, avatarParams); } catch (Exception ignored) {}
            updateTouchWindow();
            // Legs move while the body follows the cursor: walking, not sliding.
            int distance = (int) Math.hypot(targetX - oldX, targetY - oldY);
            if (distance > dp(1)) {
                followWalkPhase += Math.min(1.2f, distance / (float) Math.max(1, dp(55)));
                if (followWalkPhase > 1f) followWalkPhase -= 1f;
                avatar.setWalking(true, followWalkPhase);
                main.removeCallbacks(stopFollowWalk);
                main.postDelayed(stopFollowWalk, 220);
            }
        });
    }

    /** Fixed hand anchor inside the 180x280 drawing, scaled exactly like AvatarView draws it. */
    private int handOffsetX() {
        float scale = Math.min(avatarW / 180f, avatarH / 280f);
        return Math.round(142f * scale);
    }

    private int handOffsetY() {
        float scale = Math.min(avatarW / 180f, avatarH / 280f);
        return Math.round(178f * scale);
    }

    /**
     * Re-adds the character window last so it sits above Zafiro's cursor window: the mouse arrow
     * ends up under Nova's hand, which makes it look like her hand performs the action.
     */
    public void raiseToTop() {
        runOnMain(() -> {
            if (!visible || avatar == null || avatarParams == null || windowManager == null) return;
            try {
                windowManager.removeView(avatar);
            } catch (Exception ignored) {
            }
            try {
                windowManager.addView(avatar, avatarParams);
            } catch (Exception ignored) {
            }
        });
    }

    /** Stops following the cursor and glides back to the resting spot. */
    public void returnHome() {
        runOnMain(() -> {
            if (!visible || avatarParams == null) return;
            followingPointer = false;
            setTouchableInternal(true);
            main.removeCallbacks(stopFollowWalk);
            if (avatar != null) avatar.setWalking(false, 0f);
            if (avatar != null) avatar.setPointing(false, 0, 0);
            if (walkAnimator != null) walkAnimator.cancel();
            if (homeRunnable != null) main.removeCallbacks(homeRunnable);
            walkToInternal(homeX, homeY, 650, null);
        });
    }

    /**
     * The followed hand sits exactly on the target, so the touchable character window would
     * swallow the accessibility tap. Turn it into a pass-through window while following.
     */
    public void setTouchable(boolean touchable) {
        runOnMain(() -> setTouchableInternal(touchable));
    }

    private void setTouchableInternal(boolean touchable) {
        int flag = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        if (avatarParams != null && avatar != null) {
            if (touchable) avatarParams.flags &= ~flag;
            else avatarParams.flags |= flag;
            try {
                windowManager.updateViewLayout(avatar, avatarParams);
            } catch (Exception ignored) {
            }
        }
        if (touchParams != null && touchView != null) {
            if (touchable) touchParams.flags &= ~flag;
            else touchParams.flags |= flag;
            try {
                windowManager.updateViewLayout(touchView, touchParams);
            } catch (Exception ignored) {
            }
        }
    }

    public void pointAt(int x, int y, String label) {
        runOnMain(() -> {
            if (!visible) showInternal();
            if (!visible) return;
            followingPointer = true;
            if (avatar != null) avatar.setPointing(true, 142f, 178f);
            setTouchableInternal(false);
            glideTo(clampX(x - handOffsetX()), clampY(y - handOffsetY()), 360);
            if (label != null && !label.trim().isEmpty()) sayInternal(label.trim(), 3800);
        });
    }

    public void circle(int x, int y, int radius, int color, long durationMs) {
        runOnMain(() -> {
            if (!visible) showInternal();
            if (!visible) return;
            followingPointer = true;
            if (avatar != null) avatar.setPointing(true, 142f, 178f);
            setTouchableInternal(false);
            glideTo(clampX(x - handOffsetX()), clampY(y - handOffsetY()), 330);
            if (effects != null) effects.addCircle(x, y, radius, color, durationMs);
        });
    }

    public void underline(int x1, int y1, int x2, int y2, int color, long durationMs) {
        runOnMain(() -> {
            if (!visible) showInternal();
            if (!visible) return;
            followingPointer = true;
            if (avatar != null) avatar.setPointing(true, 142f, 178f);
            setTouchableInternal(false);
            glideTo(clampX(x2 - handOffsetX()), clampY(y2 - handOffsetY()), 330);
            if (effects != null) effects.addLine(x1, y1, x2, y2, color, durationMs);
        });
    }

    public void drawPath(List<float[]> points, int color, float widthDp, long durationMs) {
        if (points == null || points.isEmpty()) return;
        runOnMain(() -> {
            if (!visible) showInternal();
            if (!visible) return;
            float[] last = points.get(points.size() - 1);
            followingPointer = true;
            if (avatar != null) avatar.setPointing(true, 142f, 178f);
            setTouchableInternal(false);
            glideTo(clampX(Math.round(last[0]) - handOffsetX()),
                    clampY(Math.round(last[1]) - handOffsetY()), 330);
            if (effects != null) effects.addPath(points, color, widthDp, durationMs);
        });
    }

    /** Draws an effect without moving the character; the pointer's frame callback moves it. */
    public void showCircle(float x, float y, float radius, int color, long durationMs) {
        runOnMain(() -> {
            if (!visible) return;
            if (effects != null) effects.addCircle(x, y, radius, color, durationMs);
        });
    }

    public void showUnderline(float x1, float y1, float x2, float y2, int color,
                              long durationMs) {
        runOnMain(() -> {
            if (!visible) return;
            if (effects != null) effects.addLine(x1, y1, x2, y2, color, durationMs);
        });
    }

    public void showPath(List<float[]> points, int color, float widthDp, long durationMs) {
        if (points == null || points.isEmpty()) return;
        runOnMain(() -> {
            if (!visible) return;
            if (effects != null) effects.addPath(points, color, widthDp, durationMs);
        });
    }

    /** Smooth glide without the walking leg swing; used when the hand goes to a pointer target. */
    private void glideTo(int endX, int endY, long durationMs) {
        if (!visible || avatar == null || avatarParams == null) return;
        if (walkAnimator != null) walkAnimator.cancel();
        if (homeRunnable != null) main.removeCallbacks(homeRunnable);
        final int startX = avatarParams.x;
        final int startY = avatarParams.y;
        final int targetX = clampX(endX);
        final int targetY = clampY(endY);
        walkAnimator = ValueAnimator.ofFloat(0f, 1f);
        walkAnimator.setDuration(Math.max(120, durationMs));
        walkAnimator.setInterpolator(new DecelerateInterpolator());
        walkAnimator.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            if (avatarParams == null || avatar == null) return;
            avatarParams.x = startX + (int) ((targetX - startX) * t);
            avatarParams.y = startY + (int) ((targetY - startY) * t);
            avatar.setWalking(true, t * 2.6f);
            try { windowManager.updateViewLayout(avatar, avatarParams); } catch (Exception ignored) {}
            updateTouchWindow();
        });
        walkAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                if (avatar != null) avatar.setWalking(false, 0f);
            }
        });
        walkAnimator.start();
    }

    private void walkToInternal(int targetX, int targetY, long durationMs, Runnable done) {
        if (!visible || avatar == null || avatarParams == null) {
            if (done != null) done.run();
            return;
        }
        followingPointer = false;
        handActive = false;
        if (effects != null) effects.clearHand();
        final int startX = avatarParams.x;
        final int startY = avatarParams.y;
        final int endX = clampX(targetX);
        final int endY = clampY(targetY);
        if (walkAnimator != null) walkAnimator.cancel();
        if (homeRunnable != null) main.removeCallbacks(homeRunnable);
        walkAnimator = ValueAnimator.ofFloat(0f, 1f);
        walkAnimator.setDuration(Math.max(150, durationMs));
        walkAnimator.setInterpolator(new DecelerateInterpolator());
        walkAnimator.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            if (avatarParams == null || avatar == null) return;
            avatarParams.x = startX + (int) ((endX - startX) * t);
            avatarParams.y = startY + (int) ((endY - startY) * t);
            try { windowManager.updateViewLayout(avatar, avatarParams); } catch (Exception ignored) {}
            avatar.setWalking(true, t * 2.6f);
            updateTouchWindow();
            updateHand();
        });
        walkAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                if (avatar != null) {
                    avatar.setWalking(false, 0f);
                }
                if (done != null) done.run();
            }
        });
        walkAnimator.start();
    }

    /**
     * Places the character beside the target, never on top of it: the target must stay
     * outside the (touchable) avatar window or the synthetic tap would hit the character.
     */
    private int[] placeNear(int tx, int ty) {
        int margin = dp(14);
        int x;
        if (tx > screenW / 2) x = tx - avatarW - margin; // stand left of target
        else x = tx + margin;                             // stand right of target
        if (x < dp(2)) x = tx + margin;
        if (x + avatarW > screenW - dp(2)) x = tx - avatarW - margin;
        x = clampX(x);

        int y = (int) (ty - avatarH * 0.55f);
        if (y < dp(12)) y = ty + margin;
        if (y + avatarH > screenH - dp(4)) y = screenH - avatarH - dp(4);
        y = clampY(y);

        // Last-resort separation if a narrow screen still overlaps horizontally.
        boolean overlapsX = tx >= x && tx <= x + avatarW;
        boolean overlapsY = ty >= y && ty <= y + avatarH;
        if (overlapsX && overlapsY) {
            if (ty > screenH / 2) y = ty - avatarH - margin;
            else y = ty + margin;
            x = tx - avatarW / 2;
            x = clampX(x);
            y = clampY(y);
        }
        return new int[]{x, y};
    }

    private void scheduleHome(long delayMs) {
        if (homeRunnable != null) main.removeCallbacks(homeRunnable);
        homeRunnable = () -> {
            if (!visible) return;
            handActive = false;
            if (avatar != null) avatar.setPointing(false, 0, 0);
            if (effects != null) effects.clearHand();
            walkToInternal(homeX, homeY, 700, null);
        };
        main.postDelayed(homeRunnable, Math.max(500, delayMs));
    }

    private void updateHand() {
        handActive = false;
        if (effects != null) effects.clearHand();
    }

    private void updateHand(float targetX, float targetY) {
        // The pointer draws the hand; never paint a second stretched arm.
        updateHand();
    }

    private void followPointerNow(int x, int y) {
        if (avatar == null || avatarParams == null) return;
        followingPointer = true;
        avatarParams.x = clampX(x - handOffsetX());
        avatarParams.y = clampY(y - handOffsetY());
        try { windowManager.updateViewLayout(avatar, avatarParams); } catch (Exception ignored) {}
        updateTouchWindow();
        avatar.setPointing(true, 142f, 178f);
        setTouchableInternal(false);
        handActive = false;
        if (effects != null) effects.clearHand();
    }

    public void tapRipple(float x, float y) {
        runOnMain(() -> {
            if (effects != null) effects.tap(x, y);
        });
    }

    // ------------------------------------------------------------------- status

    public JSONObject status() {
        JSONObject o = new JSONObject();
        try {
            o.put("visible", visible);
            o.put("x", avatarParams == null ? -1 : avatarParams.x);
            o.put("y", avatarParams == null ? -1 : avatarParams.y);
            o.put("width", avatarW);
            o.put("height", avatarH);
            o.put("screenWidth", screenW);
            o.put("screenHeight", screenH);
            o.put("mood", mood);
        } catch (Exception ignored) {
        }
        return o;
    }

    private void runOnMain(Runnable r) {
        if (Looper.myLooper() == Looper.getMainLooper()) r.run();
        else main.post(r);
    }
}
