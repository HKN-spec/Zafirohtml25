package com.niki914.zafiro.htmlapps.library;

import android.graphics.Color;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Picks an icon that matches the app: first the page's own
 * {@code <meta name="app-icon" content="emoji|#color">}, then a keyword map over the name/HTML.
 * Falls back to the old robot only when nothing matches.
 */
public final class HtmlAppsIconSuggest {

    public static final class Suggestion {
        public final String emoji;
        public final int color;

        Suggestion(String emoji, int color) {
            this.emoji = emoji;
            this.color = color;
        }
    }

    private static final String[] KEYWORDS = {
            "hesap,calculator,matematik,topla,çarp",
            "hava,weather,forecast,sıcaklık",
            "resim,çiz,draw,paint,foto,boyama",
            "yılan,snake,oyun,game,arcade",
            "satranç,chess",
            "uzay,space,galaksi,gezegen",
            "not,todo,görev,task,liste",
            "takvim,calendar,plan,ajanda",
            "müzik,music,şarkı,player,çalar",
            "yemek,tarif,recipe,mutfak",
            "para,bütçe,budget,finans,hesap",
            "harita,map,konum,gezi",
            "kamera,camera,fotoğraf,çekim",
            "sohbet,chat,mesaj,asistan",
            "eğitim,ders,quiz,sınav,öğren",
            "sağlık,health,spor,fitness,egzersiz",
            "saat,timer,kronometre,sayac",
            "kod,code,geliştirici,program",
            "dosya,file,pdf,belge",
            "çeviri,translate,dil,lisan",
            "alışveriş,market,shop,sepet",
    };

    private static final String[] EMOJIS = {
            "🧮", "🌤️", "🎨", "🐍", "♟️", "🚀", "📝", "📅", "🎵", "🍳",
            "💰", "🗺️", "📷", "💬", "📚", "❤️", "⏱️", "💻", "📄", "🌐", "🛒",
    };

    private static final int[] COLORS = {
            0xFF4CAF50, 0xFF2196F3, 0xFFE91E63, 0xFF7C4DFF, 0xFF607D8B, 0xFF3949AB,
            0xFFFF9800, 0xFF3F51B5, 0xFFE91E63, 0xFFFF7043, 0xFF4CAF50, 0xFF009688,
            0xFF607D8B, 0xFF3F8CFF, 0xFF673AB7, 0xFFE53935, 0xFF795548, 0xFF263238,
            0xFF546E7A, 0xFF00BCD4, 0xFF8BC34A,
    };

    private static final Pattern META = Pattern.compile(
            "<meta[^>]+name=[\"']app-icon[\"'][^>]+content=[\"']([^\"']+)[\"']",
            Pattern.CASE_INSENSITIVE);

    private HtmlAppsIconSuggest() {
    }

    public static Suggestion suggest(String name, String html) {
        String content = metaIcon(html);
        if (content != null) {
            String[] parts = content.split("\\|");
            String emoji = parts.length > 0 ? parts[0].trim() : "";
            int color = 0xFF3F8CFF;
            if (parts.length > 1) {
                try {
                    color = Color.parseColor(parts[1].trim());
                } catch (Exception ignored) {
                }
            }
            if (!emoji.isEmpty()) return new Suggestion(emoji, color);
        }
        String haystack = ((name == null ? "" : name) + " "
                + (html == null ? "" : html)).toLowerCase(Locale.ROOT);
        for (int i = 0; i < KEYWORDS.length; i++) {
            String[] words = KEYWORDS[i].split(",");
            for (String word : words) {
                if (haystack.contains(word)) {
                    return new Suggestion(EMOJIS[i], COLORS[i]);
                }
            }
        }
        return new Suggestion("🤖", 0xFF3F8CFF);
    }

    private static String metaIcon(String html) {
        if (html == null || html.isEmpty()) return null;
        Matcher matcher = META.matcher(html);
        return matcher.find() ? matcher.group(1) : null;
    }
}
