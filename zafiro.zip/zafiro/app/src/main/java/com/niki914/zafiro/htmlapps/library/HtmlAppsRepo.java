package com.niki914.zafiro.htmlapps.library;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Library data source: lists HtmlApps folders under Download/HtmlApps, filters/searches them and
 * owns the recycle bin. Dot folders and folders starting with an underscore are internal
 * (.versions, .trash, _exports) and never show up as apps.
 */
public final class HtmlAppsRepo {

    public static final String ROOT_NAME = "HtmlApps";
    private static final String TRASH = ".trash";

    public static class App {
        public String folder;
        public String name;
        public File dir;
        public File icon;
        public File index;
        public HtmlAppsMeta meta;
    }

    private HtmlAppsRepo() {
    }

    public static File root() {
        return new File(Environment.getExternalStorageDirectory(), "Download/" + ROOT_NAME);
    }

    public static File ensureRoot() {
        File root = root();
        if (!root.isDirectory()) root.mkdirs();
        return root;
    }

    public static List<App> list(File root) {
        List<App> out = new ArrayList<>();
        File[] dirs = root == null ? null : root.listFiles();
        if (dirs == null) return out;
        for (File dir : dirs) {
            if (!dir.isDirectory()) continue;
            String folder = dir.getName();
            if (folder.startsWith("_") || folder.startsWith(".")) continue;
            File index = new File(dir, "index.html");
            if (!index.isFile()) continue;

            App app = new App();
            app.folder = folder;
            app.dir = dir;
            app.index = index;
            app.icon = new File(dir, "icon.png");
            app.meta = HtmlAppsMeta.load(dir);
            app.name = app.meta.name == null || app.meta.name.trim().isEmpty()
                    ? folder : app.meta.name.trim();
            if (app.meta.sizeBytes <= 0) {
                app.meta.sizeBytes = dirSize(dir);
                app.meta.save(dir);
            }
            out.add(app);
        }
        return out;
    }

    public static List<App> filter(List<App> source, String search, String category, String sort) {
        String query = search == null ? "" : search.trim().toLowerCase(Locale.getDefault());
        List<App> apps = new ArrayList<>();
        for (App app : source) {
            String haystack = (app.name + " " + app.folder + " " + app.meta.description + " "
                    + app.meta.category + " " + joinTags(app.meta.tags)).toLowerCase(Locale.getDefault());
            if (!query.isEmpty() && !haystack.contains(query)) continue;
            if ("fav".equals(category)) {
                if (!app.meta.favorite) continue;
            } else if (category != null && !category.isEmpty() && !"all".equals(category)) {
                if (!category.equals(app.meta.category)) continue;
            }
            apps.add(app);
        }
        if ("name".equals(sort)) {
            Collections.sort(apps, (a, b) -> a.name.compareToIgnoreCase(b.name));
        } else if ("used".equals(sort)) {
            Collections.sort(apps, (a, b) -> Long.compare(b.meta.lastUsedAt, a.meta.lastUsedAt));
        } else if ("size".equals(sort)) {
            Collections.sort(apps, (a, b) -> Long.compare(b.meta.sizeBytes, a.meta.sizeBytes));
        } else {
            Collections.sort(apps, (a, b) -> Long.compare(b.meta.createdAt, a.meta.createdAt));
        }
        return apps;
    }

    public static List<String> allCategories(File root) {
        List<String> categories = new ArrayList<>();
        for (App app : list(root)) {
            String category = app.meta.category;
            if (category != null && !category.isEmpty() && !categories.contains(category)) {
                categories.add(category);
            }
        }
        return categories;
    }

    public static void deleteDir(File dir) {
        if (dir == null) return;
        if (dir.isDirectory()) {
            File[] children = dir.listFiles();
            if (children != null) for (File child : children) deleteDir(child);
        }
        dir.delete();
    }

    public static long dirSize(File dir) {
        long total = 0;
        File[] children = dir == null ? null : dir.listFiles();
        if (children != null) {
            for (File child : children) {
                total += child.isDirectory() ? dirSize(child) : child.length();
            }
        }
        return total;
    }

    public static String size(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.getDefault(), "%.1f KB", bytes / 1024f);
        return String.format(Locale.getDefault(), "%.1f MB", bytes / (1024f * 1024f));
    }

    public static String joinTags(List<String> tags) {
        if (tags == null || tags.isEmpty()) return "";
        StringBuilder builder = new StringBuilder();
        for (String tag : tags) {
            if (builder.length() > 0) builder.append(' ');
            builder.append(tag);
        }
        return builder.toString();
    }

    public static Set<String> folders(List<App> apps) {
        Set<String> out = new LinkedHashSet<>();
        for (App app : apps) out.add(app.folder);
        return out;
    }

    // ---------------------------------------------------------------- recycle bin

    public static File trashDir() {
        File dir = new File(root(), TRASH);
        if (!dir.isDirectory()) dir.mkdirs();
        return dir;
    }

    /** Returns null on success, otherwise a short user-facing reason. */
    public static String moveToTrash(String folder) {
        if (folder == null || folder.isEmpty()) return "klasör adı yok";
        File source = new File(root(), folder);
        if (!source.isDirectory()) return "uygulama bulunamadı";
        File trash = trashDir();
        File target = new File(trash, folder);
        int suffix = 2;
        while (target.exists()) target = new File(trash, folder + "-" + suffix++);
        if (source.renameTo(target)) return null;
        try {
            copyDir(source, target);
            deleteDir(source);
            return null;
        } catch (Exception e) {
            deleteDir(target);
            return e.getMessage() == null ? "taşınamadı" : e.getMessage();
        }
    }

    public static List<App> trashApps() {
        List<App> out = new ArrayList<>();
        File[] dirs = trashDir().listFiles();
        if (dirs == null) return out;
        for (File dir : dirs) {
            if (!dir.isDirectory()) continue;
            File index = new File(dir, "index.html");
            if (!index.isFile()) continue;
            App app = new App();
            app.folder = dir.getName();
            app.dir = dir;
            app.index = index;
            app.icon = new File(dir, "icon.png");
            app.meta = HtmlAppsMeta.load(dir);
            app.name = app.meta.name == null || app.meta.name.trim().isEmpty()
                    ? dir.getName() : app.meta.name.trim();
            out.add(app);
        }
        return out;
    }

    public static boolean restoreFromTrash(String folder) {
        File source = new File(trashDir(), folder);
        if (!source.isDirectory()) return false;
        File target = new File(root(), folder);
        if (target.exists()) {
            String base = folder;
            int suffix = 2;
            while (target.exists()) target = new File(root(), base + "-" + suffix++);
        }
        if (source.renameTo(target)) return true;
        try {
            copyDir(source, target);
            deleteDir(source);
            return true;
        } catch (Exception e) {
            deleteDir(target);
            return false;
        }
    }

    public static void copyDir(File source, File target) throws Exception {
        if (source.isDirectory()) {
            if (!target.exists() && !target.mkdirs()) throw new Exception("klasör açılamadı");
            File[] children = source.listFiles();
            if (children != null) for (File child : children) {
                copyDir(child, new File(target, child.getName()));
            }
        } else {
            File parent = target.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            try (InputStream in = new FileInputStream(source);
                 OutputStream out = new FileOutputStream(target)) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = in.read(buffer)) > 0) out.write(buffer, 0, read);
            }
        }
    }

    /** Icon bitmap for the library grid, generated from the manifest when icon.png is missing. */
    public static Bitmap loadIcon(App app) {
        if (app.icon != null && app.icon.isFile()) {
            Bitmap bitmap = BitmapFactory.decodeFile(app.icon.getAbsolutePath());
            if (bitmap != null) return bitmap;
        }
        int size = 192;
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        int color = Color.parseColor("#3F51B5");
        try {
            color = Color.parseColor(app.meta.iconColor);
        } catch (Exception ignored) {
        }
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(color);
        canvas.drawRoundRect(0, 0, size, size, 44, 44, paint);
        paint.setColor(Color.WHITE);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(size * 0.52f);
        Paint.FontMetrics metrics = paint.getFontMetrics();
        float centerY = size / 2f - (metrics.ascent + metrics.descent) / 2f;
        String emoji = app.meta.iconEmoji == null || app.meta.iconEmoji.isEmpty()
                ? "📱" : app.meta.iconEmoji;
        canvas.drawText(emoji, size / 2f, centerY, paint);
        return bitmap;
    }

    public static void touch(File root, App app) {
        app.meta.lastUsedAt = System.currentTimeMillis();
        app.meta.openCount++;
        app.meta.save(new File(root, app.folder));
    }
}
