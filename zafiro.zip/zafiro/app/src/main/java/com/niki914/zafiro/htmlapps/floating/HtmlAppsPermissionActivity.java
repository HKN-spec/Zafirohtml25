package com.niki914.zafiro.htmlapps.floating;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;

/** Transparent permission trampoline for the overlay service (camera / microphone). */
public class HtmlAppsPermissionActivity extends Activity {

    public static final String EXTRA_MODE = "mode";
    public static final String MODE_CAMERA = "camera";
    public static final String MODE_MIC = "mic";
    public static final String MODE_ALL = "all";

    private static final int REQ_PERMISSION = 91;
    private String mode = MODE_CAMERA;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mode = getIntent().getStringExtra(EXTRA_MODE);
        if (mode == null) mode = MODE_CAMERA;
        if (MODE_ALL.equals(mode)) {
            String[] all = {Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO};
            boolean allGranted = true;
            for (String permission : all) {
                if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                finish();
            } else {
                requestPermissions(all, REQ_PERMISSION);
            }
            return;
        }
        String permission = MODE_MIC.equals(mode)
                ? Manifest.permission.RECORD_AUDIO : Manifest.permission.CAMERA;
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) {
            HtmlAppsFloatingButtonService.notifyPermission(mode, true);
            finish();
            return;
        }
        requestPermissions(new String[]{permission}, REQ_PERMISSION);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean granted = requestCode == REQ_PERMISSION
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (MODE_ALL.equals(mode)) {
            finish();
            return;
        }
        HtmlAppsFloatingButtonService.notifyPermission(mode, granted);
        finish();
    }
}
