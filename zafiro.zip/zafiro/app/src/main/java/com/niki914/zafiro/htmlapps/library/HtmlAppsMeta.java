package com.niki914.zafiro.htmlapps.library;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Library metadata stored as {@code manifest.json} inside an app folder.
 *
 * Apps published before the manifest existed only carry {@code _app.json}; {@link #load(File)}
 * falls back to it so names, descriptions and the icon emoji survive an upgrade. Saving always
 * writes manifest.json, which then becomes the single source of truth.
 */
public class HtmlAppsMeta {

    public String folder = "";
    public String name = "";
    public String description = "";
    public List<String> tags = new ArrayList<>();
    public String category = "Genel";
    public boolean favorite = false;
    public long createdAt = 0;
    public long lastUsedAt = 0;
    public int openCount = 0;
    public int version = 1;
    public String iconEmoji = "📱";
    public String iconColor = "#3F51B5";
    public long sizeBytes = 0;
    /** Minimum runtime bridge generation this app needs; empty means "no requirement". */
    public String minRuntime = "";

    public static File metaFile(File appDir) {
        return new File(appDir, "manifest.json");
    }

    public static HtmlAppsMeta load(File appDir) {
        HtmlAppsMeta meta = new HtmlAppsMeta();
        meta.folder = appDir.getName();
        meta.name = meta.folder;
        meta.createdAt = appDir.lastModified();
        File manifest = metaFile(appDir);
        try {
            if (manifest.isFile()) {
                JSONObject o = new JSONObject(readText(manifest));
                meta.name = o.optString("name", meta.folder);
                meta.description = o.optString("description", "");
                meta.category = o.optString("category", "Genel");
                meta.favorite = o.optBoolean("favorite", false);
                meta.createdAt = o.optLong("createdAt", meta.createdAt);
                meta.lastUsedAt = o.optLong("lastUsedAt", 0);
                meta.openCount = o.optInt("openCount", 0);
                meta.version = Math.max(1, o.optInt("version", 1));
                meta.iconEmoji = o.optString("iconEmoji", "📱");
                meta.iconColor = o.optString("iconColor", "#3F51B5");
                meta.sizeBytes = o.optLong("sizeBytes", 0);
                meta.minRuntime = o.optString("minRuntime", "");
                JSONArray tagArray = o.optJSONArray("tags");
                if (tagArray != null) {
                    for (int i = 0; i < tagArray.length(); i++) {
                        String tag = tagArray.optString(i, "");
                        if (!tag.isEmpty()) meta.tags.add(tag);
                    }
                }
                return meta;
            }
            File legacy = new File(appDir, "_app.json");
            if (legacy.isFile()) {
                JSONObject o = new JSONObject(readText(legacy));
                meta.name = o.optString("name", meta.folder);
                meta.description = o.optString("description", "");
                meta.iconEmoji = o.optString("icon", meta.iconEmoji);
                meta.iconColor = o.optString("bg", meta.iconColor);
                meta.createdAt = o.optLong("updated", meta.createdAt);
                meta.version = Math.max(1, o.optInt("attempts", 1));
            }
        } catch (Exception ignored) {
        }
        return meta;
    }

    public void save(File appDir) {
        if (appDir == null) return;
        if (!appDir.exists()) appDir.mkdirs();
        try {
            JSONObject o = new JSONObject();
            o.put("name", name == null ? "" : name);
            o.put("description", description == null ? "" : description);
            o.put("category", category == null || category.isEmpty() ? "Genel" : category);
            o.put("favorite", favorite);
            o.put("createdAt", createdAt);
            o.put("lastUsedAt", lastUsedAt);
            o.put("openCount", openCount);
            o.put("version", version);
            o.put("iconEmoji", iconEmoji == null ? "📱" : iconEmoji);
            o.put("iconColor", iconColor == null ? "#3F51B5" : iconColor);
            o.put("sizeBytes", sizeBytes);
            o.put("minRuntime", minRuntime == null ? "" : minRuntime);
            JSONArray tagArray = new JSONArray();
            if (tags != null) for (String tag : tags) tagArray.put(tag);
            o.put("tags", tagArray);
            try (FileOutputStream out = new FileOutputStream(metaFile(appDir))) {
                out.write(o.toString(2).getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) {
        }
    }

    public static String readText(File file) throws Exception {
        try (FileInputStream in = new FileInputStream(file)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) > 0) out.write(buffer, 0, read);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
