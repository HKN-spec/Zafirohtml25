package com.niki914.zafiro.htmlapps.avatar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

/**
 * Small on-screen character ("Nova") drawn with Canvas primitives.
 *
 * The view is only the character; the full-screen {@link AvatarEffectsView} owns long pointing
 * lines, circles, underlines and pen trails so those can extend past this small window.
 */
public class AvatarView extends View {

    public interface TouchListener {
        void onMove(float dx, float dy);
        void onTap();
    }

    private static final int SKIN = 0xFFFFD7B5;
    private static final int SKIN_SHADOW = 0xFFE8B98F;
    private static final int HAIR = 0xFF3A2A22;
    private static final int HOODIE = 0xFF3F8CFF;
    private static final int HOODIE_DARK = 0xFF2D6ED0;
    private static final int PANTS = 0xFF2B3A55;
    private static final int SHOE = 0xFF1F2937;
    private static final int ACCENT = 0xFFFFC857;
    private static final int INK = 0xFF1B2430;

    private int hoodie = HOODIE;
    private int hoodieDark = HOODIE_DARK;
    private int accent = ACCENT;
    private String style = "nova";

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();
    private final float density;

    private boolean walking;
    private float walkPhase;
    private boolean pointing;
    private float pointX;
    private float pointY;
    private long tapUntil;
    private String speech = "";
    private StaticLayout speechLayout;
    private String speechLayoutText = "";
    private String mood = "happy";
    private boolean blink;
    private TouchListener touchListener;

    private float downRawX;
    private float downRawY;
    private float lastRawX;
    private float lastRawY;
    private boolean dragging;
    private final int touchSlop;

    private final Runnable blinkRunnable = new Runnable() {
        @Override public void run() {
            blink = !blink;
            invalidate();
            postDelayed(this, blink ? 130 : 3200);
        }
    };

    public AvatarView(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void setTouchListener(TouchListener listener) {
        this.touchListener = listener;
    }

    public void setWalking(boolean walking, float phase) {
        this.walking = walking;
        this.walkPhase = phase;
        invalidate();
    }

    public void setPointing(boolean pointing, float x, float y) {
        this.pointing = pointing;
        this.pointX = x;
        this.pointY = y;
        invalidate();
    }

    public void tapPulse() {
        tapUntil = System.currentTimeMillis() + 260;
        invalidate();
        postDelayed(this::invalidate, 280);
    }

    public void setSpeech(String text) {
        this.speech = text == null ? "" : text;
        invalidate();
    }

    public void setMood(String mood) {
        this.mood = mood == null ? "happy" : mood;
        invalidate();
    }

    /** Six colour themes; the face/body proportions stay the same. */
    public void setStyle(String style) {
        this.style = style == null ? "nova" : style;
        switch (this.style) {
            case "pink":
                hoodie = 0xFFE91E63; hoodieDark = 0xFFAD1457; accent = 0xFFFFD54F; break;
            case "green":
                hoodie = 0xFF2E7D32; hoodieDark = 0xFF1B5E20; accent = 0xFFFFEB3B; break;
            case "purple":
                hoodie = 0xFF7C4DFF; hoodieDark = 0xFF5E35B1; accent = 0xFFFFD740; break;
            case "ocean":
                hoodie = 0xFF00838F; hoodieDark = 0xFF006064; accent = 0xFFFFAB40; break;
            case "sunset":
                hoodie = 0xFFFF7043; hoodieDark = 0xFFE64A19; accent = 0xFFFFD54F; break;
            default:
                hoodie = HOODIE; hoodieDark = HOODIE_DARK; accent = ACCENT; break;
        }
        invalidate();
    }

    public String getStyle() { return style; }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        postDelayed(blinkRunnable, 2600);
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(blinkRunnable);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float scale = Math.min(getWidth() / 180f, getHeight() / 280f);
        if (scale <= 0f) return;
        canvas.save();
        canvas.scale(scale, scale);

        float swing = walking ? (float) Math.sin(walkPhase * Math.PI * 2.0) * 12f : 0f;
        float bob = walking ? (float) Math.abs(Math.sin(walkPhase * Math.PI * 2.0)) * 3f : 0f;
        float baseY = 252f - bob;

        // Soft shadow
        fill.setColor(0x33000000);
        canvas.drawOval(new RectF(50, baseY + 8, 130, baseY + 22), fill);

        // Legs
        drawLimb(canvas, 74, 196, 70 + swing, baseY, 18f, PANTS);
        drawLimb(canvas, 106, 196, 110 - swing, baseY, 18f, PANTS);
        fill.setColor(SHOE);
        canvas.drawRoundRect(new RectF(58 + swing, baseY - 4, 86 + swing, baseY + 10), 7, 7, fill);
        canvas.drawRoundRect(new RectF(98 - swing, baseY - 4, 126 - swing, baseY + 10), 7, 7, fill);

        // Body (hoodie)
        fill.setColor(hoodie);
        rect.set(56, 118, 124, 212);
        canvas.drawRoundRect(rect, 26, 26, fill);
        // A soft pocket seam instead of the old horizontal rectangle.
        stroke.setColor(hoodieDark);
        stroke.setStrokeWidth(2f);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        rect.set(72, 182, 108, 202);
        canvas.drawArc(rect, 200, 140, false, stroke);
        fill.setColor(0x66FFFFFF);
        canvas.drawCircle(90, 150, 15, fill);
        fill.setColor(accent);
        path.reset();
        path.moveTo(90, 141);
        path.lineTo(95, 150);
        path.lineTo(90, 159);
        path.lineTo(85, 150);
        path.close();
        canvas.drawPath(path, fill);

        // Arms
        float leftHandY = 178 + (walking ? -swing * 0.55f : 0);
        float rightHandY = 178 + (walking ? swing * 0.55f : 0);
        if (pointing) {
            drawPointingArm(canvas, rightHandY);
        } else {
            drawArm(canvas, 60, 136, 40, leftHandY);
            drawArm(canvas, 120, 136, 140, rightHandY);
        }

        // Head
        fill.setColor(SKIN);
        canvas.drawCircle(90, 80, 40, fill);

        // Hair
        fill.setColor(HAIR);
        rect.set(50, 40, 130, 88);
        canvas.drawArc(rect, 180, 180, true, fill);
        rect.set(48, 60, 70, 92);
        canvas.drawRoundRect(rect, 12, 12, fill);
        rect.set(110, 60, 132, 92);
        canvas.drawRoundRect(rect, 12, 12, fill);

        // Face
        drawFace(canvas);

        // Speech bubble
        if (speech != null && !speech.isEmpty()) drawSpeech(canvas);

        canvas.restore();
    }

    private void drawFace(Canvas canvas) {
        fill.setColor(INK);
        if (blink) {
            stroke.setColor(INK);
            stroke.setStrokeWidth(3.2f);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            canvas.drawLine(70, 79, 82, 79, stroke);
            canvas.drawLine(98, 79, 110, 79, stroke);
        } else {
            canvas.drawCircle(76, 78, 4.2f, fill);
            canvas.drawCircle(104, 78, 4.2f, fill);
            fill.setColor(0xFFFFFFFF);
            canvas.drawCircle(77.5f, 76.5f, 1.3f, fill);
            canvas.drawCircle(105.5f, 76.5f, 1.3f, fill);
        }
        // Eyebrows
        stroke.setColor(HAIR);
        stroke.setStrokeWidth(2.6f);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        if ("thinking".equals(mood)) {
            canvas.drawLine(68, 66, 82, 63, stroke);
            canvas.drawLine(98, 63, 112, 66, stroke);
        } else if ("sad".equals(mood)) {
            canvas.drawLine(68, 64, 82, 68, stroke);
            canvas.drawLine(98, 68, 112, 64, stroke);
        } else {
            canvas.drawLine(68, 66, 82, 65, stroke);
            canvas.drawLine(98, 65, 112, 66, stroke);
        }

        // Nose
        stroke.setColor(SKIN_SHADOW);
        stroke.setStrokeWidth(2.4f);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        path.reset();
        path.moveTo(87, 87);
        path.quadTo(84, 94, 90, 96);
        canvas.drawPath(path, stroke);

        // Mouth
        stroke.setColor(0xFF8A4B3A);
        stroke.setStrokeWidth(3f);
        if ("wow".equals(mood)) {
            fill.setColor(0xFF8A4B3A);
            canvas.drawOval(new RectF(84, 96, 96, 108), fill);
        } else if ("sad".equals(mood)) {
            rect.set(78, 104, 102, 116);
            canvas.drawArc(rect, 200, 140, false, stroke);
        } else if ("thinking".equals(mood)) {
            canvas.drawLine(84, 102, 96, 102, stroke);
        } else {
            rect.set(78, 94, 102, 112);
            canvas.drawArc(rect, 20, 140, false, stroke);
        }
    }

    private void drawPointingArm(Canvas canvas, float fallbackY) {
        float shoulderX = 120;
        float shoulderY = 136;
        float tx = pointX;
        float ty = pointY;
        if (tx == 0 && ty == 0) {
            tx = 160;
            ty = fallbackY - 30;
        }
        // The arm never stretches: the whole character glides so this fixed hand stays on the
        // cursor. Clamping keeps a tool-driven target inside the drawing.
        float dx = tx - shoulderX;
        float dy = ty - shoulderY;
        float length = (float) Math.sqrt(dx * dx + dy * dy);
        float max = 64f;
        if (length > max && length > 0) {
            tx = shoulderX + dx / length * max;
            ty = shoulderY + dy / length * max;
        }
        drawArm(canvas, shoulderX, shoulderY, tx, ty);
        drawHand(canvas, tx, ty);
    }

    private void drawLimb(Canvas canvas, float x1, float y1, float x2, float y2,
                          float width, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(width);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        canvas.drawLine(x1, y1, x2, y2, stroke);
    }

    private void drawArm(Canvas canvas, float x1, float y1, float x2, float y2) {
        stroke.setColor(SKIN);
        stroke.setStrokeWidth(13f);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        canvas.drawLine(x1, y1, x2, y2, stroke);
        drawHand(canvas, x2, y2);
    }

    private void drawHand(Canvas canvas, float x, float y) {
        fill.setColor(SKIN);
        canvas.drawCircle(x, y, 7.5f, fill);
        stroke.setColor(SKIN_SHADOW);
        stroke.setStrokeWidth(1.8f);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        for (int i = -1; i <= 1; i++) {
            canvas.drawLine(x + i * 3.2f, y + 2, x + i * 4.2f, y + 8, stroke);
        }
    }

    private void drawSpeech(Canvas canvas) {
        if (speechLayout == null || !speech.equals(speechLayoutText)) {
            TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            textPaint.setColor(INK);
            textPaint.setTextSize(10.5f);
            speechLayout = StaticLayout.Builder
                    .obtain(speech, 0, speech.length(), textPaint, 158)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setMaxLines(3)
                    .setEllipsize(TextUtils.TruncateAt.END)
                    .build();
            speechLayoutText = speech;
        }
        StaticLayout layout = speechLayout;
        int textHeight = layout.getHeight();
        float top = Math.max(2, 58 - textHeight);
        rect.set(11, top, 169, top + textHeight + 14);
        fill.setColor(0xF2FFFFFF);
        canvas.drawRoundRect(rect, 12, 12, fill);
        stroke.setColor(hoodieDark);
        stroke.setStrokeWidth(1.6f);
        canvas.drawRoundRect(rect, 12, 12, stroke);
        // Tail
        path.reset();
        path.moveTo(78, rect.bottom - 1);
        path.lineTo(90, rect.bottom + 10);
        path.lineTo(100, rect.bottom - 1);
        path.close();
        fill.setColor(0xF2FFFFFF);
        canvas.drawPath(path, fill);
        stroke.setColor(hoodieDark);
        canvas.drawLine(78, rect.bottom - 1, 90, rect.bottom + 10, stroke);
        canvas.drawLine(100, rect.bottom - 1, 90, rect.bottom + 10, stroke);
        canvas.save();
        canvas.translate(18, top + 7);
        layout.draw(canvas);
        canvas.restore();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downRawX = lastRawX = event.getRawX();
                downRawY = lastRawY = event.getRawY();
                dragging = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                float dx = event.getRawX() - lastRawX;
                float dy = event.getRawY() - lastRawY;
                if (Math.abs(event.getRawX() - downRawX) > touchSlop
                        || Math.abs(event.getRawY() - downRawY) > touchSlop) {
                    dragging = true;
                }
                if (dragging && touchListener != null) touchListener.onMove(dx, dy);
                lastRawX = event.getRawX();
                lastRawY = event.getRawY();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (!dragging) performClick();
                return true;
            default:
                return false;
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        if (touchListener != null) touchListener.onTap();
        return true;
    }
}
