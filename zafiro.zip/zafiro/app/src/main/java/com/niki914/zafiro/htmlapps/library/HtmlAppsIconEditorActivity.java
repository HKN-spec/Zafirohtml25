package com.niki914.zafiro.htmlapps.library;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Icon editor: 32 emoji, 16 colours or a gallery image; renders icon.png. */
public class HtmlAppsIconEditorActivity extends Activity {

    public static final String EXTRA_APP_FOLDER = "app_folder";

    private static final String[] EMOJIS = {
            "📱", "📝", "✅", "🧮", "⏱️", "📊", "📷", "🎙️",
            "🖼️", "📺", "🌤️", "🔄", "🎲", "👤", "⏰", "📻",
            "🎵", "📖", "🔧", "🎮", "💡", "🍕", "☕", "🏠",
            "🚗", "✈️", "💰", "📅", "🎯", "❤️", "⭐", "🔒"
    };

    private static final String[] COLORS = {
            "#3F51B5", "#E91E63", "#9C27B0", "#673AB7",
            "#2196F3", "#00BCD4", "#009688", "#4CAF50",
            "#8BC34A", "#FFC107", "#FF9800", "#FF5722",
            "#795548", "#607D8B", "#3949AB", "#5C6BC0"
    };

    private File appDir;
    private String currentEmoji = "📱";
    private String currentColor = "#3F51B5";
    private Bitmap customBitmap;
    private ImageView preview;
    private TextView emojiHint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String folder = getIntent().getStringExtra(EXTRA_APP_FOLDER);
        if (folder == null || folder.isEmpty()) {
            finish();
            return;
        }
        appDir = new File(HtmlAppsRepo.root(), folder);
        if (!appDir.isDirectory()) {
            finish();
            return;
        }
        HtmlAppsMeta meta = HtmlAppsMeta.load(appDir);
        currentEmoji = meta.iconEmoji == null || meta.iconEmoji.isEmpty() ? "📱" : meta.iconEmoji;
        currentColor = meta.iconColor == null || meta.iconColor.isEmpty() ? "#3F51B5" : meta.iconColor;
        File icon = new File(appDir, "icon.png");
        if (icon.isFile()) {
            Bitmap bitmap = BitmapFactory.decodeFile(icon.getAbsolutePath());
            if (bitmap != null) customBitmap = bitmap;
        }

        int pad = dp(16);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Simgeyi düzenle");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(22);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        body.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText(folder);
        subtitle.setTextColor(0xFF8FA3BF);
        subtitle.setTextSize(12);
        subtitle.setPadding(0, dp(2), 0, dp(12));
        body.addView(subtitle);

        preview = new ImageView(this);
        LinearLayout.LayoutParams previewParams =
                new LinearLayout.LayoutParams(dp(160), dp(160));
        previewParams.gravity = Gravity.CENTER_HORIZONTAL;
        previewParams.bottomMargin = pad;
        body.addView(preview, previewParams);
        renderPreview();

        emojiHint = new TextView(this);
        emojiHint.setText("Emoji");
        emojiHint.setTextColor(0xFFDCE7FF);
        emojiHint.setTextSize(14);
        emojiHint.setPadding(0, dp(8), 0, dp(6));
        body.addView(emojiHint);

        LinearLayout emojiGrid = new LinearLayout(this);
        emojiGrid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout emojiRow = null;
        for (int i = 0; i < EMOJIS.length; i++) {
            if (i % 8 == 0) {
                emojiRow = new LinearLayout(this);
                emojiRow.setOrientation(LinearLayout.HORIZONTAL);
                emojiGrid.addView(emojiRow);
            }
            TextView cell = new TextView(this);
            cell.setText(EMOJIS[i]);
            cell.setTextSize(22);
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(dp(4), dp(4), dp(4), dp(4));
            cell.setLayoutParams(new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            final String emoji = EMOJIS[i];
            cell.setOnClickListener(v -> {
                currentEmoji = emoji;
                customBitmap = null;
                renderPreview();
            });
            emojiRow.addView(cell);
        }
        body.addView(emojiGrid);

        TextView colorLabel = new TextView(this);
        colorLabel.setText("Renk");
        colorLabel.setTextColor(0xFFDCE7FF);
        colorLabel.setTextSize(14);
        colorLabel.setPadding(0, pad, 0, dp(6));
        body.addView(colorLabel);

        LinearLayout colorGrid = new LinearLayout(this);
        colorGrid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout colorRow = null;
        for (int i = 0; i < COLORS.length; i++) {
            if (i % 8 == 0) {
                colorRow = new LinearLayout(this);
                colorRow.setOrientation(LinearLayout.HORIZONTAL);
                colorGrid.addView(colorRow);
            }
            View cell = new View(this);
            LinearLayout.LayoutParams cellParams =
                    new LinearLayout.LayoutParams(0, dp(38), 1f);
            int margin = dp(4);
            cellParams.setMargins(margin, margin, margin, margin);
            cell.setLayoutParams(cellParams);
            final int color = Color.parseColor(COLORS[i]);
            cell.setBackgroundColor(color);
            final String hex = COLORS[i];
            cell.setOnClickListener(v -> {
                currentColor = hex;
                customBitmap = null;
                renderPreview();
            });
            colorRow.addView(cell);
        }
        body.addView(colorGrid);

        Button suggest = new Button(this);
        suggest.setText("✨ İsimden simge öner");
        suggest.setTextSize(13);
        suggest.setBackgroundColor(0xFF2E7D32);
        suggest.setTextColor(0xFFFFFFFF);
        suggest.setPadding(dp(12), dp(8), dp(12), dp(8));
        LinearLayout.LayoutParams suggestParams =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
        suggestParams.topMargin = pad;
        body.addView(suggest, suggestParams);
        suggest.setOnClickListener(v -> suggestIcon());

        Button gallery = new Button(this);
        gallery.setText("🖼 Galeriden resim seç");
        gallery.setTextSize(13);
        gallery.setBackgroundColor(0xFF1E2838);
        gallery.setTextColor(0xFFFFFFFF);
        gallery.setPadding(dp(12), dp(8), dp(12), dp(8));
        LinearLayout.LayoutParams galleryParams =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
        galleryParams.topMargin = pad;
        body.addView(gallery, galleryParams);
        gallery.setOnClickListener(v -> pickImage());

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, pad, 0, 0);
        body.addView(actions);

        Button cancel = new Button(this);
        cancel.setText("İptal");
        cancel.setBackgroundColor(0xFF2A3444);
        cancel.setTextColor(0xFFFFFFFF);
        cancel.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        actions.addView(cancel);
        cancel.setOnClickListener(v -> finish());

        Button save = new Button(this);
        save.setText("Kaydet");
        save.setBackgroundColor(0xFF3F8CFF);
        save.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams saveParams =
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        saveParams.leftMargin = dp(8);
        save.setLayoutParams(saveParams);
        actions.addView(save);
        save.setOnClickListener(v -> save());

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFF0B0F16);
        scroll.addView(body);
        setContentView(scroll);
    }

    private void suggestIcon() {
        try {
            String html = HtmlAppsMeta.readText(new File(appDir, "index.html"));
            HtmlAppsIconSuggest.Suggestion suggestion =
                    HtmlAppsIconSuggest.suggest(appDir.getName(), html);
            currentEmoji = suggestion.emoji;
            currentColor = String.format("#%06X", 0xFFFFFF & suggestion.color);
            customBitmap = null;
            renderPreview();
            toast("Öneri: " + currentEmoji);
        } catch (Exception e) {
            toast("index.html okunamadı");
        }
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, 41);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 41 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                Bitmap bitmap = BitmapFactory.decodeStream(in);
                if (bitmap != null) {
                    customBitmap = square(bitmap, 512);
                    renderPreview();
                }
            } catch (Exception e) {
                toast("Resim okunamadı");
            }
        }
    }

    private void renderPreview() {
        if (preview == null) return;
        if (customBitmap != null) {
            preview.setImageBitmap(customBitmap);
            return;
        }
        Bitmap bitmap = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.parseColor(currentColor));
        canvas.drawRoundRect(0, 0, 192, 192, 44, 44, paint);
        paint.setColor(Color.WHITE);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(100);
        Paint.FontMetrics metrics = paint.getFontMetrics();
        canvas.drawText(currentEmoji, 96, 96 - (metrics.ascent + metrics.descent) / 2f, paint);
        preview.setImageBitmap(bitmap);
    }

    private void save() {
        try {
            HtmlAppsMeta meta = HtmlAppsMeta.load(appDir);
            meta.iconEmoji = currentEmoji;
            meta.iconColor = currentColor;
            meta.save(appDir);
            File icon = new File(appDir, "icon.png");
            if (customBitmap != null) {
                try (FileOutputStream out = new FileOutputStream(icon)) {
                    customBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                }
            } else {
                HtmlAppsIconGenerator.render(icon, currentEmoji, Color.parseColor(currentColor));
            }
            new HtmlAppsVersions(appDir).snapshot("Simge güncellendi");
            toast("Simge kaydedildi");
            finish();
        } catch (Exception e) {
            toast("Kaydedilemedi: " + e.getMessage());
        }
    }

    private static Bitmap square(Bitmap source, int size) {
        int edge = Math.min(source.getWidth(), source.getHeight());
        int left = (source.getWidth() - edge) / 2;
        int top = (source.getHeight() - edge) / 2;
        Bitmap crop = Bitmap.createBitmap(source, left, top, edge, edge);
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        canvas.drawBitmap(crop, new Rect(0, 0, edge, edge), new Rect(0, 0, size, size),
                new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
        return out;
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}
