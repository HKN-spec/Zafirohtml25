package com.niki914.zafiro.htmlapps.library;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.List;

/** Version history with one-tap restore; the current document is snapshotted before restoring. */
public class HtmlAppsVersionsActivity extends Activity {

    public static final String EXTRA_APP_FOLDER = "app_folder";

    private String folder;
    private File appDir;
    private HtmlAppsVersions store;
    private LinearLayout list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        folder = getIntent().getStringExtra(EXTRA_APP_FOLDER);
        if (folder == null || folder.isEmpty()) {
            finish();
            return;
        }
        appDir = new File(HtmlAppsRepo.root(), folder);
        if (!appDir.isDirectory()) {
            finish();
            return;
        }
        store = new HtmlAppsVersions(appDir);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(0xFF0B0F16);
        int pad = dp(16);
        main.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Sürüm geçmişi");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        main.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText(folder);
        subtitle.setTextColor(0xFF8FA3BF);
        subtitle.setTextSize(12);
        subtitle.setPadding(0, dp(2), 0, dp(12));
        main.addView(subtitle);

        Button snapshot = new Button(this);
        snapshot.setText("＋ Şimdiki sürümü kaydet");
        snapshot.setBackgroundColor(0xFF3F8CFF);
        snapshot.setTextColor(Color.WHITE);
        main.addView(snapshot, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        snapshot.setOnClickListener(v -> saveSnapshot());

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(12), 0, dp(12));
        scroll.addView(list);
        main.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(main);
        renderList();
    }

    private void saveSnapshot() {
        try {
            HtmlAppsVersions.Version version = store.snapshot("Elle kayıt");
            toast(version == null ? "Kaydedilecek index.html yok" : "Sürüm kaydedildi");
            renderList();
        } catch (Exception e) {
            toast("Kaydedilemedi: " + e.getMessage());
        }
    }

    private void renderList() {
        list.removeAllViews();
        List<HtmlAppsVersions.Version> versions = store.list();
        if (versions.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Henüz sürüm yok. Simge düzenlemesi ve üretim sonrası sürümler "
                    + "burada birikir.");
            empty.setTextColor(0xFF8FA3BF);
            empty.setTextSize(13);
            empty.setPadding(dp(4), dp(20), dp(4), dp(20));
            list.addView(empty);
            return;
        }
        for (final HtmlAppsVersions.Version version : versions) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(14), dp(12), dp(14), dp(12));
            android.graphics.drawable.GradientDrawable background =
                    new android.graphics.drawable.GradientDrawable();
            background.setColor(0xFF151C27);
            background.setCornerRadius(dp(14));
            row.setBackground(background);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.bottomMargin = dp(8);
            row.setLayoutParams(params);

            TextView head = new TextView(this);
            head.setText("v" + version.index + " · " + version.timestamp);
            head.setTextColor(Color.WHITE);
            head.setTextSize(14);
            row.addView(head);

            TextView meta = new TextView(this);
            String note = version.note == null || version.note.isEmpty() ? "Sürüm" : version.note;
            meta.setText(note + " · " + HtmlAppsRepo.size(version.size));
            meta.setTextColor(0xFF8FA3BF);
            meta.setTextSize(11);
            row.addView(meta);

            row.setOnClickListener(v -> showVersion(version));
            list.addView(row);
        }
    }

    private void showVersion(final HtmlAppsVersions.Version version) {
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("v" + version.index + " · " + version.timestamp)
                .setItems(new String[]{"👁 Önizle", "↩ Bu sürüme geri dön"}, (dialog, which) -> {
                    if (which == 0) preview(version);
                    else restore(version);
                })
                .setNegativeButton("Kapat", null)
                .show();
    }

    private void preview(HtmlAppsVersions.Version version) {
        try {
            String html = store.loadHtml(version.index);
            if (html == null) {
                toast("Sürüm okunamadı");
                return;
            }
            TextView view = new TextView(this);
            view.setText(html);
            view.setTextSize(10.5f);
            view.setTypeface(Typeface.MONOSPACE);
            view.setTextColor(Color.WHITE);
            view.setPadding(dp(12), dp(12), dp(12), dp(12));
            ScrollView scroll = new ScrollView(this);
            scroll.addView(view);
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                    .setTitle("v" + version.index + " · " + html.length() + " karakter")
                    .setView(scroll)
                    .setPositiveButton("Kapat", null)
                    .show();
        } catch (Exception e) {
            toast("Sürüm okunamadı: " + e.getMessage());
        }
    }

    private void restore(final HtmlAppsVersions.Version version) {
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("v" + version.index + " geri yüklensin mi?")
                .setMessage("Şimdiki index.html önce yeni bir sürüm olarak saklanır.")
                .setNegativeButton("İptal", null)
                .setPositiveButton("Geri yükle", (dialog, which) -> {
                    try {
                        boolean ok = store.restore(version.index, "Geri yükleme öncesi");
                        if (!ok) {
                            toast("Sürüm bulunamadı");
                            return;
                        }
                        toast("✔ Sürüm " + version.index + " geri yüklendi");
                        renderList();
                    } catch (Exception e) {
                        toast("Hata: " + e.getMessage());
                    }
                })
                .show();
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}
