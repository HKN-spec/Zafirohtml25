package com.niki914.zafiro.htmlapps.avatar;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import java.util.ArrayList;
import java.util.List;

/**
 * Full-screen, non-touchable drawing surface for the avatar: circles, underlines, freehand
 * trails and tap ripples. Keeping this in a separate window lets effects go anywhere on the
 * screen without enlarging the avatar's touch area.
 *
 * The pointing arm intentionally is NOT drawn here: a screen-long rubber arm changes thickness
 * and position, so the character's fixed arm (AvatarView) travels with the cursor instead.
 */
public class AvatarEffectsView extends View {

    private static final int TYPE_CIRCLE = 1;
    private static final int TYPE_LINE = 2;
    private static final int TYPE_PATH = 3;
    private static final int TYPE_RIPPLE = 4;

    private static class Shape {
        int type;
        float x, y, r, x2, y2;
        int color;
        float width;
        float progress;
        List<float[]> points;
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();
    private final float density;
    private final List<Shape> shapes = new ArrayList<>();

    private boolean handVisible;
    private float shoulderX, shoulderY, handX, handY;
    private ValueAnimator animator;
    private final Runnable clearRunnable = this::clear;

    public AvatarEffectsView(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void setHand(float sx, float sy, float hx, float hy) {
        // Kept for API compatibility; the fixed arm in AvatarView replaces the stretched arm.
        handVisible = false;
        invalidate();
    }

    public void clearHand() {
        handVisible = false;
        invalidate();
    }

    public void addCircle(float x, float y, float r, int color, long durationMs) {
        Shape s = new Shape();
        s.type = TYPE_CIRCLE;
        s.x = x;
        s.y = y;
        s.r = Math.max(12, r);
        s.color = color;
        s.width = 5f * density;
        shapes.add(s);
        animate(Math.max(250, durationMs));
    }

    public void addLine(float x1, float y1, float x2, float y2, int color, long durationMs) {
        Shape s = new Shape();
        s.type = TYPE_LINE;
        s.x = x1;
        s.y = y1;
        s.x2 = x2;
        s.y2 = y2;
        s.color = color;
        s.width = 6f * density;
        shapes.add(s);
        animate(Math.max(250, durationMs));
    }

    public void addPath(List<float[]> points, int color, float widthDp, long durationMs) {
        if (points == null || points.size() < 2) return;
        Shape s = new Shape();
        s.type = TYPE_PATH;
        s.points = points;
        s.color = color;
        s.width = Math.max(2f, widthDp) * density;
        shapes.add(s);
        animate(Math.max(300, durationMs));
    }

    public void tap(float x, float y) {
        Shape s = new Shape();
        s.type = TYPE_RIPPLE;
        s.x = x;
        s.y = y;
        s.color = 0xFFFFC857;
        s.width = 3f * density;
        shapes.add(s);
        animate(520);
    }

    private void animate(long durationMs) {
        if (animator != null) animator.cancel();
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(durationMs);
        animator.setInterpolator(new DecelerateInterpolator());
        animator.addUpdateListener(a -> {
            float value = (float) a.getAnimatedValue();
            for (Shape s : shapes) s.progress = value;
            invalidate();
        });
        animator.start();
        removeCallbacks(clearRunnable);
        postDelayed(clearRunnable, Math.max(2600, durationMs + 1800));
    }

    public void clear() {
        if (animator != null) animator.cancel();
        shapes.clear();
        clearHand();
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);

        for (Shape s : shapes) {
            paint.setColor(s.color);
            paint.setStrokeWidth(s.width);
            paint.setAlpha(255);
            if (s.type == TYPE_CIRCLE) {
                rect.set(s.x - s.r, s.y - s.r, s.x + s.r, s.y + s.r);
                paint.setAlpha(230);
                canvas.drawArc(rect, -90, 360 * clamp(s.progress), false, paint);
            } else if (s.type == TYPE_LINE) {
                float t = clamp(s.progress);
                canvas.drawLine(s.x, s.y, s.x + (s.x2 - s.x) * t,
                        s.y + (s.y2 - s.y) * t, paint);
            } else if (s.type == TYPE_PATH && s.points != null) {
                path.reset();
                int count = Math.max(2, (int) (s.points.size() * clamp(s.progress)));
                for (int i = 0; i < count && i < s.points.size(); i++) {
                    float[] p = s.points.get(i);
                    if (i == 0) path.moveTo(p[0], p[1]);
                    else path.lineTo(p[0], p[1]);
                }
                canvas.drawPath(path, paint);
            } else if (s.type == TYPE_RIPPLE) {
                float t = clamp(s.progress);
                paint.setAlpha((int) (180 * (1 - t)));
                canvas.drawCircle(s.x, s.y, 8 + 34 * t, paint);
                paint.setAlpha((int) (120 * (1 - t)));
                canvas.drawCircle(s.x, s.y, 4 + 18 * t, paint);
            }
        }
    }

    private static float clamp(float value) {
        return Math.max(0f, Math.min(1f, value));
    }
}
