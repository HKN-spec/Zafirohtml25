package com.niki914.zafiro.htmlapps.floating;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Persistent look-and-feel for the floating ring and its panel, ported from HtmlApps.
 *
 * The panel reads this file every time it opens, so colour/opacity changes apply without a
 * restart. Panel size and ring position are stored too, so a resized panel and a moved ring stay
 * where the user left them.
 */
public final class HtmlAppsFloatStyle {

    private static final String FILE = "float_ui";

    private static final String K_BUBBLE_COLOR = "bubble_color";
    private static final String K_BUBBLE_ALPHA = "bubble_alpha";
    private static final String K_PANEL_COLOR = "panel_color";
    private static final String K_PANEL_ALPHA = "panel_alpha";
    private static final String K_PANEL_W = "panel_w";
    private static final String K_PANEL_H = "panel_h";
    private static final String K_TEXT_COLOR = "text_color";
    private static final String K_TEXT_ALPHA = "text_alpha";
    private static final String K_BUBBLE_X = "bubble_x";
    private static final String K_BUBBLE_Y = "bubble_y";
    private static final String K_SPEAKER = "speaker";
    private static final String K_FONT_SIZE = "font_size";
    private static final String K_EDGE_FADE = "edge_fade";
    private static final String K_AUTO_OPEN = "auto_open";
    private static final String K_REPLY_POSITION = "reply_position";

    public static final int DEFAULT_PANEL_COLOR = 0x1F2330;
    public static final int DEFAULT_PANEL_ALPHA = 242;

    private HtmlAppsFloatStyle() {
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext()
                .getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    /** Inner colour of the ring (ring itself stays white). Default: white with 0 alpha. */
    public static int bubbleColor(Context context) {
        return prefs(context).getInt(K_BUBBLE_COLOR, 0xFFFFFF);
    }

    /** 0..255. */
    public static int bubbleAlpha(Context context) {
        return prefs(context).getInt(K_BUBBLE_ALPHA, 0);
    }

    public static void setBubble(Context context, int color, int alpha) {
        prefs(context).edit()
                .putInt(K_BUBBLE_COLOR, color & 0xFFFFFF)
                .putInt(K_BUBBLE_ALPHA, clamp(alpha))
                .apply();
    }

    public static int panelColor(Context context) {
        return prefs(context).getInt(K_PANEL_COLOR, DEFAULT_PANEL_COLOR);
    }

    public static int panelAlpha(Context context) {
        return prefs(context).getInt(K_PANEL_ALPHA, DEFAULT_PANEL_ALPHA);
    }

    public static void setPanel(Context context, int color, int alpha) {
        prefs(context).edit()
                .putInt(K_PANEL_COLOR, color & 0xFFFFFF)
                .putInt(K_PANEL_ALPHA, clamp(alpha))
                .apply();
    }

    /** Panel text colour, independent from the surface colour. */
    public static int textColor(Context context) {
        return prefs(context).getInt(K_TEXT_COLOR, 0xE8EDF7);
    }

    public static int textAlpha(Context context) {
        return prefs(context).getInt(K_TEXT_ALPHA, 255);
    }

    public static void setTextColor(Context context, int color, int alpha) {
        prefs(context).edit()
                .putInt(K_TEXT_COLOR, color & 0xFFFFFF)
                .putInt(K_TEXT_ALPHA, clamp(alpha))
                .apply();
    }

    public static int panelWidth(Context context) {
        return prefs(context).getInt(K_PANEL_W, 0);
    }

    public static int panelHeight(Context context) {
        return prefs(context).getInt(K_PANEL_H, 0);
    }

    public static void setPanelSize(Context context, int width, int height) {
        prefs(context).edit()
                .putInt(K_PANEL_W, Math.max(0, width))
                .putInt(K_PANEL_H, Math.max(0, height))
                .apply();
    }

    public static int bubbleX(Context context) {
        return prefs(context).getInt(K_BUBBLE_X, -1);
    }

    public static int bubbleY(Context context) {
        return prefs(context).getInt(K_BUBBLE_Y, -1);
    }

    public static void setBubblePosition(Context context, int x, int y) {
        prefs(context).edit().putInt(K_BUBBLE_X, x).putInt(K_BUBBLE_Y, y).apply();
    }

    public static boolean speakerEnabled(Context context) {
        return prefs(context).getBoolean(K_SPEAKER, false);
    }

    public static void setSpeakerEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(K_SPEAKER, enabled).apply();
    }

    /** Panel text size in sp; 12 is the HtmlApps default. */
    public static int fontSize(Context context) {
        return prefs(context).getInt(K_FONT_SIZE, 12);
    }

    public static void setFontSize(Context context, int sp) {
        prefs(context).edit().putInt(K_FONT_SIZE, Math.max(9, Math.min(28, sp))).apply();
    }

    /** 0..100: how transparent the ring becomes while docked at a screen edge. */
    public static int edgeFade(Context context) {
        return prefs(context).getInt(K_EDGE_FADE, 0);
    }

    public static void setEdgeFade(Context context, int percent) {
        prefs(context).edit().putInt(K_EDGE_FADE, Math.max(0, Math.min(100, percent))).apply();
    }

    public static boolean autoOpen(Context context) {
        return prefs(context).getBoolean(K_AUTO_OPEN, false);
    }

    public static void setAutoOpen(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(K_AUTO_OPEN, enabled).apply();
    }

    /** true = answer above the microphone button; false = at the bottom (HtmlApps default). */
    public static boolean replyTop(Context context) {
        return "top".equals(prefs(context).getString(K_REPLY_POSITION, "bottom"));
    }

    public static void setReplyTop(Context context, boolean top) {
        prefs(context).edit().putString(K_REPLY_POSITION, top ? "top" : "bottom").apply();
    }

    public static void reset(Context context) {
        prefs(context).edit()
                .putInt(K_BUBBLE_COLOR, 0xFFFFFF)
                .putInt(K_BUBBLE_ALPHA, 0)
                .putInt(K_PANEL_COLOR, DEFAULT_PANEL_COLOR)
                .putInt(K_PANEL_ALPHA, DEFAULT_PANEL_ALPHA)
                .putInt(K_TEXT_COLOR, 0xE8EDF7)
                .putInt(K_TEXT_ALPHA, 255)
                .putInt(K_PANEL_W, 0)
                .putInt(K_PANEL_H, 0)
                .putInt(K_FONT_SIZE, 12)
                .putInt(K_EDGE_FADE, 0)
                .putBoolean(K_AUTO_OPEN, false)
                .putString(K_REPLY_POSITION, "bottom")
                .apply();
    }

    public static int textArgb(Context context) {
        return (textAlpha(context) << 24) | (textColor(context) & 0xFFFFFF);
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }
}
