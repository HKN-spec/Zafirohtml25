package com.niki914.zafiro.htmlapps.library;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.speech.tts.TextToSpeech;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.util.Locale;

/**
 * Minimal HtmlApps runtime surface: opens a published single-file app in a WebView and exposes
 * the basic bridge calls (toast, speech, navigation). The full 416-action bridge remains in the
 * dedicated HtmlApps app; this viewer is the optional in-Zafiro runner.
 */
public class HtmlAppsViewerActivity extends Activity {

    public static final String EXTRA_FOLDER = "folder";
    private WebView webView;
    private TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String folder = getIntent().getStringExtra(EXTRA_FOLDER);
        if (folder == null || folder.trim().isEmpty()) {
            finish();
            return;
        }
        HtmlAppsContextStore.setFolder(this, folder);
        File root = new File(Environment.getExternalStorageDirectory(), "Download/HtmlApps");
        File index = new File(new File(root, folder), "index.html");
        if (!index.isFile()) {
            Toast.makeText(this, "Uygulama bulunamadı: " + folder, Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        tts = new TextToSpeech(this, status -> {});
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new Bridge(), "HtmlRuntimeBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl(index.toURI().toString());
        setContentView(webView);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView != null && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private class Bridge {
        @JavascriptInterface
        public void postMessage(String raw) {
            final String reply;
            Object id = null;
            try {
                JSONObject request = new JSONObject(raw == null ? "{}" : raw);
                id = request.opt("id");
                String action = request.optString("action", "").toUpperCase(Locale.US);
                switch (action) {
                    case "TOAST": {
                        String text = request.optString("text", "");
                        runOnUiThread(() -> Toast.makeText(HtmlAppsViewerActivity.this, text,
                                Toast.LENGTH_SHORT).show());
                        reply = replyJson(id, true, null, null);
                        break;
                    }
                    case "TEXT_TO_SPEECH": {
                        String text = request.optString("text", "");
                        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "htmlapps");
                        reply = replyJson(id, true, null, null);
                        break;
                    }
                    case "CLOSE_APP": {
                        runOnUiThread(HtmlAppsViewerActivity.this::finish);
                        reply = replyJson(id, true, null, null);
                        break;
                    }
                    default:
                        reply = replyJson(id, false, "action_not_in_viewer:" + action, null);
                        break;
                }
            } catch (Exception e) {
                // no reply needed
                return;
            }
            final String js = "window.__bridgeReply && window.__bridgeReply("
                    + JSONObject.quote(reply) + ")";
            runOnUiThread(() -> webView.evaluateJavascript(js, null));
        }

        private String replyJson(Object id, boolean ok, String error, String dataJson) {
            try {
                JSONObject reply = new JSONObject();
                if (id != null) reply.put("id", id);
                reply.put("ok", ok);
                if (error != null) reply.put("error", error);
                else reply.put("data", dataJson == null ? new JSONObject() : new JSONObject(dataJson));
                return reply.toString();
            } catch (Exception e) {
                return ok ? "{\"ok\":true}" : "{\"ok\":false,\"error\":\"bridge_failed\"}";
            }
        }
    }
}
