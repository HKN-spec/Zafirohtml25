package com.niki914.zafiro.htmlapps.library;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Usage and storage statistics for the HtmlApps library. */
public class HtmlAppsStatsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        List<HtmlAppsRepo.App> apps = HtmlAppsRepo.list(HtmlAppsRepo.root());
        long total = 0;
        int favorites = 0;
        int opened = 0;
        for (HtmlAppsRepo.App app : apps) {
            total += app.meta.sizeBytes;
            if (app.meta.favorite) favorites++;
            opened += app.meta.openCount;
        }

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFF0B0F16);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        body.setPadding(pad, pad, pad, pad);
        scroll.addView(body);

        TextView title = new TextView(this);
        title.setText("Kullanım istatistikleri");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        body.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText(HtmlAppsRepo.root().getAbsolutePath());
        subtitle.setTextColor(0xFF8FA3BF);
        subtitle.setTextSize(11);
        subtitle.setPadding(0, dp(2), 0, dp(12));
        body.addView(subtitle);

        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.HORIZONTAL);
        cards.addView(stat("Uygulama", String.valueOf(apps.size())),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        cards.addView(stat("Toplam boyut", HtmlAppsRepo.size(total)),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        cards.addView(stat("Favori", String.valueOf(favorites)),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        body.addView(cards);

        LinearLayout second = new LinearLayout(this);
        second.setOrientation(LinearLayout.HORIZONTAL);
        second.setPadding(0, dp(8), 0, dp(16));
        second.addView(stat("Açılma", String.valueOf(opened)),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        second.addView(stat("Ort. boyut", HtmlAppsRepo.size(apps.isEmpty() ? 0 : total / apps.size())),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        body.addView(second);

        body.addView(heading("En çok açılan"));
        List<HtmlAppsRepo.App> byUse = new ArrayList<>(apps);
        Collections.sort(byUse, (a, b) -> Integer.compare(b.meta.openCount, a.meta.openCount));
        int shown = 0;
        for (HtmlAppsRepo.App app : byUse) {
            if (shown >= 6) break;
            body.addView(row(app.name, app.meta.openCount + " açılma · "
                    + lastUsed(app.meta.lastUsedAt)));
            shown++;
        }
        if (shown == 0) body.addView(empty());

        body.addView(heading("En büyük"));
        List<HtmlAppsRepo.App> bySize = new ArrayList<>(apps);
        Collections.sort(bySize, (a, b) -> Long.compare(b.meta.sizeBytes, a.meta.sizeBytes));
        shown = 0;
        for (HtmlAppsRepo.App app : bySize) {
            if (shown >= 6) break;
            body.addView(row(app.name, HtmlAppsRepo.size(app.meta.sizeBytes)));
            shown++;
        }
        if (shown == 0) body.addView(empty());

        body.addView(heading("Son kullanılan"));
        List<HtmlAppsRepo.App> byRecent = new ArrayList<>(apps);
        Collections.sort(byRecent, (a, b) -> Long.compare(b.meta.lastUsedAt, a.meta.lastUsedAt));
        shown = 0;
        for (HtmlAppsRepo.App app : byRecent) {
            if (shown >= 6) break;
            if (app.meta.lastUsedAt == 0) continue;
            body.addView(row(app.name, lastUsed(app.meta.lastUsedAt)));
            shown++;
        }
        if (shown == 0) body.addView(empty());

        setContentView(scroll);
    }

    private LinearLayout stat(String label, String value) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable background = new GradientDrawable();
        background.setColor(0xFF151C27);
        background.setCornerRadius(dp(14));
        card.setBackground(background);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(dp(3), dp(3), dp(3), dp(3));
        card.setLayoutParams(params);

        TextView valueView = new TextView(this);
        valueView.setText(value);
        valueView.setTextColor(Color.WHITE);
        valueView.setTextSize(18);
        valueView.setTypeface(null, Typeface.BOLD);
        card.addView(valueView);

        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextColor(0xFF8FA3BF);
        labelView.setTextSize(10);
        card.addView(labelView);
        return card;
    }

    private TextView heading(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(0xFFDCE7FF);
        view.setTextSize(14);
        view.setTypeface(null, Typeface.BOLD);
        view.setPadding(0, dp(10), 0, dp(6));
        return view;
    }

    private TextView row(String title, String meta) {
        TextView view = new TextView(this);
        view.setText(title + "\n" + meta);
        view.setTextColor(Color.WHITE);
        view.setTextSize(13);
        view.setLineSpacing(dp(2), 1f);
        view.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable background = new GradientDrawable();
        background.setColor(0xFF111926);
        background.setCornerRadius(dp(12));
        view.setBackground(background);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = dp(5);
        view.setLayoutParams(params);
        return view;
    }

    private TextView empty() {
        TextView view = new TextView(this);
        view.setText("Henüz veri yok.");
        view.setTextColor(0xFF8FA3BF);
        view.setTextSize(12);
        return view;
    }

    private String lastUsed(long when) {
        if (when <= 0) return "hiç açılmadı";
        return new SimpleDateFormat("d MMM HH:mm", Locale.getDefault()).format(new Date(when));
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}
