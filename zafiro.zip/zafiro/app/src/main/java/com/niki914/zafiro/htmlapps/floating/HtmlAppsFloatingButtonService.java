package com.niki914.zafiro.htmlapps.floating;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.AlertDialog;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.niki914.zafiro.api.model.ApprovalRequest;
import com.niki914.zafiro.app.MainActivity;
import com.niki914.zafiro.htmlapps.NovaAgentBridge;
import com.niki914.zafiro.htmlapps.NovaPanelApprover;
import com.niki914.zafiro.htmlapps.library.HtmlAppsLibraryActivity;

import java.util.Locale;

/**
 * HtmlApps'in yüzen halkası + paneli.
 *
 * Görünüm, yerleşim ve ayarlar HtmlApps'teki FloatingButtonService/FloatStyle ile birebir
 * eşleşir: boş beyaz halka (56 dp), halkaya altından bağlanan 300x400 panel, kalıcı mikrofon
 * düğmesi, hoparlör, tek satır istem, Gönder, onay, kamera/galeri/dosya, kopyalanabilir yanıt,
 * sağ alttan boyutlandırma ve panel içi ayarlar.
 *
 * Ajan tarafı Zafiro'ya bağlıdır: istekler AgentManager.main üzerinden yürür, yanıt panelde
 * canlı gösterilir; Zafiro'nun ana ekranı açılmaz.
 */
public class HtmlAppsFloatingButtonService extends Service {

    private static final String PREFS = "htmlapps_float";
    private static final String CHANNEL = "htmlapps_float";
    private static final int NOTIFICATION_ID = 4210;
    private static final int BUTTON_DP = 56;
    private static final int[] STYLE_COLORS = {
            0xFF111111, 0xFFFFFFFF, 0xFF3D6BFF, 0xFF32D74B, 0xFFFF9F0A, 0xFFBF5AF2
    };
    private static final int[] STYLE_TEXT_COLORS = {
            0xFFFFFFFF, 0xFF000000, 0xFFE8EDF7, 0xFF3D6BFF, 0xFFFFD166
    };

    private static volatile HtmlAppsFloatingButtonService instance;
    private static volatile boolean pendingOpenPanel;

    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager windowManager;
    private FrameLayout buttonView;
    private LinearLayout panelView;
    private WindowManager.LayoutParams buttonParams;
    private WindowManager.LayoutParams panelParams;
    private TextView micButton;
    private TextView speakerButton;
    private TextView stopButton;
    private TextView newChatButton;
    private TextView attachChip;
    private TextView replyView;
    private TextView confirmButton;
    private TextView denyButton;
    private LinearLayout confirmRow;
    private FrameLayout previewHost;
    private EditText inputView;
    private ScrollView panelScroll;
    private boolean panelOpen;
    private boolean previewOn;
    private boolean micOn;
    private boolean voiceLoop;
    private boolean awaitingVoice;
    private boolean speaking;
    private int screenWidth;
    private int screenHeight;
    private int buttonSize;
    private int panelWidth;
    private int panelHeight;
    private float downRawX;
    private float downRawY;
    private int downX;
    private int downY;
    private boolean moved;
    private boolean longPressFired;
    private String pendingImageUri;
    private String pendingFileUri;
    private String pendingText = "";
    private boolean sendAfterCapture;
    private HtmlAppsLiveCamera liveCamera;
    private HtmlAppsSpeech speech;
    private TextToSpeech tts;
    private boolean ttsReady;
    private boolean agentPolling;
    private boolean lastAgentRunning;
    private BroadcastReceiver screenReceiver;
    private String lastReply = "";
    private String lastSpoken = "";

    private final Runnable longPressRunnable = new Runnable() {
        @Override public void run() {
            longPressFired = true;
            showStyleMenu();
        }
    };

    // ---------------------------------------------------------------- lifecycle

    public static boolean isEnabled(Context context) {
        return prefs(context).getBoolean("enabled", false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean("enabled", enabled).apply();
        if (enabled) start(context);
        else context.stopService(new Intent(context, HtmlAppsFloatingButtonService.class));
    }

    public static void start(Context context) {
        Intent intent = new Intent(context, HtmlAppsFloatingButtonService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent);
            else context.startService(intent);
        } catch (Exception e) {
            try {
                context.startService(intent);
            } catch (Exception ignored) {
            }
        }
    }

    public static void showPanel(Context context) {
        pendingOpenPanel = true;
        start(context);
        HtmlAppsFloatingButtonService local = instance;
        if (local != null) {
            local.main.post(() -> {
                pendingOpenPanel = false;
                if (!local.panelOpen) local.openPanel();
            });
        }
    }

    public static void hidePanel(Context context) {
        HtmlAppsFloatingButtonService local = instance;
        if (local != null) local.main.post(local::closePanel);
    }

    public static void rebuildPanel(Context context) {
        HtmlAppsFloatingButtonService local = instance;
        if (local != null) {
            local.main.post(() -> {
                if (local.panelOpen) {
                    local.closePanel();
                    local.main.postDelayed(local::openPanel, 180);
                }
            });
        }
    }

    public static void refreshStyle(Context context) {
        HtmlAppsFloatingButtonService local = instance;
        if (local != null) local.main.post(local::applyFloatStyle);
    }

    public static void notifyPermission(String mode, boolean granted) {
        HtmlAppsFloatingButtonService local = instance;
        if (local == null) return;
        local.main.post(() -> local.onPermissionResult(mode, granted));
    }

    public static void attachToPanel(String uri, boolean image) {
        HtmlAppsFloatingButtonService local = instance;
        if (local == null) return;
        local.main.post(() -> local.onExternalAttachment(uri, image));
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        goForeground();
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Yüzen buton için ekran üstünde gösterme izni gerekli",
                    Toast.LENGTH_LONG).show();
            stopSelf();
            return;
        }
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        screenWidth = getResources().getDisplayMetrics().widthPixels;
        screenHeight = getResources().getDisplayMetrics().heightPixels;
        buttonSize = dp(BUTTON_DP);
        speech = new HtmlAppsSpeech(this, speechListener);
        initTts();
        createButton();
        startAgentPolling();
        NovaPanelApprover.attach(NovaAgentBridge.control(), approvalListener);
        registerScreenReceiver();
        if (pendingOpenPanel) {
            pendingOpenPanel = false;
            main.postDelayed(this::openPanel, 380);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (windowManager != null && buttonView == null && Settings.canDrawOverlays(this)) {
            createButton();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        instance = null;
        unregisterScreenReceiver();
        stopAgentPolling();
        NovaPanelApprover.detach();
        closePanel();
        if (liveCamera != null) {
            liveCamera.stop();
            liveCamera = null;
        }
        if (speech != null) {
            speech.destroy();
            speech = null;
        }
        if (tts != null) {
            try {
                tts.stop();
                tts.shutdown();
            } catch (Exception ignored) {
            }
            tts = null;
        }
        try {
            stopForeground(true);
        } catch (Exception ignored) {
        }
        try {
            if (buttonView != null && windowManager != null) windowManager.removeView(buttonView);
        } catch (Exception ignored) {
        }
        buttonView = null;
        super.onDestroy();
    }

    private void registerScreenReceiver() {
        if (screenReceiver != null) return;
        screenReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                ensureOverlayAlive();
            }
        };
        try {
            IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_USER_PRESENT);
            registerReceiver(screenReceiver, filter);
        } catch (Exception ignored) {
        }
    }

    private void unregisterScreenReceiver() {
        if (screenReceiver == null) return;
        try {
            unregisterReceiver(screenReceiver);
        } catch (Exception ignored) {
        }
        screenReceiver = null;
    }

    /** The system can drop overlay windows while locked; bring them back on unlock. */
    private void ensureOverlayAlive() {
        if (!isEnabled(this) || !Settings.canDrawOverlays(this)) return;
        try {
            if (buttonView == null || !buttonView.isShown()) {
                if (buttonView != null && windowManager != null) {
                    windowManager.removeView(buttonView);
                }
                buttonView = null;
                createButton();
            }
            if (panelOpen && (panelView == null || !panelView.isShown())) {
                closePanel();
                openPanel();
            }
        } catch (Exception ignored) {
        }
    }

    private void goForeground() {
        try {
            NotificationManager manager =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager == null) return;
            if (Build.VERSION.SDK_INT >= 26
                    && manager.getNotificationChannel(CHANNEL) == null) {
                manager.createNotificationChannel(new NotificationChannel(CHANNEL,
                        "HtmlApps yüzen buton", NotificationManager.IMPORTANCE_LOW));
            }
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
            PendingIntent content = PendingIntent.getActivity(this, 0,
                    new Intent(this, MainActivity.class)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                    | Intent.FLAG_ACTIVITY_CLEAR_TOP), flags);
            Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, CHANNEL)
                    : new Notification.Builder(this);
            builder.setSmallIcon(android.R.drawable.ic_menu_view)
                    .setContentTitle("HtmlApps yüzen buton")
                    .setContentText("Nova paneli")
                    .setContentIntent(content)
                    .setOngoing(true);
            startForeground(NOTIFICATION_ID, builder.build());
        } catch (Exception ignored) {
        }
    }

    // ---------------------------------------------------------------- button

    private void createButton() {
        if (windowManager == null) return;
        buttonView = new FrameLayout(this);
        applyFloatStyle();
        buttonView.setElevation(dp(6));

        int savedX = HtmlAppsFloatStyle.bubbleX(this);
        int savedY = HtmlAppsFloatStyle.bubbleY(this);
        int initialX = savedX >= 0 ? savedX : screenWidth - buttonSize - dp(6);
        int initialY = savedY >= 0 ? savedY : (int) (screenHeight * 0.55f);

        buttonParams = new WindowManager.LayoutParams(
                buttonSize, buttonSize,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        buttonParams.gravity = Gravity.TOP | Gravity.START;
        buttonParams.x = clampX(initialX);
        buttonParams.y = clampY(initialY);

        buttonView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        downX = buttonParams.x;
                        downY = buttonParams.y;
                        moved = false;
                        longPressFired = false;
                        main.postDelayed(longPressRunnable, 600);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - downRawX);
                        int dy = (int) (event.getRawY() - downRawY);
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) {
                            moved = true;
                            main.removeCallbacks(longPressRunnable);
                        }
                        if (moved) {
                            buttonParams.x = clampX(downX + dx);
                            buttonParams.y = clampY(downY + dy);
                            try {
                                windowManager.updateViewLayout(buttonView, buttonParams);
                            } catch (Exception ignored) {
                            }
                            if (panelOpen) positionPanel();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        main.removeCallbacks(longPressRunnable);
                        if (moved) {
                            HtmlAppsFloatStyle.setBubblePosition(thisService(), buttonParams.x,
                                    buttonParams.y);
                            applyFloatStyle();
                        } else if (!longPressFired) {
                            if (panelOpen) closePanel();
                            else openPanel();
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });

        try {
            windowManager.addView(buttonView, buttonParams);
            applyFloatStyle();
        } catch (Exception e) {
            stopSelf();
        }
    }

    private HtmlAppsFloatingButtonService thisService() {
        return this;
    }

    private GradientDrawable bubbleDrawable() {
        int color = HtmlAppsFloatStyle.bubbleColor(this);
        int alpha = HtmlAppsFloatStyle.bubbleAlpha(this);
        int fade = 0;
        if (buttonParams != null) {
            int margin = dp(18);
            boolean nearEdge = buttonParams.x <= margin
                    || buttonParams.x + buttonSize >= screenWidth - margin
                    || buttonParams.y <= margin
                    || buttonParams.y + buttonSize >= screenHeight - margin;
            if (nearEdge) fade = HtmlAppsFloatStyle.edgeFade(this);
        }
        int fillAlpha = alpha * (100 - fade) / 100;
        int strokeAlpha = 255 * (100 - fade) / 100;
        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setColor(Color.argb(fillAlpha, Color.red(color), Color.green(color), Color.blue(color)));
        ring.setStroke(dp(2.5f), Color.argb(strokeAlpha, 255, 255, 255));
        return ring;
    }

    private GradientDrawable panelDrawable() {
        int color = HtmlAppsFloatStyle.panelColor(this);
        int alpha = HtmlAppsFloatStyle.panelAlpha(this);
        GradientDrawable background = new GradientDrawable();
        background.setCornerRadius(dp(18));
        background.setColor(Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color)));
        background.setStroke(dp(1), 0xFF3949AB);
        return background;
    }

    private void applyFloatStyle() {
        try {
            if (buttonView != null) buttonView.setBackground(bubbleDrawable());
            if (panelView != null) panelView.setBackground(panelDrawable());
            int color = HtmlAppsFloatStyle.textArgb(this);
            int font = HtmlAppsFloatStyle.fontSize(this);
            if (replyView != null) {
                replyView.setTextColor(color);
                replyView.setTextSize(font);
            }
            if (inputView != null) {
                inputView.setTextColor(color);
                inputView.setTextSize(font);
            }
        } catch (Exception ignored) {
        }
    }

    /** Re-adds the ring after the panel so the button always stays above the panel. */
    private void raiseButton() {
        try {
            if (buttonView == null || buttonParams == null || windowManager == null) return;
            if (buttonView.getParent() != null) windowManager.removeView(buttonView);
            windowManager.addView(buttonView, buttonParams);
        } catch (Exception ignored) {
        }
    }

    // ---------------------------------------------------------------- panel

    private void openPanel() {
        if (panelOpen) return;
        panelOpen = true;

        int pad = dp(12);
        int savedWidth = HtmlAppsFloatStyle.panelWidth(this);
        int savedHeight = HtmlAppsFloatStyle.panelHeight(this);
        int maxWidth = screenWidth - dp(16);
        int maxHeight = screenHeight - dp(80);
        panelWidth = savedWidth > 0 ? Math.min(savedWidth, maxWidth) : dp(300);
        panelHeight = savedHeight > 0 ? Math.min(savedHeight, maxHeight) : dp(400);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(pad, pad, pad, dp(8));
        panel.setBackground(panelDrawable());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        panelScroll = scroll;
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        previewHost = new FrameLayout(this);
        previewHost.setBackgroundColor(0xFF101218);
        previewHost.setVisibility(View.GONE);
        content.addView(previewHost, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(200)));

        micButton = new TextView(this);
        micButton.setText("🔴 Mikrofon kapalı");
        micButton.setTextColor(Color.WHITE);
        micButton.setTextSize(14);
        micButton.setGravity(Gravity.CENTER);
        micButton.setBackground(rounded(0xFFC62828, 0, 12));
        micButton.setPadding(pad, dp(8), pad, dp(8));
        micButton.setOnClickListener(v -> toggleMic());
        LinearLayout.LayoutParams micParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
        micParams.topMargin = dp(8);
        content.addView(micButton, micParams);

        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setOrientation(LinearLayout.HORIZONTAL);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        statusRow.setPadding(0, dp(6), 0, 0);

        stopButton = new TextView(this);
        stopButton.setText("⏹ Durdur");
        stopButton.setTextColor(Color.WHITE);
        stopButton.setTextSize(11);
        stopButton.setGravity(Gravity.CENTER);
        stopButton.setPadding(dp(9), dp(8), dp(9), dp(8));
        stopButton.setBackground(rounded(0xFFC62828, 0, 10));
        statusRow.addView(stopButton);
        stopButton.setOnClickListener(v -> {
            NovaAgentBridge.stop();
            awaitingVoice = false;
            setReply("Durduruluyor…");
        });

        speakerButton = new TextView(this);
        speakerButton.setTextSize(12f);
        speakerButton.setGravity(Gravity.CENTER);
        speakerButton.setPadding(dp(4), dp(7), dp(4), dp(7));
        speakerButton.setOnClickListener(v -> {
            boolean next = !HtmlAppsFloatStyle.speakerEnabled(this);
            HtmlAppsFloatStyle.setSpeakerEnabled(this, next);
            updateSpeakerButton();
            if (next) {
                String answer = NovaAgentBridge.replyText();
                if (!answer.isEmpty()) speak(answer);
            } else if (tts != null) {
                try {
                    tts.stop();
                } catch (Exception ignored) {
                }
                speaking = false;
                if (voiceLoop && panelOpen) restartVoice(400);
            }
        });
        LinearLayout.LayoutParams speakerParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        speakerParams.leftMargin = dp(6);
        speakerParams.rightMargin = dp(6);
        statusRow.addView(speakerButton, speakerParams);

        newChatButton = new TextView(this);
        newChatButton.setText("＋ Yeni");
        newChatButton.setTextColor(Color.WHITE);
        newChatButton.setTextSize(11);
        newChatButton.setGravity(Gravity.CENTER);
        newChatButton.setPadding(dp(9), dp(8), dp(9), dp(8));
        newChatButton.setBackground(rounded(0xFF2E7D32, 0, 10));
        statusRow.addView(newChatButton);
        newChatButton.setOnClickListener(v -> newConversation());

        content.addView(statusRow);
        updateSpeakerButton();

        inputView = new EditText(this);
        inputView.setHint("Yaz…");
        inputView.setTextColor(HtmlAppsFloatStyle.textArgb(this));
        inputView.setHintTextColor(0xFF8A93A8);
        inputView.setSingleLine(true);
        inputView.setBackground(rounded(0xFF2A2F3D, 0, 12));
        inputView.setPadding(pad, dp(4), pad, dp(4));
        inputView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                setPanelFocusable(true);
                inputView.requestFocus();
                inputView.postDelayed(() -> {
                    InputMethodManager imm =
                            (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(inputView, InputMethodManager.SHOW_IMPLICIT);
                }, 80);
            }
            return false;
        });
        inputView.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                try {
                    InputMethodManager imm =
                            (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) imm.hideSoftInputFromWindow(inputView.getWindowToken(), 0);
                } catch (Exception ignored) {
                }
                setPanelFocusable(false);
            }
        });
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        inputParams.topMargin = dp(8);
        content.addView(inputView, inputParams);

        TextView send = new TextView(this);
        send.setText("Gönder");
        send.setTextColor(Color.WHITE);
        send.setTextSize(14);
        send.setGravity(Gravity.CENTER);
        send.setBackground(rounded(0xFF3949AB, 0, 12));
        send.setOnClickListener(v -> sendMessage());
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        sendParams.topMargin = dp(8);
        content.addView(send, sendParams);

        confirmRow = new LinearLayout(this);
        confirmRow.setOrientation(LinearLayout.HORIZONTAL);
        confirmRow.setVisibility(View.GONE);
        LinearLayout.LayoutParams confirmParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        confirmParams.topMargin = dp(8);
        content.addView(confirmRow, confirmParams);

        confirmButton = new TextView(this);
        confirmButton.setText("✔ Onayla ve uygula");
        confirmButton.setTextColor(Color.WHITE);
        confirmButton.setTextSize(12);
        confirmButton.setGravity(Gravity.CENTER);
        confirmButton.setBackground(rounded(0xFF2E7D32, 0, 10));
        confirmButton.setPadding(dp(8), dp(9), dp(8), dp(9));
        LinearLayout.LayoutParams confirmButtonParams = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        confirmButtonParams.rightMargin = dp(6);
        confirmRow.addView(confirmButton, confirmButtonParams);
        confirmButton.setOnClickListener(v -> NovaPanelApprover.approve());

        denyButton = new TextView(this);
        denyButton.setText("✖");
        denyButton.setTextColor(Color.WHITE);
        denyButton.setTextSize(13);
        denyButton.setGravity(Gravity.CENTER);
        denyButton.setBackground(rounded(0xFFC62828, 0, 10));
        denyButton.setPadding(dp(12), dp(9), dp(12), dp(9));
        confirmRow.addView(denyButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        denyButton.setOnClickListener(v -> NovaPanelApprover.deny());

        try {
            if (!isAccessibilityEnabled()) {
                TextView warning = new TextView(this);
                warning.setText("⚠ Erişilebilirlik kapalı: ekran kontrolü ve diğer uygulamalar "
                        + "çalışmaz. Dokun → Ayarlar");
                warning.setTextColor(0xFFFFB74D);
                warning.setTextSize(11);
                warning.setPadding(0, dp(8), 0, 0);
                warning.setOnClickListener(v -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception ignored) {
                    }
                });
                content.addView(warning);
            }
        } catch (Exception ignored) {
        }

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.setPadding(0, dp(8), 0, 0);
        tools.addView(toolButton("📷 Canlı", v -> togglePreview()), weight());
        tools.addView(toolButton("🖼 Galeri", v -> pickAttachment(HtmlAppsAttachActivity.MODE_IMAGE)),
                weight());
        tools.addView(toolButton("📎 Dosya", v -> pickAttachment(HtmlAppsAttachActivity.MODE_FILE)),
                weight());
        content.addView(tools);

        attachChip = new TextView(this);
        attachChip.setTextColor(0xFF9FB4D8);
        attachChip.setTextSize(11);
        attachChip.setPadding(0, dp(6), 0, 0);
        attachChip.setVisibility(View.GONE);
        content.addView(attachChip);

        replyView = new TextView(this);
        replyView.setText("");
        replyView.setTextColor(HtmlAppsFloatStyle.textArgb(this));
        replyView.setTextSize(12);
        replyView.setPadding(0, dp(8), 0, 0);
        replyView.setTextIsSelectable(true);
        replyView.setOnClickListener(v -> copyReply());
        replyView.setOnLongClickListener(v -> {
            copyReply();
            return true;
        });

        if (HtmlAppsFloatStyle.replyTop(this)) {
            // Above the microphone button, right under the camera preview.
            content.addView(replyView, 1);
        } else {
            content.addView(replyView);
        }

        scroll.setVerticalScrollBarEnabled(true);
        scroll.setScrollbarFadingEnabled(false);
        scroll.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        scroll.addView(content);
        panel.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setPadding(0, dp(6), 0, 0);
        TextView close = new TextView(this);
        close.setText("Kapat");
        close.setTextColor(0xFF8A93A8);
        close.setTextSize(12);
        close.setGravity(Gravity.CENTER_VERTICAL);
        close.setOnClickListener(v -> closePanel());
        footer.addView(close, weight());
        TextView resize = new TextView(this);
        resize.setText("◢");
        resize.setTextColor(0xFFB8C2D6);
        resize.setTextSize(18);
        resize.setGravity(Gravity.CENTER);
        footer.addView(resize, new LinearLayout.LayoutParams(dp(44), dp(34)));
        panel.addView(footer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        resize.setOnTouchListener(new View.OnTouchListener() {
            float downX;
            float downY;
            int startW;
            int startH;

            @Override public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    downX = event.getRawX();
                    downY = event.getRawY();
                    startW = panelWidth;
                    startH = panelHeight;
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    panelWidth = Math.max(dp(200), Math.min(screenWidth - dp(16),
                            startW + (int) (event.getRawX() - downX)));
                    panelHeight = Math.max(dp(180), Math.min(screenHeight - dp(80),
                            startH + (int) (event.getRawY() - downY)));
                    panelParams.width = panelWidth;
                    panelParams.height = panelHeight;
                    try {
                        windowManager.updateViewLayout(panelView, panelParams);
                    } catch (Exception ignored) {
                    }
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    HtmlAppsFloatStyle.setPanelSize(thisService(), panelWidth, panelHeight);
                    return true;
                }
                return false;
            }
        });

        panelParams = new WindowManager.LayoutParams(
                panelWidth, panelHeight,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;

        panelView = panel;
        try {
            windowManager.addView(panelView, panelParams);
            positionPanel();
            raiseButton();
            applyFloatStyle();
        } catch (Exception e) {
            panelOpen = false;
            panelView = null;
        }
    }

    /** Toggles focus so the overlay never steals the keyboard from other apps. */
    private void setPanelFocusable(boolean focusable) {
        if (panelParams == null) return;
        int base = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
        panelParams.flags = focusable ? base
                : base | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        try {
            windowManager.updateViewLayout(panelView, panelParams);
        } catch (Exception ignored) {
        }
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private TextView toolButton(String label, View.OnClickListener listener) {
        TextView view = new TextView(this);
        view.setText(label);
        view.setTextColor(Color.WHITE);
        view.setTextSize(12);
        view.setGravity(Gravity.CENTER);
        view.setPadding(0, dp(8), 0, dp(8));
        view.setBackground(rounded(0xFF2A2F3D, 0xFF3949AB, 10));
        view.setOnClickListener(listener);
        LinearLayout.LayoutParams params = weight();
        params.setMargins(dp(3), 0, dp(3), 0);
        view.setLayoutParams(params);
        return view;
    }

    /** Keeps the panel glued to the ring, clamped on screen. */
    private void positionPanel() {
        if (!panelOpen || panelParams == null || panelView == null) return;
        int x = buttonParams.x + buttonSize / 2 - panelWidth / 2;
        x = Math.max(dp(8), Math.min(screenWidth - panelWidth - dp(8), x));
        int y = buttonParams.y + buttonSize + dp(10);
        int maxY = screenHeight - dp(80);
        if (y > maxY) y = Math.max(dp(8), buttonParams.y - panelHeight - dp(10));
        panelParams.x = x;
        panelParams.y = y;
        try {
            windowManager.updateViewLayout(panelView, panelParams);
        } catch (Exception ignored) {
        }
    }

    private void closePanel() {
        if (!panelOpen) return;
        panelOpen = false;
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null && inputView != null) {
                imm.hideSoftInputFromWindow(inputView.getWindowToken(), 0);
            }
        } catch (Exception ignored) {
        }
        if (previewOn) stopPreview();
        voiceLoop = false;
        awaitingVoice = false;
        micOn = false;
        if (speech != null) speech.stop();
        if (tts != null) {
            try {
                tts.stop();
            } catch (Exception ignored) {
            }
        }
        if (liveCamera != null) {
            liveCamera.stop();
            liveCamera = null;
        }
        if (tts != null) {
            try {
                tts.stop();
            } catch (Exception ignored) {
            }
        }
        try {
            if (panelView != null) windowManager.removeView(panelView);
        } catch (Exception ignored) {
        }
        panelView = null;
        panelParams = null;
        panelScroll = null;
        replyView = null;
        inputView = null;
        micButton = null;
        previewHost = null;
        attachChip = null;
        confirmButton = null;
        denyButton = null;
        confirmRow = null;
        speakerButton = null;
        pendingImageUri = null;
        pendingFileUri = null;
        pendingText = "";
        sendAfterCapture = false;
        lastReply = "";
    }

    // ---------------------------------------------------------------- actions

    private void updateSpeakerButton() {
        if (speakerButton == null) return;
        boolean enabled = HtmlAppsFloatStyle.speakerEnabled(this);
        speakerButton.setText(enabled ? "🔊 Ses açık" : "🔇 Ses kapalı");
        speakerButton.setTextColor(enabled ? 0xFF66D17A : 0xFFFF8A80);
        speakerButton.setGravity(Gravity.CENTER);
    }

    private void toggleMic() {
        if (speech == null) return;
        if (voiceLoop) {
            voiceLoop = false;
            awaitingVoice = false;
            micOn = false;
            speech.stop();
            if (tts != null) {
                try {
                    tts.stop();
                } catch (Exception ignored) {
                }
            }
            updateMicButton(false);
            return;
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            startActivity(new Intent(this, HtmlAppsPermissionActivity.class)
                    .putExtra(HtmlAppsPermissionActivity.EXTRA_MODE,
                            HtmlAppsPermissionActivity.MODE_MIC)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            return;
        }
        voiceLoop = true;
        startSpeech();
    }

    private void startSpeech() {
        if (!panelOpen || speech == null) return;
        micOn = true;
        speech.start();
    }

    private void updateMicButton(boolean listening) {
        if (micButton == null) return;
        micButton.setText(voiceLoop ? "🟢 Mikrofon açık" : "🔴 Mikrofon kapalı");
        micButton.setBackground(rounded(voiceLoop ? 0xFF2E7D32 : 0xFFC62828, 0, 12));
    }

    private void togglePreview() {
        if (previewOn) {
            stopPreview();
            return;
        }
        if (checkSelfPermission(android.Manifest.permission.CAMERA)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            startActivity(new Intent(this, HtmlAppsPermissionActivity.class)
                    .putExtra(HtmlAppsPermissionActivity.EXTRA_MODE,
                            HtmlAppsPermissionActivity.MODE_CAMERA)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            return;
        }
        startPreview();
    }

    private void startPreview() {
        if (previewHost == null) return;
        if (liveCamera == null) {
            liveCamera = new HtmlAppsLiveCamera(this, previewHost, new HtmlAppsLiveCamera.Listener() {
                @Override
                public void onCaptured(String uri) {
                    pendingImageUri = uri;
                    pendingFileUri = null;
                    updateAttachmentChip();
                    if (sendAfterCapture) {
                        sendAfterCapture = false;
                        sendWith(pendingText, uri, null);
                    } else {
                        setReply("📷 Fotoğraf eklendi. Sorunu yazıp Gönder'e bas.");
                    }
                }

                @Override
                public void onError(String message) {
                    if (sendAfterCapture) {
                        sendAfterCapture = false;
                        sendWith(pendingText, null, null);
                    }
                    setReply("Kamera: " + message);
                }
            });
        }
        liveCamera.start();
        previewOn = true;
        if (previewHost != null) previewHost.setVisibility(View.VISIBLE);
        if (panelScroll != null) {
            panelScroll.post(() -> panelScroll.scrollTo(0, 0));
        }
    }

    private void stopPreview() {
        previewOn = false;
        if (liveCamera != null) {
            liveCamera.stop();
            liveCamera = null;
        }
        if (previewHost != null) previewHost.setVisibility(View.GONE);
    }

    private void pickAttachment(String mode) {
        if (inputView == null) return;
        String text = inputView.getText().toString().trim();
        startActivity(new Intent(this, HtmlAppsAttachActivity.class)
                .putExtra(HtmlAppsAttachActivity.EXTRA_MODE, mode)
                .putExtra(HtmlAppsAttachActivity.EXTRA_TEXT, text)
                .putExtra(HtmlAppsAttachActivity.EXTRA_TARGET,
                        HtmlAppsAttachActivity.TARGET_PANEL)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }

    private void updateAttachmentChip() {
        if (attachChip == null) return;
        if (pendingFileUri != null) {
            attachChip.setText("📎 Dosya gönderime eklenecek");
            attachChip.setVisibility(View.VISIBLE);
        } else if (pendingImageUri != null) {
            attachChip.setText("📷 Fotoğraf gönderime eklenecek");
            attachChip.setVisibility(View.VISIBLE);
        } else {
            attachChip.setVisibility(View.GONE);
        }
    }

    private void onExternalAttachment(String uri, boolean image) {
        if (image) {
            pendingImageUri = uri;
            pendingFileUri = null;
        } else {
            pendingFileUri = uri;
            pendingImageUri = null;
        }
        updateAttachmentChip();
        if (!panelOpen) openPanel();
        setReply(image
                ? "Görsel eklendi. Nova'ya ne yapmasını istediğini yaz."
                : "Dosya eklendi. Nova'ya ne yapmasını istediğini yaz.");
    }

    private void onPermissionResult(String mode, boolean granted) {
        if (HtmlAppsPermissionActivity.MODE_CAMERA.equals(mode)) {
            if (granted) startPreview();
            else setReply("Kamera izni verilmedi.");
        } else if (HtmlAppsPermissionActivity.MODE_MIC.equals(mode)) {
            if (granted) startSpeech();
            else setReply("Mikrofon izni verilmedi.");
        }
    }

    private final HtmlAppsSpeech.Listener speechListener = new HtmlAppsSpeech.Listener() {
        @Override
        public void onText(String text, boolean finalResult) {
            if (inputView == null) return;
            inputView.setText(text);
            inputView.setSelection(inputView.getText().length());
            if (finalResult) {
                if (voiceLoop && !text.trim().isEmpty()) {
                    awaitingVoice = true;
                    sendWith(text, pendingImageUri, pendingFileUri);
                } else {
                    setReply("Ses yazıya çevrildi. Gönder'e basabilirsin.");
                }
            }
        }

        @Override
        public void onState(boolean listening) {
            micOn = listening;
            updateMicButton(listening);
        }

        @Override
        public void onError(String message) {
            micOn = false;
            setReply(message);
            if (voiceLoop) restartVoice(1200);
        }
    };

    // ---------------------------------------------------------------- send / reply

    private void sendMessage() {
        if (inputView == null) return;
        String text = inputView.getText().toString().trim();
        if (text.isEmpty() && pendingImageUri == null && pendingFileUri == null) {
            Toast.makeText(this, "Bir şey yaz veya fotoğraf/dosya ekle", Toast.LENGTH_SHORT).show();
            return;
        }
        if (previewOn && liveCamera != null && pendingImageUri == null) {
            if (liveCamera.hasRecentFrame()) {
                String frame = liveCamera.latestFrameUri();
                if (frame != null) {
                    pendingImageUri = frame;
                    sendWith(text, frame, null);
                    return;
                }
            }
            sendAfterCapture = true;
            pendingText = text;
            setReply("Fotoğraf çekiliyor…");
            liveCamera.capture();
            return;
        }
        sendWith(text, pendingImageUri, pendingFileUri);
    }

    private void sendWith(String text, String imageUri, String fileUri) {
        if (!NovaAgentBridge.available()) {
            setReply("Zafiro ajanı hazır değil.");
            return;
        }
        setReply("Düşünüyor…");
        if (fileUri != null) {
            NovaAgentBridge.sendFileAsync(text, fileUri, result -> {
                if (Looper.myLooper() != Looper.getMainLooper()) {
                    main.post(() -> handleSendResult(result));
                } else {
                    handleSendResult(result);
                }
            });
            return;
        }
        handleSendResult(NovaAgentBridge.send(text, imageUri));
    }

    private void handleSendResult(String result) {
        if ("started".equals(result)) {
            if (inputView != null) inputView.setText("");
            pendingImageUri = null;
            pendingFileUri = null;
            updateAttachmentChip();
            pendingText = "";
            setReply("Düşünüyor…");
            startAgentPolling();
        } else if ("busy".equals(result)) {
            setReply("Zaten bir yanıt üretiliyor. Bitmesini bekle.");
        } else if ("empty".equals(result)) {
            setReply("Bir şey yaz veya bir fotoğraf/dosya ekle.");
        } else if ("unreadable".equals(result)) {
            setReply("Dosya okunamadı. Başka bir dosya seç.");
        } else {
            setReply("Ajan yanıtı başlatılamadı.");
        }
        if (!"started".equals(result) && voiceLoop) {
            awaitingVoice = false;
            restartVoice(900);
        }
    }

    private void setReply(String text) {
        lastReply = text == null ? "" : text;
        if (replyView != null) replyView.setText(text);
    }

    private void copyReply() {
        if (replyView == null) return;
        CharSequence text = replyView.getText();
        if (text == null || text.length() == 0) return;
        try {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboard != null) {
                clipboard.setPrimaryClip(ClipData.newPlainText("Nova", text));
                Toast.makeText(this, "Yanıt kopyalandı", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ignored) {
        }
    }

    private void startAgentPolling() {
        agentPolling = true;
        main.removeCallbacks(agentPoll);
        main.post(agentPoll);
    }

    private void stopAgentPolling() {
        agentPolling = false;
        main.removeCallbacks(agentPoll);
    }

    private final Runnable agentPoll = new Runnable() {
        @Override
        public void run() {
            if (!agentPolling) return;
            boolean running = NovaAgentBridge.isRunning();
            if (!panelOpen) {
                if (lastAgentRunning && !running && HtmlAppsFloatStyle.autoOpen(
                        HtmlAppsFloatingButtonService.this)) {
                    openPanel();
                }
                lastAgentRunning = running;
                main.postDelayed(this, 180);
                return;
            }
            if (replyView == null) {
                lastAgentRunning = running;
                main.postDelayed(this, 180);
                return;
            }
            String reply = NovaAgentBridge.replyText();
            String transcript = NovaAgentBridge.transcriptText();
            String shown = transcript.isEmpty() ? NovaAgentBridge.statusText() : transcript;
            if (voiceLoop && awaitingVoice && !running) {
                awaitingVoice = false;
                if (HtmlAppsFloatStyle.speakerEnabled(
                        HtmlAppsFloatingButtonService.this) && !reply.isEmpty()) {
                    lastSpoken = reply;
                    speak(reply);
                } else {
                    restartVoice(600);
                }
            }
            if (!shown.equals(lastReply)) {
                lastReply = shown;
                replyView.setText(shown);
                if (panelScroll != null) {
                    panelScroll.post(() -> {
                        if (HtmlAppsFloatStyle.replyTop(HtmlAppsFloatingButtonService.this)
                                && replyView != null) {
                            panelScroll.smoothScrollTo(0,
                                    Math.max(0, replyView.getBottom()
                                            - panelScroll.getHeight() + dp(24)));
                        } else {
                            panelScroll.fullScroll(View.FOCUS_DOWN);
                        }
                    });
                }
                if (HtmlAppsFloatStyle.speakerEnabled(
                        HtmlAppsFloatingButtonService.this)
                        && NovaAgentBridge.isIdle()
                        && !reply.isEmpty()
                        && !reply.equals(lastSpoken)) {
                    lastSpoken = reply;
                    speak(reply);
                }
            }
            lastAgentRunning = running;
            main.postDelayed(this, 180);
        }
    };

    private final NovaPanelApprover.Listener approvalListener =
            new NovaPanelApprover.Listener() {
                @Override
                public void onRequest(ApprovalRequest request) {
                    main.post(() -> showApproval(request));
                }

                @Override
                public void onClear() {
                    main.post(() -> {
                        if (confirmRow != null) confirmRow.setVisibility(View.GONE);
                    });
                }
            };

    private void showApproval(ApprovalRequest request) {
        if (confirmRow == null) return;
        String text;
        if (request instanceof ApprovalRequest.ToolExecution) {
            ApprovalRequest.ToolExecution tool = (ApprovalRequest.ToolExecution) request;
            text = "⚠ " + tool.getToolName() + ": " + tool.getCommand();
        } else if (request instanceof ApprovalRequest.ScreenControlConsent) {
            text = "⚠ Ekran kontrolü izni isteniyor.";
        } else {
            text = "⚠ Onay gerekiyor.";
        }
        confirmButton.setText("✔ Onayla");
        denyButton.setText("✖");
        confirmRow.setVisibility(View.VISIBLE);
        setReply(text);
        if (panelScroll != null) {
            panelScroll.post(() -> panelScroll.smoothScrollTo(0, confirmRow.getTop()));
        }
    }

    // ---------------------------------------------------------------- tts

    private void initTts() {
        try {
            tts = new TextToSpeech(this, status -> {
                ttsReady = status == TextToSpeech.SUCCESS;
                if (ttsReady && tts != null) {
                    try {
                        int available = tts.isLanguageAvailable(new Locale("tr", "TR"));
                        if (available >= TextToSpeech.LANG_AVAILABLE) {
                            tts.setLanguage(new Locale("tr", "TR"));
                        }
                        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                            @Override public void onStart(String utteranceId) {
                                speaking = true;
                            }

                            @Override public void onDone(String utteranceId) {
                                speaking = false;
                                if (voiceLoop && panelOpen) restartVoice(350);
                            }

                            @Override public void onError(String utteranceId) {
                                speaking = false;
                                if (voiceLoop && panelOpen) restartVoice(500);
                            }
                        });
                    } catch (Exception ignored) {
                    }
                }
            });
        } catch (Exception ignored) {
            ttsReady = false;
        }
    }

    private void speak(String text) {
        if (!ttsReady || tts == null || text == null || text.trim().isEmpty()) {
            speaking = false;
            if (voiceLoop && panelOpen) restartVoice(600);
            return;
        }
        try {
            speaking = true;
            tts.speak(text.trim(), TextToSpeech.QUEUE_FLUSH, null, "nova-panel");
        } catch (Exception ignored) {
            speaking = false;
            if (voiceLoop && panelOpen) restartVoice(600);
        }
    }

    private void restartVoice(long delayMs) {
        if (!voiceLoop || !panelOpen) return;
        main.postDelayed(() -> {
            if (voiceLoop && panelOpen && !speaking && !NovaAgentBridge.isRunning()
                    && speech != null && !speech.isListening()) {
                startSpeech();
            }
        }, Math.max(200, delayMs));
    }

    // ---------------------------------------------------------------- accessibility

    private boolean isAccessibilityEnabled() {
        try {
            String enabled = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return enabled != null
                    && enabled.contains(getPackageName())
                    && enabled.contains("ZafiroAccessibilityService");
        } catch (Exception e) {
            return true;
        }
    }

    // ---------------------------------------------------------------- navigation

    /** HtmlApps parity: long-press on the ring opens the appearance menu. */
    private void showStyleMenu() {
        String[] options = {
                "Halka rengi",
                "Panel rengi",
                "Yazı rengi",
                HtmlAppsFloatStyle.replyTop(this) ? "Cevabı alta al" : "Cevabı üste al",
                "Görünümü varsayılana dön",
                "Uygulama kütüphanesi",
                "Zafiro uygulamasını aç",
                "Yeni sohbet"
        };
        AlertDialog dialog = new AlertDialog.Builder(this,
                android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Kaydırılabilir panel")
                .setItems(options, (d, which) -> {
                    switch (which) {
                        case 0: {
                            int alpha = HtmlAppsFloatStyle.bubbleAlpha(this);
                            HtmlAppsColorDialog.show(this, "Halka iç rengi",
                                    HtmlAppsFloatStyle.bubbleColor(this),
                                    alpha == 0 ? 180 : alpha, (color, a) -> {
                                        HtmlAppsFloatStyle.setBubble(this, color, a);
                                        applyFloatStyle();
                                    });
                            break;
                        }
                        case 1: {
                            int alpha = HtmlAppsFloatStyle.panelAlpha(this);
                            HtmlAppsColorDialog.show(this, "Panel rengi",
                                    HtmlAppsFloatStyle.panelColor(this),
                                    alpha == 0 ? 242 : alpha, (color, a) -> {
                                        HtmlAppsFloatStyle.setPanel(this, color, a);
                                        applyFloatStyle();
                                    });
                            break;
                        }
                        case 2: {
                            HtmlAppsColorDialog.show(this, "Yazı rengi",
                                    HtmlAppsFloatStyle.textColor(this),
                                    HtmlAppsFloatStyle.textAlpha(this), (color, a) -> {
                                        HtmlAppsFloatStyle.setTextColor(this, color, a);
                                        applyFloatStyle();
                                    });
                            break;
                        }
                        case 3:
                            HtmlAppsFloatStyle.setReplyTop(this,
                                    !HtmlAppsFloatStyle.replyTop(this));
                            if (panelOpen) {
                                closePanel();
                                main.postDelayed(this::openPanel, 180);
                            }
                            break;
                        case 4:
                            HtmlAppsFloatStyle.reset(this);
                            applyFloatStyle();
                            break;
                        case 5:
                            openLibrary();
                            break;
                        case 6:
                            openZafiro();
                            break;
                        default:
                            newConversation();
                            break;
                    }
                })
                .create();
        try {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
            }
        } catch (Exception ignored) {
        }
        dialog.show();
    }

    private void openZafiro() {
        closePanel();
        try {
            startActivity(new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
        } catch (Exception ignored) {
        }
    }

    private void newConversation() {
        if (NovaAgentBridge.newConversation()) {
            pendingImageUri = null;
            pendingFileUri = null;
            if (inputView != null) inputView.setText("");
            updateAttachmentChip();
            setReply("Yeni sohbet başladı.");
        } else {
            setReply("Yeni sohbet başlatılamadı.");
        }
    }

    private void openLibrary() {
        main.removeCallbacks(longPressRunnable);
        closePanel();
        try {
            startActivity(new Intent(this, HtmlAppsLibraryActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) {
        }
    }

    // ---------------------------------------------------------------- ui helpers

    private GradientDrawable rounded(int color, int strokeColor, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private int clampX(int x) {
        return Math.max(0, Math.min(screenWidth - buttonSize, x));
    }

    private int clampY(int y) {
        return Math.max(0, Math.min(screenHeight - buttonSize, y));
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}
