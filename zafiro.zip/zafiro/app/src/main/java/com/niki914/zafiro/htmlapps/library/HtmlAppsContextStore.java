package com.niki914.zafiro.htmlapps.library;

import android.content.Context;

import org.json.JSONObject;

/** Tiny shared context so the agent knows the current app/folder without asking. */
public final class HtmlAppsContextStore {

    public static final String PREFS = "htmlapps_context";

    private HtmlAppsContextStore() {}

    public static void setPackage(Context context, String packageName) {
        if (context == null || packageName == null || packageName.isEmpty()) return;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("package", packageName)
                .putLong("packageTs", System.currentTimeMillis())
                .apply();
    }

    public static void setFolder(Context context, String folder) {
        if (context == null || folder == null) return;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("folder", folder)
                .putLong("folderTs", System.currentTimeMillis())
                .apply();
    }

    public static JSONObject read(Context context) {
        JSONObject out = new JSONObject();
        try {
            android.content.SharedPreferences prefs =
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            long now = System.currentTimeMillis();
            out.put("package", prefs.getString("package", ""));
            out.put("packageAgeMs", prefs.getLong("packageTs", 0) == 0 ? -1
                    : now - prefs.getLong("packageTs", 0));
            out.put("folder", prefs.getString("folder", ""));
            out.put("folderAgeMs", prefs.getLong("folderTs", 0) == 0 ? -1
                    : now - prefs.getLong("folderTs", 0));
        } catch (Exception ignored) {
        }
        return out;
    }
}
