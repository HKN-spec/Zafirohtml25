package com.niki914.zafiro.htmlapps.library;

import android.util.Base64;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Portable QR payload for app sharing.
 *
 * The whole document is gzipped and base64url-encoded. A QR symbol tops out around 2.9 KB, so the
 * library copies the payload to the clipboard (and offers a ZIP/HTML share) instead of drawing an
 * unreadable code for large apps.
 */
public final class HtmlAppsQr {

    public static final int MAX_QR_CHARS = 2500;

    private HtmlAppsQr() {
    }

    public static String packApp(String folder, String html) throws Exception {
        JSONObject json = new JSONObject();
        json.put("type", "htmlapp_share");
        json.put("v", 1);
        json.put("folder", folder);
        json.put("html", html);
        return compress(json.toString());
    }

    public static String[] unpackApp(String data) throws Exception {
        JSONObject json = new JSONObject(decompress(data));
        if (!"htmlapp_share".equals(json.optString("type"))) throw new Exception("QR biçimi geçersiz");
        return new String[]{json.optString("folder"), json.optString("html")};
    }

    public static boolean fitsInQr(String packed) {
        return packed != null && !packed.isEmpty() && packed.length() <= MAX_QR_CHARS;
    }

    private static String compress(String text) throws Exception {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        try (GZIPOutputStream gzip = new GZIPOutputStream(buffer)) {
            gzip.write(text.getBytes(StandardCharsets.UTF_8));
        }
        return Base64.encodeToString(buffer.toByteArray(),
                Base64.NO_WRAP | Base64.URL_SAFE);
    }

    private static String decompress(String text) throws Exception {
        byte[] bytes = Base64.decode(text, Base64.NO_WRAP | Base64.URL_SAFE);
        try (GZIPInputStream gzip = new GZIPInputStream(new ByteArrayInputStream(bytes))) {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] chunk = new byte[8192];
            int read;
            while ((read = gzip.read(chunk)) > 0) buffer.write(chunk, 0, read);
            return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
