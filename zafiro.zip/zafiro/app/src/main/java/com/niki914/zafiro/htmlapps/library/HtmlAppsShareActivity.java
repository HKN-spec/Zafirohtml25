package com.niki914.zafiro.htmlapps.library;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * Share one library app: ZIP (always works), the raw index.html, or the compact QR payload text
 * that Library → "QR'dan içe aktar" understands.
 */
public class HtmlAppsShareActivity extends Activity {

    public static final String EXTRA_APP_FOLDER = "app_folder";

    private File appDir;
    private HtmlAppsRepo.App app;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String folder = getIntent().getStringExtra(EXTRA_APP_FOLDER);
        if (folder == null || folder.isEmpty()) {
            finish();
            return;
        }
        appDir = new File(HtmlAppsRepo.root(), folder);
        if (!appDir.isDirectory()) {
            finish();
            return;
        }
        app = new HtmlAppsRepo.App();
        app.folder = folder;
        app.dir = appDir;
        app.index = new File(appDir, "index.html");
        app.icon = new File(appDir, "icon.png");
        app.meta = HtmlAppsMeta.load(appDir);
        app.name = app.meta.name == null || app.meta.name.isEmpty() ? folder : app.meta.name;

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFF0B0F16);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(18);
        body.setPadding(pad, pad, pad, pad);
        scroll.addView(body);

        TextView title = new TextView(this);
        title.setText("Paylaş");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        body.addView(title);

        ImageView icon = new ImageView(this);
        icon.setImageBitmap(HtmlAppsRepo.loadIcon(app));
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(96), dp(96));
        iconParams.gravity = Gravity.CENTER_HORIZONTAL;
        iconParams.topMargin = dp(16);
        body.addView(icon, iconParams);

        TextView name = new TextView(this);
        name.setText(app.name);
        name.setTextColor(Color.WHITE);
        name.setTextSize(18);
        name.setGravity(Gravity.CENTER);
        name.setPadding(0, dp(10), 0, dp(2));
        body.addView(name);

        TextView meta = new TextView(this);
        meta.setText(app.meta.category + " · " + HtmlAppsRepo.size(app.meta.sizeBytes)
                + " · " + app.folder);
        meta.setTextColor(0xFF8FA3BF);
        meta.setTextSize(11);
        meta.setGravity(Gravity.CENTER);
        body.addView(meta);

        TextView description = new TextView(this);
        description.setText(app.meta.description == null ? "" : app.meta.description);
        description.setTextColor(0xFFB9C7DC);
        description.setTextSize(12);
        description.setGravity(Gravity.CENTER);
        description.setPadding(dp(4), dp(10), dp(4), dp(14));
        body.addView(description);

        body.addView(button("📦  ZIP olarak paylaş", 0xFF3F8CFF, v -> shareZip()));
        body.addView(button("📄  index.html paylaş", 0xFF2E7D32, v -> shareHtml()));
        body.addView(button("🔗  QR metnini kopyala", 0xFF7C4DFF, v -> copyQr()));
        body.addView(button("📋  Dosya yolunu kopyala", 0xFF3949AB, v -> copyPath()));
        body.addView(button("👁  Uygulamayı aç", 0xFF3A4556, v -> {
            startActivity(new Intent(this, HtmlAppsViewerActivity.class)
                    .putExtra(HtmlAppsViewerActivity.EXTRA_FOLDER, app.folder));
            finish();
        }));

        setContentView(scroll);
    }

    private Button button(String text, int color, android.view.View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setAllCaps(false);
        GradientDrawable background = new GradientDrawable();
        background.setColor(color);
        background.setCornerRadius(dp(14));
        button.setBackground(background);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = dp(8);
        button.setLayoutParams(params);
        button.setOnClickListener(listener);
        return button;
    }

    private void shareZip() {
        try {
            File dir = new File(getCacheDir(), "htmlapps");
            if (!dir.isDirectory()) dir.mkdirs();
            File zip = new File(dir, app.folder + "-" + System.currentTimeMillis() + ".zip");
            try (OutputStream out = new FileOutputStream(zip)) {
                HtmlAppsBackup.Result result = HtmlAppsBackup.backup(appDir.getParentFile(), out,
                        java.util.Collections.singleton(app.folder));
                if (!result.ok) throw new Exception(result.message);
            }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", zip);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("application/zip");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_SUBJECT, app.name);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "Uygulamayı paylaş"));
        } catch (Exception e) {
            toast("Paylaşılamadı: " + e.getMessage());
        }
    }

    private void shareHtml() {
        try {
            if (!app.index.isFile()) throw new Exception("index.html yok");
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider",
                    app.index);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/html");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_SUBJECT, app.name);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "HTML dosyasını paylaş"));
        } catch (Exception e) {
            toast("Paylaşılamadı: " + e.getMessage());
        }
    }

    private void copyQr() {
        try {
            String html = HtmlAppsMeta.readText(app.index);
            String packed = HtmlAppsQr.packApp(app.folder, html);
            ClipboardManager clipboard = getSystemService(ClipboardManager.class);
            if (clipboard != null) {
                clipboard.setPrimaryClip(ClipData.newPlainText(app.name, packed));
            }
            if (HtmlAppsQr.fitsInQr(packed)) {
                toast("QR metni kopyalandı (" + packed.length() + " karakter)");
            } else {
                toast("Uygulama QR için büyük; metin kopyalandı, ZIP ile paylaş");
            }
        } catch (Exception e) {
            toast("Kopyalanamadı: " + e.getMessage());
        }
    }

    private void copyPath() {
        ClipboardManager clipboard = getSystemService(ClipboardManager.class);
        if (clipboard != null) {
            clipboard.setPrimaryClip(ClipData.newPlainText("path", app.index.getAbsolutePath()));
            toast("Yol kopyalandı");
        }
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}
