package com.niki914.zafiro.htmlapps.avatar

import android.content.Context
import com.niki914.zafiro.api.screen.PhoneScreenId
import com.niki914.zafiro.api.screen.ScreenAction
import com.niki914.zafiro.api.screen.Screens
import com.niki914.zafiro.api.screen.Target
import com.niki914.zafiro.service.findService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Performs the actual gesture after the avatar has reached the target. */
object HtmlAppsScreenBridge {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    fun tap(context: Context, x: Int, y: Int) {
        scope.launch {
            runCatching {
                findService<Screens>()?.get(PhoneScreenId)
                    ?.act(ScreenAction.Tap(Target.Point(x, y)))
            }
        }
    }

    fun longClick(context: Context, x: Int, y: Int) {
        scope.launch {
            runCatching {
                findService<Screens>()?.get(PhoneScreenId)
                    ?.act(ScreenAction.LongClick(Target.Point(x, y)))
            }
        }
    }

    fun swipe(context: Context, x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long) {
        scope.launch {
            runCatching {
                findService<Screens>()?.get(PhoneScreenId)
                    ?.act(ScreenAction.Swipe(x1, y1, x2, y2, durationMs))
            }
        }
    }
}
