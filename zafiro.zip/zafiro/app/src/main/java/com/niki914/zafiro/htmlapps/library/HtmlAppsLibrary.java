package com.niki914.zafiro.htmlapps.library;

import android.content.Context;
import android.os.Environment;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Publishes generated single-file HTML pages into the HtmlApps library folder so the existing
 * HtmlApps runtime/library can launch them unchanged.
 */
public final class HtmlAppsLibrary {

    private HtmlAppsLibrary() {}

    public static File publish(Context context, String requestedName, String html) throws Exception {
        if (html == null || html.trim().isEmpty()) throw new IllegalArgumentException("empty_html");
        File root = new File(Environment.getExternalStorageDirectory(), "Download/HtmlApps");
        if (!root.isDirectory() && !root.mkdirs()) {
            throw new IllegalStateException("library_unavailable");
        }
        String name = safeName(requestedName);
        File dir = new File(root, name);
        int suffix = 2;
        while (dir.exists() && suffix < 100) dir = new File(root, name + "-" + suffix++);
        if (!dir.mkdirs()) throw new IllegalStateException("folder_unavailable");
        File index = new File(dir, "index.html");
        try (FileOutputStream out = new FileOutputStream(index)) {
            out.write(html.getBytes(StandardCharsets.UTF_8));
        }

        HtmlAppsMeta meta = new HtmlAppsMeta();
        HtmlAppsIconSuggest.Suggestion icon = HtmlAppsIconSuggest.suggest(dir.getName(), html);
        meta.name = dir.getName();
        meta.description = "Zafiro tarafından üretildi";
        meta.category = "Zafiro";
        meta.createdAt = System.currentTimeMillis();
        meta.iconEmoji = icon.emoji;
        meta.iconColor = String.format("#%06X", 0xFFFFFF & icon.color);
        meta.sizeBytes = HtmlAppsRepo.dirSize(dir);
        meta.version = 1;
        meta.tags.add("zafiro");
        meta.save(dir);

        HtmlAppsIconGenerator.render(new File(dir, "icon.png"), icon.emoji, icon.color);
        try {
            new HtmlAppsVersions(dir).snapshot("Üretim (Zafiro)");
        } catch (Exception ignored) {
        }
        return dir;
    }

    private static String safeName(String requested) {
        String value = requested == null ? "" : requested.trim();
        value = value.replaceAll("[^\\p{L}\\p{N}_-]", "-");
        value = value.replaceAll("-+", "-");
        if (value.isEmpty()) value = "Nova-App-" + System.currentTimeMillis();
        return value.length() > 40 ? value.substring(0, 40) : value;
    }
}
