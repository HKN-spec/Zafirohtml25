package com.niki914.zafiro.app

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.niki914.logging.Logger
import java.io.File

/**
 * N68 (v14): the app could write a backup to Download but often could not list it back
 * (scoped storage / missing mount at boot). MediaStore is the sanctioned read path.
 *
 * Copies matching backups into an app-private staging dir, which the ledger importer
 * can always read. Returns the number of staged files (0 when permission is missing).
 */
object LedgerMediaImport {

    private const val LOG_TAG = "niki914_zafiro_LedgerMediaImport"

    fun stage(context: Context, stagingRoot: File): Int {
        val target = File(stagingRoot, "ledger-import").apply { mkdirs() }
        var staged = 0
        runCatching {
            val projection = arrayOf(
                MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
            )
            val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?"
            val args = arrayOf("zafiro-ledger-%")
            context.contentResolver.query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                args,
                null,
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                while (cursor.moveToNext()) {
                    val name = cursor.getString(nameColumn) ?: continue
                    if (!name.startsWith("zafiro-ledger-") || !name.endsWith(".json.gz")) continue
                    val uri = ContentUris.withAppendedId(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        cursor.getLong(idColumn),
                    )
                    val out = File(target, name)
                    runCatching {
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            out.outputStream().use { output -> input.copyTo(output) }
                        }
                    }
                    if (out.isFile && out.length() > 0) staged++
                }
            }
        }.onFailure {
            Logger.w(LOG_TAG, "MediaStore staging failed: ${it.message}")
        }
        return staged
    }

    fun stagedCount(stagingRoot: File): Int =
        File(stagingRoot, "ledger-import").listFiles()
            ?.count { it.isFile && it.name.startsWith("zafiro-ledger-") } ?: 0
}
