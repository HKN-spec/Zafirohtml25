package com.niki914.zafiro.app

import android.app.ActivityManager
import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.color.DynamicColors
import com.niki914.logging.Logger
import com.niki914.xposed.api.util.ContextProvider
import com.niki914.zafiro.api.McpService
import com.niki914.zafiro.app.conversation.ConversationRepo
import com.niki914.zafiro.app.crash.CrashRecorder
import com.niki914.zafiro.app.debug.DebugLogFile
import com.niki914.zafiro.app.notification.ResidentNotificationManager
import com.niki914.zafiro.app.notification.TurnNotificationManager
import com.niki914.zafiro.app.overlay.FloatingBallOverlayManager
import com.niki914.zafiro.app.screen.PhonePointer
import com.niki914.zafiro.app.wakelock.AgentWakeLockController
import com.niki914.zafiro.htmlapps.avatar.AvatarOverlay
import com.niki914.zafiro.htmlapps.floating.HtmlAppsFloatingButtonService
import com.niki914.zafiro.business.permission.Permission
import com.niki914.zafiro.business.permission.PermissionManager
import com.niki914.zafiro.business.permission.PermissionState
import com.niki914.zafiro.chat.agentic.python.PyRuntime
import com.niki914.zafiro.chat.agentic.buildin.BuiltinToolRegistry
import com.niki914.zafiro.evolution.NightShiftScheduler
import com.niki914.zafiro.evolution.core.EvolutionRuntime
import com.niki914.zafiro.evolution.core.Hash
import com.niki914.zafiro.evolution.core.SecretVault
import com.niki914.zafiro.evolution.core.ToolInventoryEntry
import com.niki914.zafiro.evolution.json.J
import com.niki914.zafiro.evolution.json.asBool
import com.niki914.zafiro.evolution.json.objOrNull
import com.niki914.zafiro.evolution.json.str
import com.niki914.zafiro.plugin.PluginManager
import com.niki914.zafiro.repo.UpdateCheckHolder
import com.niki914.zafiro.repo.XRepo
import com.niki914.zafiro.runtime.createAppRuntimeBridge
import com.niki914.zafiro.service.requireService
import com.niki914.zafiro.settings.RuntimeEnvironment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.io.File

class App : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        CrashRecorder.install(this)
        // 日志 debug 门控：release 构建 DEBUG/VERBOSE 全停，仅 INFO+ 输出
        Logger.setDebugProvider { BuildConfig.DEBUG }
        // 调试构建额外把日志落到 filesDir/logs/（release 不装文件后端）
        DebugLogFile.install(this)
        // 非主进程（目前只有 `:python`）不初始化主进程状态：上下文与持久化只属于主进程
        //（否则 ContextProvider 从未 provide，PyRuntime.warmUp 会永远挂起）
        if (!isMainProcess()) return
        ContextProvider.provide(applicationContext)
        XRepo.init(this.applicationContext)
        ConversationRepo.init(this.applicationContext)
        RuntimeEnvironment.install(createAppRuntimeBridge())
        // 依赖装配只发生在 AppServices（主进程组合根）
        AppServices.install(this)
        initializeEvolution()
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        DynamicColors.applyToActivitiesIfAvailable(this)
        applicationScope.launch {
            UpdateCheckHolder.runOnce(BuildConfig.VERSION_NAME)
        }
        StartupWrites.track(
            applicationScope,
            { XRepo.tryPutDefaultSettings() },
            { XRepo.skills.seedDefaults() },
            { XRepo.seedPyTools() },
        )
        // OpenRouter 公共目录预热：免鉴权后台抓，30 分钟内不重拉；失败保留旧缓存
        applicationScope.launch {
            XRepo.cloudFacts.refreshOpenRouterIfStale()
        }
        applicationScope.launch {
            PyRuntime.warmUp()
        }

        observeFloatingBall()
        observeResidentNotification()
        observeMcpService()
        observeAgentWakeLock()
        PhonePointer.watch(applicationScope)
        TurnNotificationManager.init(this)
        if (AvatarOverlay.enabled(this)) {
            AvatarOverlay.get(this).show()
        }
        if (HtmlAppsFloatingButtonService.isEnabled(this)) {
            HtmlAppsFloatingButtonService.start(this)
        }
    }

    /**
     * Evrim organizması: L4 plugin'lerini yükle, çekirdeği başlat, araç envanterini ver.
     * Hiçbir hata uygulamayı düşürmez; organizma devre dışı kalır ve loglanır.
     */
    private fun initializeEvolution() {
        runCatching {
            PluginManager.load(
                context = this,
                appVersion = BuildConfig.VERSION_NAME,
                reservedNames = BuiltinToolRegistry.default().all().map { it.name }.toSet(),
            )
            val runtime = EvolutionRuntime.install(File(filesDir, "evolution"))
            // N60: the ledger's secrets are sealed with a device-bound key.
            SecretVault.sealer = KeystoreSecretSealer()
            val buildInfo = runCatching {
                assets.open("evolution/build-info.json").bufferedReader().use { it.readText() }
            }.getOrNull()?.let { J.parseOrNull(it)?.objOrNull() } ?: J.objOf(
                "version_name" to J.of(BuildConfig.VERSION_NAME),
                "version_code" to J.of(BuildConfig.VERSION_CODE),
                "gen" to J.of("source"),
                "commit" to J.of(""),
                "sha256" to J.of(""),
            )
            runtime.setBuildInfo(buildInfo)
            val apkFile = File(applicationInfo.sourceDir)
            val apkSha = runCatching { Hash.sha256(apkFile) }.getOrDefault("")
            runtime.setBuildInfo(
                J.Obj(LinkedHashMap(buildInfo.fields)).apply {
                    fields["apk_sha256"] = J.of(apkSha)
                    fields["apk_path"] = J.of(apkFile.absolutePath)
                    if (fields["sha256"].str().isBlank()) fields["sha256"] = J.of(apkSha)
                }
            )
            NightShiftScheduler.schedule(
                this,
                enabled = runtime.config().nightlyEnabled,
                startHour = runtime.config().nightStartHour,
            )
            runtime.setInventory(
                BuiltinToolRegistry.default().all().map {
                    ToolInventoryEntry(it.name, it.defaultEnabled, it.description)
                }
            )
            // N23: the ledger must outlive a reinstall. Download survives; app data does not.
            val ledgerDir = File(
                android.os.Environment.getExternalStoragePublicDirectory(
                    android.os.Environment.DIRECTORY_DOWNLOADS
                ),
                "Zafiro-ledger",
            )
            runCatching { runtime.autoImportLedger(ledgerDir) }.onFailure {
                Logger.w("niki914_zafiro_App", "ledger auto-import failed: ${it.message}")
            }
            applicationScope.launch {
                // N68: read backups through MediaStore, then fall back to the plain path.
                val staging = File(cacheDir, "ledger-media")
                val staged = runCatching { LedgerMediaImport.stage(this@App, staging) }.getOrDefault(0)
                val importDir = if (staged > 0) File(staging, "ledger-import") else ledgerDir
                // N40: three attempts. Download can mount late (FUSE) and one miss used
                // to look exactly like "there is no backup".
                var restored = false
                repeat(3) { attempt ->
                    if (attempt > 0) kotlinx.coroutines.delay(10_000)
                    val result = runCatching { runtime.autoImportLedger(importDir) }.getOrNull()
                    restored = result?.get("imported")?.asBool(false) == true ||
                        result?.get("code")?.str() == "ALREADY_IMPORTED"
                    if (restored) return@launch
                }
                // N68: archives exist but could not be restored → this is a reset, named.
                if (!restored && (staged > 0 || LedgerMediaImport.stagedCount(staging) > 0)) {
                    runtime.markResetDetected(
                        "Download'da yedek görünüyor ama içe alınamadı " +
                            "(MediaStore: $staged, dizin: ${ledgerDir.absolutePath})"
                    )
                }
            }
            applicationScope.launch {
                kotlinx.coroutines.delay(20_000)
                runCatching {
                    // N7/N48: the working mirror must be *this* build's source. A foreign
                    // track (2.x) from an old repo_sync is replaced by the APK's own copy.
                    val mirror = runtime.mirrorIdentity()
                    if (runtime.codeIndex().files().isEmpty() || mirror["state"].str() == "mismatch") {
                        // N61: the asset is src.tar.gz in this build, but a plain src.tar
                        // must also work. A failure is a note and a gap, never silent.
                        val candidates = listOf("evolution/src.tar.gz", "evolution/src.tar")
                        var seeded = false
                        var lastError = ""
                        for (asset in candidates) {
                            try {
                                val temp = File(
                                    cacheDir,
                                    "evolution-seed-" + asset.substringAfterLast('/').replace('.', '-'),
                                )
                                assets.open(asset).use { input ->
                                    temp.outputStream().use { output -> input.copyTo(output) }
                                }
                                val result = runtime.syncRepoZip(temp.absolutePath)
                                if (result["ok"].asBool(false)) {
                                    seeded = true
                                    break
                                }
                                lastError = result["error"].str()
                            } catch (missing: java.io.FileNotFoundException) {
                                lastError = "asset yok: $asset"
                            } catch (error: Throwable) {
                                lastError = error.message ?: error::class.java.simpleName
                            }
                        }
                        if (!seeded) {
                            runtime.noteSeedFailure(
                                candidates.joinToString(" | "),
                                "ASSET_UNRESOLVED",
                                lastError,
                            )
                        }
                    }
                    val skills = File(filesDir, "skills").listFiles()
                        ?.filter { it.isDirectory && File(it, "SKILL.md").isFile }
                        ?.map { it.name }
                        .orEmpty()
                    val pyToolDefs = RuntimeEnvironment.awaitSettingsGateway().listCustomPyTools()
                    val pyTools = pyToolDefs.map { it.name }
                    // N24: the inventory must match the tools the model can actually call.
                    runtime.addInventory(
                        pyToolDefs.map {
                            ToolInventoryEntry(it.name, true, "python tool")
                        }
                    )
                    runtime.syncGenome(
                        skills = skills,
                        pyTools = pyTools,
                        recipes = runtime.services.recipes.all().map { it.id },
                        plugins = PluginManager.status().filter { it.loaded }.map { it.id },
                    )
                }.onFailure {
                    Logger.w("niki914_zafiro_App", "genome sync failed: ${it.message}")
                }
            }
            applicationScope.launch {
                // N71: skills/py tools are seeded by StartupWrites; a second pass after
                // 40 s keeps genome == disk instead of freezing the first 3 skills.
                kotlinx.coroutines.delay(40_000)
                runCatching {
                    val skills = File(filesDir, "skills").listFiles()
                        ?.filter { it.isDirectory && File(it, "SKILL.md").isFile }
                        ?.map { it.name }
                        .orEmpty()
                    val pyTools = RuntimeEnvironment.awaitSettingsGateway()
                        .listCustomPyTools()
                        .map { it.name }
                    runtime.syncGenome(
                        skills = skills,
                        pyTools = pyTools,
                        recipes = runtime.services.recipes.all().map { it.id },
                        plugins = PluginManager.status().filter { it.loaded }.map { it.id },
                    )
                }.onFailure {
                    Logger.w("niki914_zafiro_App", "genome resync failed: ${it.message}")
                }
            }
            applicationScope.launch {
                kotlinx.coroutines.delay(90_000)
                EvolutionRuntime.getOrNull()?.let { runtime ->
                    runtime.markHealthy()
                    // N23: keep a fresh copy in Download so the next install can restore it.
                    runCatching { runtime.autoExportLedger(ledgerDir) }.onFailure {
                        Logger.w("niki914_zafiro_App", "ledger auto-export failed: ${it.message}")
                    }
                }
            }
        }.onFailure { throwable ->
            Logger.e("niki914_zafiro_App", "evolution init failed: ${throwable.message}")
        }
    }

    private fun observeAgentWakeLock() {
        AgentWakeLockController.start(this, applicationScope)
    }

    private fun observeMcpService() {
        applicationScope.launch {
            val service = requireService<McpService>()
            val initialConfig = XRepo.mcpService.get()
            if (initialConfig.enabled) {
                service.start()
            }
            var lastConfig = initialConfig
            XRepo.mcpService.configFlow.collect { config ->
                if (config != lastConfig) {
                    lastConfig = config
                    if (config.enabled) {
                        service.restart()
                    } else {
                        service.stop()
                    }
                }
            }
        }
    }

    private fun observeResidentNotification() = launchFeatureFlagObserver(
        enabledFlow = XRepo.residentNotificationEnabledSetting,
        permission = Permission.NOTIFICATION,
        onPermissionMissing = { XRepo.setResidentNotificationEnabled(false) },
    ) { enabled ->
        if (enabled) ResidentNotificationManager.start(this) else ResidentNotificationManager.stop(
            this
        )
    }

    private fun observeFloatingBall() = launchFeatureFlagObserver(
        enabledFlow = XRepo.floatingBallEnabledSetting,
        permission = Permission.OVERLAY,
        onPermissionMissing = { XRepo.setFloatingBallEnabled(false) },
    ) { enabled ->
        if (enabled) FloatingBallOverlayManager.show(this) else FloatingBallOverlayManager.dismiss()
    }

    /**
     * 开关类功能的统一门禁：开关被打开但缺权限时回滚开关（不静默无效），
     * 其余情况交回 [onChange] 处理。
     */
    private fun launchFeatureFlagObserver(
        enabledFlow: Flow<Boolean>,
        permission: Permission,
        onPermissionMissing: suspend () -> Unit,
        onChange: (Boolean) -> Unit,
    ) {
        applicationScope.launch {
            enabledFlow.collect { enabled ->
                if (enabled && requireService<PermissionManager>().status(permission) != PermissionState.GRANTED) {
                    onPermissionMissing()
                } else {
                    onChange(enabled)
                }
            }
        }
    }

    /**
     * 是否主进程。进程名优先读 `/proc/self/cmdline`（内核直接给出命令行，
     * 不依赖框架侧的内存状态），`getMyMemoryState` 仅作兜底；
     * 两者都取不到进程名时按主进程处理——宁可多初始化，不能让主进程缺初始化。
     */
    private fun isMainProcess(): Boolean {
        val fromProc = runCatching {
            File("/proc/self/cmdline").readBytes()
                .takeWhile { it != 0.toByte() }
                .toByteArray()
                .decodeToString()
        }.getOrNull()?.takeIf { it.isNotEmpty() }
        val name = fromProc ?: ActivityManager.RunningAppProcessInfo().also {
            ActivityManager.getMyMemoryState(it)
        }.processName?.takeIf { it.isNotEmpty() }
        return name == null || name == packageName
    }

}
